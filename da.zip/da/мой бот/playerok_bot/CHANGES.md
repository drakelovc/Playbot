# Изменения: playerok_bot + плагины autosteamoffline / autosteamrental / authcode

## История версий
- v1: первая итерация — `autosteamoffline` (`!guard`) + `autosteamrental` (`!steamguard <ник>`).
- v2: порт `revoke_sessions` / `change_password`, per-account аналитика, плагин `authcode` (IMAP), ежедневная сводка, быстрые ответы, smart bump, структурное логирование, SQLite-бэкенд, тесты pytest.
- v3: pre-reservation 5 мин, recovery после краха VM, оператор-кнопки (Продлить/Прервать/Сменить аккаунт), blacklist покупателей с авто-добавлением при refund, Prometheus `/metrics`.
- v4 (этот апдейт): Warmup аккаунтов — раз в N дней бот сам логинится в простаивающие аккаунты, чтобы Steam не помечал их как dormant.

---

## v4: Warmup аккаунтов (anti-dormant)

`plugins/_steam_session.py` — добавлен метод `SteamSession.warmup(idle_seconds=30)`. Логика: `login()` (включая 2FA через `.maFile`) → idle с лёгкими GET-пингами на community/store раз в 10 сек → возврат. Этого достаточно, чтобы Steam пометил аккаунт «недавно активен» и не уводил в dormant-режим.

`plugins/autosteamrental.py` — `Handler._warmup_tick()` вызывается из бэкграунд-чекера `_tick()`. Раз в `warmup_check_interval_hours` (по умолчанию 6 ч) ищется 1 аккаунт-кандидат:
- не заморожен;
- есть `mafile.shared_secret`;
- сейчас не в аренде;
- `last_used_at + last_warmup_at + created_at` (самый давний) ≥ `warmup_interval_days` назад.

Кандидаты сортируются по «самому давно неиспользуемому», берётся 1, запускается в отдельном потоке (параллельные warmup'ы запрещены через флаг `_warmup_running` — Steam не любит burst-логины). Per-account stats:
- `last_warmup_at`, `warmup_count`, `warmup_failures`, `last_warmup_failure_at`;
- 3 подряд неудачи → аккаунт замораживается (`frozen=True`, `freeze_reason="auto: 3 warmup failures"`) + уведомление админу.

Конфиг:
```json
"warmup_enabled": false,
"warmup_interval_days": 7,
"warmup_idle_seconds": 30,
"warmup_check_interval_hours": 6
```

Управление:
- Telegram → `/autosteamrental` → ⚙ Настройки → 🔥 Warmup → вкл/выкл, интервал в днях, idle в секундах.
- В карточке аккаунта (`Аккаунты → выбрать`) появилась строка «🔥 Warmup: дата · всего N» и кнопка «🔥 Warmup сейчас» — ручной запуск.

История пишется в `logs/structured.log.YYYY-MM-DD`: `warmup_start / warmup_ok / warmup_failed / warmup_exception` с alias и счётчиком ошибок.

---

## v3: что добавлено

### 1. Pre-reservation на 5 минут
`plugins/autosteamrental.py`. Между `NEW_DEAL` и `ITEM_PAID` Playerok бот резервирует аккаунт под deal: создаёт запись со статусом `reserved` и `reserved_until = now + pre_reservation_minutes*60`. Второй параллельный заказ на тот же лот **не получит этот аккаунт** — он будет помечен как занятый функцией `_account_in_use()`.

Если `ITEM_PAID` приходит до истечения резервации — она *промотируется* в `delivered` через `_promote_reservation()`. Если оплата не пришла за 5 минут — фоновый `_tick()` сбрасывает резервацию (`status="reservation_expired"`).

Конфиг:
```json
"pre_reservation_enabled": true,
"pre_reservation_minutes": 5
```
Управление: Telegram → `/autosteamrental` → ⚙ Настройки → ⏳ Pre-reservation (вкл/выкл).

### 2. Recovery после краха VM
`Handler._recover_on_start()` (`plugins/autosteamrental.py`) вызывается при старте плагина (внутри `start_background()`). Сканирует все assignment'ы:
- `reserved` с `reserved_until <= now` → `reservation_expired`;
- `active` с `expires_at <= now` → `expired` + флаг `recovered=True`.
- `active` с `expires_at > now` — таймер сам подхватится бэкграунд-чекером (он работает по abs-времени, отдельного хранилища таймеров нет).

Админу отправляется уведомление в Telegram о результатах recovery.

### 3. Telegram операторские кнопки для активных аренд
В меню `/autosteamrental → 🎮 Активные` теперь у каждой active/delivered аренды есть «⚙ {alias}» — открывает панель действий:
- **➕15м / ➕30м / ➕60м** — `_operator_extend()` сдвигает `expires_at` вперёд + шлёт покупателю «Время аренды увеличено».
- **🛑 Прервать** — `_operator_stop()` помечает `expired`, шлёт покупателю шаблон `expired` и (если включено) спавнит `revoke_sessions/change_password` в отдельном потоке.
- **🔁 Сменить аккаунт** — `_operator_switch_account()` подбирает свободный аккаунт, закрывает старую аренду (`expired`+`replaced_by`), создаёт новую `delivered`-запись на том же `deal_id` с суффиксом `/switch-{ts}`, шлёт покупателю новый логин/пароль.
- **🚫 Buyer → blacklist** — заносит `buyer` текущей аренды в blacklist.

### 4. Buyer blacklist
В `plugins/autosteamrental.py` добавлены функции `add_buyer_to_blacklist()`, `remove_buyer_from_blacklist()`, `is_buyer_blacklisted()`. Совпадение ищется по `username`/`id`/`email` покупателя — case-insensitive.

Авто-blacklist срабатывает на событии `DEAL_HAS_PROBLEM` от Playerok (refund/chargeback), если включён `auto_blacklist_on_refund`. Защита `NEW_DEAL` и `ITEM_PAID` — если покупатель в blacklist, событие игнорируется и шлётся уведомление админу.

Конфиг:
```json
"buyer_blacklist": ["spammer", "buyer-1@example.com"],
"auto_blacklist_on_refund": true
```
Управление: Telegram → `/autosteamrental` → ⚙ Настройки → 🚫 Blacklist (список / добавить / удалить).

### 5. Prometheus `/metrics`
Эндпоинт встроен в `playerok_bot.py`. Без внешних зависимостей — `http.server` + plaintext Prometheus 0.0.4 format.

Метрики:
- `playerok_asr_assignments_active` (gauge)
- `playerok_asr_assignments_reserved` (gauge)
- `playerok_asr_accounts_total / _free / _frozen` (gauge)
- `playerok_asr_rentals_delivered_total` (counter)
- `playerok_asr_rentals_expired_total` (counter)
- `playerok_asr_blocked_blacklist_total` (counter)
- `playerok_aso_accounts_total / _frozen` (gauge)
- `playerok_aso_delivered_total / aso_guard_sent_total / aso_limit_reached_total` (counter)
- `playerok_authcode_codes_sent_total` (counter)

Конфиг:
```json
"metrics_enabled": false,
"metrics_port": 9101,
"metrics_bind": "0.0.0.0"
```
Управление: Telegram → ⚙ Настройки → 📈 Prometheus /metrics.

После включения требуется перезапуск бота, чтобы сервер поднялся.

Пример scrape:
```yaml
scrape_configs:
  - job_name: playerok
    static_configs:
      - targets: ["bot-host:9101"]
```

---

---

## v2: что добавлено

### 1. Реальный `revoke_sessions` + смена пароля по истечении аренды
Файл: `plugins/_steam_session.py` (470 строк).

Класс `SteamSession` — точный порт из FunPay-плагина `steam_rental_v2.4.4/steam_rental.py` (строки 1405–1710). Использует `steampy.IAuthenticationService` для логина, mobile-confirmation через `identity_secret` из `.maFile`. Методы:
- `login()` — RSA + 2FA;
- `revoke_all_other_sessions()` — отзыв всех остальных сессий;
- `change_password(new_password)` — wizard recovery через `help.steampowered.com` с обязательным mobile-confirm.

Подключение в `plugins/autosteamrental.py`:
- В `Handler._tick()` при `rental_expired` вызывается `_post_expire_actions()` в отдельном потоке.
- `_post_expire_actions()` читает mafile, логинится, делает revoke/change_password при `cfg["auto_revoke_sessions"]` / `cfg["auto_change_password"]`.
- Старые пароли копятся в `acc["previous_passwords"]` (макс 5).
- 3 подряд неудачи — аккаунт замораживается (`frozen=True`, `freeze_reason="auto: 3 post-expire failures"`).

Чтобы включить:
```json
// storage/plugins/autosteamrental/config.json
"auto_revoke_sessions": true,
"auto_change_password": true
```
Требует `pip install rsa steampy` (steampy уже стоит как dep playerok_bot).

### 2. Per-account аналитика
`plugins/autosteamrental.py` хранит блок `acc["stats"]`:
- `rentals_count` — успешно завершённых аренд;
- `active_count` — сколько раз попадал в активную аренду;
- `delivered_count` — сколько раз выдавался;
- `total_minutes` — суммарно сданных минут;
- `total_revenue` — выручка;
- `first_used_at` / `last_used_at`.

В Telegram: «🎮 autosteamrental → 📊 Статистика → 📈 По аккаунтам».

### 3. Плагин `authcode` — IMAP-почта
Файл: `plugins/authcode.py` (~480 строк).

Команды покупателю в чате Playerok: `!mailcode`, `!authcode`, `!письмо` (`!email`, `!почта`).
Бот идёт в IMAP-ящик (per-account настройки или fallback на глобальные из конфига плагина), парсит последние письма от Steam, выдаёт код регэкспом (`[A-Z0-9]{5}` по умолчанию).

Хранилище: `storage/plugins/authcode/{config,accounts,history}.json`.

Telegram-меню: `/authcode` или кнопка «📧 authcode (IMAP)» в главной панели. Подразделы: Настройки / Тест / Ивенты / Инструкция.

### 4. Ежедневная сводка в Telegram
Фоновый поток `daily_summary_loop` в `playerok_bot.py`. Раз в день в час `daily_summary_hour` (по умолчанию 0, в часовом поясе `bump_tz_offset`=3, т. е. 00:00 МСК) шлёт админу:
```
📊 Ежедневная сводка (13.05.2026)
за последние 24 ч

🎮 Аренда: выдач/стартов/истекло/активных
🛡 Оффлайн: выдач/Guard кодов/лимит достигнут
📧 Authcode: выдано mail-кодов
```

Управление: «⚙️ Настройки → 📊 Ежедневная сводка». Можно включить/выключить, поменять час, прислать сводку вручную.

### 5. Кнопки быстрого ответа
Под уведомлением «💬 Новое сообщение» появляются inline-кнопки с шаблонами из `cfg["quick_replies"]`. Тап → шаблон сразу уезжает в чат Playerok, админ получает короткое подтверждение.

Управление: «⚙️ Настройки → ⚡ Быстрые ответы». Можно добавлять/удалять/сбросить к дефолтным («Здравствуйте!», «Сейчас отвечу», «Технические работы»). Максимум 6 шаблонов.

### 6. Smart bump
Лоты поднимаются только в «горячие» часы. По умолчанию каждый день 19:00–02:00 МСК.

Управление: «⚙️ Настройки → 🌙 Smart bump». Можно включить/выключить, сбросить расписание, отредактировать JSON напрямую. Формат:
```json
[
  {"days": [1,2,3,4,5,6,7], "from": 19, "to": 2}
]
```
Дни: 1=Пн … 7=Вс. Поддерживается переход через полночь (`from > to`).

Часовой пояс: `cfg["bump_tz_offset"]` = 3 (МСК).

### 7. Структурированное логирование + ротация
Помимо `playerok_bot.log` (plain-text), бот пишет JSON-логи в `logs/structured.log.YYYY-MM-DD` (ротация ежедневно, хранятся 14 дней).

Формат каждой записи:
```json
{"ts":"2026-05-13T20:27:01","lvl":"INFO","logger":"playerok_bot.autosteamrental",
 "msg":"delivered","event":"delivered","deal_id":"d-123","alias":"leshaman111"}
```
Дочерние логгеры плагинов автоматически прицепляются к JSON-хендлеру. Любой `log.info("...", extra={"event":..., "deal_id":...})` уйдёт в JSON-лог как поля.

### 8. SQLite-бэкенд (с lazy-миграцией из JSON)
Файл: `plugins/_sqlite_store.py`.

По умолчанию **выключен** (плагины пишут JSON как раньше). Включить:
```bash
export PLAYEROK_USE_SQLITE=1
```
После этого `_steam_common.load_json` / `save_json` начнут работать через `storage/plugins.db` (одна таблица `blobs(path TEXT PK, value TEXT, updated_at INTEGER)`, WAL-режим). При первом чтении файл из JSON автоматически переносится в БД, JSON-файл остаётся как резервная копия. Опционально можно держать оба формата синхронно через `PLAYEROK_SQLITE_BACKUP_JSON=1`.

### 9. Тесты pytest
Папка `tests/` (4 файла, 23 теста):
- `test_steam_common.py` — load/save, parse maFile, парсер длительности, SQLite roundtrip;
- `test_autosteamrental.py` — `_handle_item_paid`, `!steamguard`, `_tick` (истечение), `bump_stat`, smart-bump логика;
- `test_autosteamoffline.py` — `_handle_item_paid`, лимит `!guard`;
- `test_authcode.py` — fallback при отсутствии IMAP, выдача кода, алиасы команд, MIME-декодинг.

Запуск:
```bash
pip install pytest
pytest tests/ -v
```
Все 23 теста зелёные.

---

## Старое (v1): autosteamoffline / autosteamrental

### 🛡 Плагин `autosteamoffline`
Заменяет старый `steam_guard`. Команда в чате — `!guard` (алиасы `!code` / `!код`).

После оплаты бот шлёт:
```
🛡 Спасибо за покупку оффлайн активации Steam!
Ваши данные:
• Логин: ...
• Пароль: ...
Для получения кода, отправьте в чат команду !guard
Вы можете получать код 3 раз(-а)
```
Покупатель пишет `!guard` → Steam Guard-код. По исчерпании — «лимит исчерпан».

Telegram: `/autosteamoffline` или кнопка в главной панели.

### 🎮 Плагин `autosteamrental`
Команда — `!steamguard <ник>`.

После оплаты бот шлёт логин/пароль + длительность. Первый `!steamguard <ник>` → запускает таймер аренды + код. За 15 минут до конца — напоминание. По истечении — «Срок аренды истёк».

Длительность: `lot_map[item_id].duration_minutes` → или парсится из названия (`на 2 часа`, `на 1 сутки`).

Telegram: `/autosteamrental` или кнопка в главной панели.

## Что НЕ перенесено из FunPay (специально)
- AI-верификация фото (PC-club);
- VAC / Trade-ban скан через Steam Web API;
- Лицензионная система модуля.

## Хранилище
`storage/plugins/<id>/{config,accounts,assignments,history,events}.json`.

Пулы `autosteamoffline` / `autosteamrental` / `authcode` независимые. SQLite-бэкенд — опциональный (`PLAYEROK_USE_SQLITE=1`), хранит то же самое в одной БД `storage/plugins.db`.

## Миграция конфига
- `enabled_plugins`: `["steam_guard"]` → `["autosteamoffline","autosteamrental"]` (+ `authcode` если добавлено).
- Новые ключи добавляются с дефолтами; старые ключи сохраняются.
