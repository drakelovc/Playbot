"""
Playerok Steam Guard Bot — полноценный бот для автоматизации продаж на Playerok.
Аналог Easy Sell | Playerok с интеграцией Steam Guard кодов.

Возможности:
- Панель управления с полной статистикой
- Автонастройки: автовыдача кодов, автоответчик, приветствие, автоподтверждение
- Профиль: чаты, покупатели, уведомления, вечный онлайн
- Мониторинг чатов Playerok в реальном времени
- Команда !code <ник> для покупателей в чате Playerok
- Привязка аккаунтов к лотам/чатам
- История и аналитика
- Управление прокси
"""
from __future__ import annotations

import json
import os
import sys
import time
import logging
import traceback
import threading
import re
from datetime import datetime, timedelta
from copy import deepcopy

# ─── Импорты ────────────────────────────────────────────────────
try:
    import telebot
    from telebot import types as tg_types
    import steampy.guard as guard
except ImportError as e:
    with open("playerok_bot.log", "a") as f:
        f.write(f"ОШИБКА ИМПОРТА: {e}\npip install pyTelegramBotAPI steampy\n")
    print(f"ОШИБКА ИМПОРТА: {e}\npip install pyTelegramBotAPI steampy")
    sys.exit(1)

try:
    from playerokapi.account import Account as PlayerokAccount
    from playerokapi.listener.listener import EventListener
    from playerokapi.enums import EventTypes, ItemDealStatuses, ItemStatuses
except ImportError as e:
    with open("playerok_bot.log", "a") as f:
        f.write(f"ОШИБКА ИМПОРТА PlayerokAPI: {e}\npip install tqdm git+https://github.com/alleexxeeyy/PlayerokAPI.git\n")
    print(f"ОШИБКА ИМПОРТА PlayerokAPI: {e}\npip install tqdm git+https://github.com/alleexxeeyy/PlayerokAPI.git")
    sys.exit(1)

# Postgres-бэкап файлов (для Railway). Если DATABASE_URL не задан — модуль no-op.
try:
    import db as _db
except Exception:
    _db = None  # type: ignore[assignment]

# Реестр плагинов — вкл/выкл фичей через панель «🧩 Плагины».
import plugins as _plugins

# ─── Конфигурация ───────────────────────────────────────────────
BOT_TOKEN = "8655548987:AAG-6OxS8wR1pxKBWgegOpj280aBL2_91Ag"
ADMIN_ID = 6163072393
CONFIG_FILE = "playerok_config.json"
ACCOUNTS_FOLDER = "accounts"
LOG_FILE = "playerok_bot.log"
CODE_PERIOD = 30

# ─── Логирование ────────────────────────────────────────────────
# Поддерживаем 2 канала логов:
#   1. человеческий — в stdout + plain-text файл (playerok_bot.log)
#   2. JSON (structured) — отдельный файл `logs/structured.log.YYYY-MM-DD`
#      с дневной ротацией. Туда же можно дописывать произвольные поля
#      (event=, deal_id=, alias=, …) через `log.info("...", extra={...})`.
import json as _json_log
from logging.handlers import TimedRotatingFileHandler


class _JsonFormatter(logging.Formatter):
    """Сериализует record в одну JSON-строку с extra-полями."""

    _STD_FIELDS = {
        "name", "msg", "args", "levelname", "levelno", "pathname",
        "filename", "module", "exc_info", "exc_text", "stack_info",
        "lineno", "funcName", "created", "msecs", "relativeCreated",
        "thread", "threadName", "processName", "process", "message",
        "taskName",
    }

    def format(self, record: logging.LogRecord) -> str:  # noqa: D401
        base: dict[str, object] = {
            "ts": self.formatTime(record, "%Y-%m-%dT%H:%M:%S"),
            "lvl": record.levelname,
            "logger": record.name,
            "msg": record.getMessage(),
        }
        for k, v in record.__dict__.items():
            if k.startswith("_") or k in self._STD_FIELDS:
                continue
            try:
                _json_log.dumps(v)
                base[k] = v
            except (TypeError, ValueError):
                base[k] = repr(v)
        if record.exc_info:
            base["exc"] = self.formatException(record.exc_info)
        return _json_log.dumps(base, ensure_ascii=False)


log = logging.getLogger("playerok_bot")
log.setLevel(logging.INFO)
_fmt = logging.Formatter("%(asctime)s [%(levelname)s] %(message)s")
_ch = logging.StreamHandler()
_ch.setFormatter(_fmt)
log.addHandler(_ch)
_fh = logging.FileHandler(LOG_FILE, encoding="utf-8")
_fh.setFormatter(_fmt)
log.addHandler(_fh)

# JSON-логи с дневной ротацией. Если папка `logs/` не создаётся —
# спокойно продолжаем без структурного логирования.
try:
    os.makedirs("logs", exist_ok=True)
    _json_fh = TimedRotatingFileHandler(
        os.path.join("logs", "structured.log"),
        when="midnight", interval=1, backupCount=14, encoding="utf-8",
    )
    _json_fh.suffix = "%Y-%m-%d"
    _json_fh.setFormatter(_JsonFormatter())
    log.addHandler(_json_fh)
    # Для дочерних логгеров (playerok_bot.autosteamrental и т. д.) —
    # тоже навешиваем json-handler, чтобы события плагинов попадали
    # в общий структурный лог.
    logging.getLogger("playerok_bot.autosteamrental").addHandler(_json_fh)
    logging.getLogger("playerok_bot.autosteamoffline").addHandler(_json_fh)
    logging.getLogger("playerok_bot.authcode").addHandler(_json_fh)
    logging.getLogger("autosteamrental.session").addHandler(_json_fh)
except Exception:
    log.exception("Не удалось поднять структурное логирование")

bot = telebot.TeleBot(BOT_TOKEN)


# ─── Контекст плагинов (заполняется ниже, после load_config) ──────
_plugin_ctx: "_plugins.PluginContext | None" = None


# ═══════════════════════════════════════════════════════════════
#  КОНФИГ
# ═══════════════════════════════════════════════════════════════

DEFAULT_CONFIG = {
    "playerok_cookies": "",
    "playerok_user_agent": "",
    "playerok_proxy": "",
    # ─── Автонастройки ───
    "auto_code": True,
    "auto_confirm": True,
    "auto_restore": False,
    "auto_restore_interval": 30,
    "auto_restore_expired": True,
    "auto_bump": False,
    "auto_bump_interval": 30,
    # Smart bump: расписание «горячих» часов авто-поднятия. Если пусто —
    # бот поднимает в любое время согласно auto_bump_interval. Если
    # заполнено — поднимает только в указанные часы (по часовому поясу
    # bump_tz_offset, по умолчанию +3 = МСК).
    # Формат: список диапазонов вида {"days": [1,2,3,4,5,6,7], "from": 19, "to": 2}
    # (день недели 1=Пн ... 7=Вс, from/to — часы 0..23, поддерживается
    # переход через полночь, например 19→2).
    "smart_bump_enabled": False,
    "smart_bump_ranges": [
        {"days": [1, 2, 3, 4, 5, 6, 7], "from": 19, "to": 2},
    ],
    "bump_tz_offset": 3,  # МСК
    # Ежедневная сводка
    "daily_summary_enabled": True,
    "daily_summary_hour": 0,   # час по bump_tz_offset (0 = 00:00 МСК)
    # Prometheus /metrics endpoint (опционально). Если порт = 0 — выключен.
    "metrics_enabled": False,
    "metrics_port": 9101,
    "metrics_bind": "0.0.0.0",
    # Кнопки быстрого ответа под уведомлением «Новое сообщение»
    "quick_replies": [
        "Здравствуйте! Спасибо за заказ.",
        "Сейчас отвечу — одну минуту.",
        "Технические работы, скоро вернусь.",
    ],
    "auto_greeting": True,
    "greeting_text": "👋 Привет! Я автоматический бот.\nДля получения Steam Guard кода напиши: !code <ник_аккаунта>",
    "ignore_reminder": True,
    "ignore_reminder_text": "⏰ Вы не ответили. Если вам нужен Steam Guard код, напишите: !code <ник_аккаунта>",
    "ignore_reminder_minutes": 10,
    "confirm_reminder": True,
    "confirm_reminder_text": "📦 Пожалуйста, подтвердите получение товара!",
    "confirm_reminder_minutes": 30,
    "after_confirm_text": "✅ Спасибо за покупку! Буду рад оставленному отзыву 🙏",
    "auto_responder": True,
    "auto_responses": {
        "привет": "👋 Привет! Чем могу помочь?",
        "здравствуйте": "👋 Здравствуйте! Чем могу помочь?",
        "hello": "👋 Hello! How can I help?",
        "помощь": "📖 Доступные команды:\n!code <ник> — получить Steam Guard код",
        "help": "📖 Commands:\n!code <nick> — get Steam Guard code",
    },
    # ─── Уведомления ───
    "notify_new_message": True,
    "notify_new_deal": True,
    "notify_deal_confirmed": True,
    "notify_deal_problem": True,
    "notify_code_sent": True,
    "permanent_online": True,
    # ─── Привязки ───
    "account_map": {},
    "default_account": "",
    # ─── Статистика ───
    "stats": {
        "codes_sent": 0,
        "deals_confirmed": 0,
        "messages_received": 0,
        "deals_total": 0,
        "revenue": 0.0,
        "started_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    },
    "history": [],
    "greeted_chats": [],
    "reminded_chats": {},
    # Список id включённых плагинов. None означает «взять дефолты» (используется
    # в plugins.is_enabled() для обратной совместимости со старыми конфигами).
    "enabled_plugins": ["autosteamoffline", "autosteamrental", "autowithdraw", "chat_manager", "reviews", "deals", "autoconfirm", "items", "custom_commands", "proxy_manager"],
}


def load_config() -> dict:
    if not os.path.exists(CONFIG_FILE):
        return deepcopy(DEFAULT_CONFIG)
    try:
        with open(CONFIG_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        for k, v in DEFAULT_CONFIG.items():
            if k not in data:
                data[k] = deepcopy(v)
        if "stats" in data:
            for sk, sv in DEFAULT_CONFIG["stats"].items():
                if sk not in data["stats"]:
                    data["stats"][sk] = sv
        # Миграция: старый плагин `steam_guard` теперь — autosteamoffline,
        # плюс заводим autosteamrental, если их ещё нет.
        plugins_list = data.get("enabled_plugins")
        if isinstance(plugins_list, list):
            if "steam_guard" in plugins_list:
                plugins_list = [p for p in plugins_list if p != "steam_guard"]
                if "autosteamoffline" not in plugins_list:
                    plugins_list.append("autosteamoffline")
                if "autosteamrental" not in plugins_list:
                    plugins_list.append("autosteamrental")
                data["enabled_plugins"] = plugins_list
        return data
    except Exception:
        return deepcopy(DEFAULT_CONFIG)


def save_config(cfg: dict):
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2, ensure_ascii=False)
    if _db is not None:
        try:
            _db.save_file(CONFIG_FILE)
        except Exception:
            log.debug("db.save_file(config) failed", exc_info=True)


# ═══════════════════════════════════════════════════════════════
#  STEAM GUARD
# ═══════════════════════════════════════════════════════════════

def load_mafiles() -> dict[str, dict]:
    """Загружает все .maFile из accounts/ и подпапок."""
    result = {}
    if not os.path.exists(ACCOUNTS_FOLDER):
        os.makedirs(ACCOUNTS_FOLDER)
    folders = [ACCOUNTS_FOLDER]
    for d in os.listdir(ACCOUNTS_FOLDER):
        p = os.path.join(ACCOUNTS_FOLDER, d)
        if os.path.isdir(p):
            folders.append(p)
    for folder in folders:
        for fn in os.listdir(folder):
            if not fn.endswith(".maFile"):
                continue
            path = os.path.join(folder, fn)
            try:
                with open(path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                name = data.get("account_name", fn.replace(".maFile", ""))
                if data.get("shared_secret"):
                    result[name.lower()] = data
            except Exception:
                pass
    return result


def generate_code(account_name: str) -> str | None:
    mafiles = load_mafiles()
    data = mafiles.get(account_name.lower())
    if not data:
        return None
    try:
        return guard.generate_one_time_code(data["shared_secret"])
    except Exception as exc:
        log.error("Ошибка генерации кода %s: %s", account_name, exc)
        return None


def get_account_names() -> list[str]:
    return [d.get("account_name", k) for k, d in load_mafiles().items()]


def seconds_until_code_change() -> int:
    return CODE_PERIOD - (int(time.time()) % CODE_PERIOD)


def _get_other_username(chat, my_username: str | None) -> str:
    """Возвращает ник собеседника в чате (не наш аккаунт)."""
    users = getattr(chat, 'users', None) or []
    # Сначала ищем участника с ником, отличным от нашего
    for u in users:
        u_name = getattr(u, 'username', None)
        if u_name and u_name != my_username:
            return u_name
    # Если не нашли — берём первого с ненулевым ником
    for u in users:
        u_name = getattr(u, 'username', None)
        if u_name:
            return u_name
    # Старое API могло иметь second_member
    sm = getattr(chat, 'second_member', None)
    if sm:
        u_name = getattr(sm, 'username', None)
        if u_name:
            return u_name
    return "?"


# ═══════════════════════════════════════════════════════════════
#  PLAYEROK CONNECTION
# ═══════════════════════════════════════════════════════════════

playerok_acc: PlayerokAccount | None = None
playerok_listener: EventListener | None = None
playerok_running = False
playerok_thread: threading.Thread | None = None
online_thread: threading.Thread | None = None
bump_thread: threading.Thread | None = None
playerok_status = {
    "connected": False,
    "last_sync": None,
    "error": None,
    "username": None,
    "email": None,
    "balance": None,
    "rating": None,
    "reviews_count": 0,
    "items_total": 0,
    "deals_incoming_total": 0,
    "deals_incoming_finished": 0,
}


def init_playerok() -> bool:
    global playerok_acc, playerok_listener, playerok_status
    cfg = load_config()
    cookies = cfg.get("playerok_cookies", "")
    user_agent = cfg.get("playerok_user_agent", "")
    proxy_raw = cfg.get("playerok_proxy", "") or ""
    # PlayerokAPI ожидает формат user:pass@ip:port (без http://)
    # Если пользователь ввёл http:// — убираем
    proxy = proxy_raw.replace("https://", "").replace("http://", "").strip() or None

    if not cookies:
        playerok_status = {**playerok_status, "connected": False, "error": "Куки не заданы"}
        return False

    try:
        if hasattr(PlayerokAccount, "instance"):
            delattr(PlayerokAccount, "instance")

        playerok_acc = PlayerokAccount(
            cookies=cookies,
            user_agent=user_agent or "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36",
            proxy=proxy,
        ).get()

        playerok_listener = EventListener(playerok_acc)
        # Прокидываем актуальный playerok-аккаунт в контекст плагинов.
        if _plugin_ctx is not None:
            _plugin_ctx.playerok_acc = playerok_acc

        # Получаем профиль
        balance_val = None
        rating_val = None
        reviews = 0
        items_total = 0
        deals_in_total = 0
        deals_in_finished = 0
        try:
            if hasattr(playerok_acc, 'balance') and playerok_acc.balance:
                balance_val = playerok_acc.balance.value / 100 if hasattr(playerok_acc.balance, 'value') else None
            if hasattr(playerok_acc, 'stats') and playerok_acc.stats:
                if hasattr(playerok_acc.stats, 'items'):
                    items_total = playerok_acc.stats.items.total
                if hasattr(playerok_acc.stats, 'deals') and playerok_acc.stats.deals:
                    if hasattr(playerok_acc.stats.deals, 'incoming'):
                        deals_in_total = playerok_acc.stats.deals.incoming.total
                        deals_in_finished = playerok_acc.stats.deals.incoming.finished
            if hasattr(playerok_acc, 'rating'):
                rating_val = playerok_acc.rating
            if hasattr(playerok_acc, 'reviews_count'):
                reviews = playerok_acc.reviews_count
        except Exception:
            pass

        playerok_status = {
            "connected": True,
            "last_sync": datetime.now().strftime("%d.%m.%Y %H:%M:%S"),
            "error": None,
            "username": playerok_acc.username,
            "email": getattr(playerok_acc, 'email', None),
            "balance": balance_val,
            "rating": rating_val,
            "reviews_count": reviews,
            "items_total": items_total,
            "deals_incoming_total": deals_in_total,
            "deals_incoming_finished": deals_in_finished,
        }
        log.info("Playerok подключён: %s", playerok_acc.username)
        return True
    except Exception as exc:
        playerok_status = {**playerok_status, "connected": False, "error": str(exc)}
        log.error("Ошибка подключения Playerok: %s\n%s", exc, traceback.format_exc())
        return False


def find_account_for_chat(chat_id: str) -> str | None:
    cfg = load_config()
    acc = cfg.get("account_map", {}).get(chat_id)
    if not acc:
        acc = cfg.get("default_account") or None
    return acc


# ═══════════════════════════════════════════════════════════════
#  PLAYEROK EVENT LOOP
# ═══════════════════════════════════════════════════════════════

def playerok_loop():
    global playerok_running, playerok_status

    if not playerok_listener:
        return

    playerok_running = True
    log.info("Playerok listener запущен")

    try:
        for event in playerok_listener.listen():
            if not playerok_running:
                break

            playerok_status["last_sync"] = datetime.now().strftime("%d.%m.%Y %H:%M:%S")
            cfg = load_config()

            # ─── Диспатч события в плагины (autosteamoffline / autosteamrental
            # и т. п.). Плагины сами фильтруют, на что реагировать. Ошибки
            # внутри плагинов глотаются — основной цикл не должен падать.
            if _plugin_ctx is not None:
                try:
                    _plugins.dispatch_event(event, _plugin_ctx)
                except Exception:
                    log.exception("plugin dispatch_event failed")

            # ═══ НОВОЕ СООБЩЕНИЕ ═══
            if event.type is EventTypes.NEW_MESSAGE:
                if not event.message or not event.message.user:
                    continue
                if event.message.user.id == playerok_acc.id:
                    continue

                cfg["stats"]["messages_received"] += 1
                save_config(cfg)

                msg_text = (event.message.text or "").strip()
                msg_lower = msg_text.lower()
                chat_id = event.chat.id
                buyer_name = getattr(event.message.user, 'username', None) or "Покупатель"

                log.info("[MSG] %s: %s", buyer_name, msg_text)

                # Уведомление админу
                if cfg.get("notify_new_message"):
                    try:
                        kb = tg_types.InlineKeyboardMarkup()
                        kb.row(
                            tg_types.InlineKeyboardButton("💬 Ответить", callback_data=f"reply:{chat_id}"),
                            tg_types.InlineKeyboardButton("🔑 Отправить код", callback_data=f"pickcode:{chat_id}"),
                        )
                        # Быстрые шаблоны: первые буквы шаблона как label
                        quick = cfg.get("quick_replies") or []
                        for i, tpl in enumerate(quick[:6]):
                            short = (tpl[:18] + "…") if len(tpl) > 19 else tpl
                            kb.add(tg_types.InlineKeyboardButton(
                                f"⚡ {short}",
                                callback_data=f"qr:{chat_id}:{i}",
                            ))
                        bot.send_message(
                            ADMIN_ID,
                            f"💬 *Новое сообщение*\n\n"
                            f"👤 {buyer_name}\n"
                            f"📝 {msg_text}\n"
                            f"💬 Чат: `{chat_id}`",
                            parse_mode="Markdown", reply_markup=kb,
                        )
                    except Exception:
                        pass

                # ─── !code/!guard/!steamguard ───
                # Команды Steam Guard теперь полностью обрабатываются
                # плагинами `autosteamoffline` (!guard / !code) и
                # `autosteamrental` (!steamguard) — см. dispatch_event выше.
                # Здесь оставлен только обратно-совместимый fallback `!code <ник>`
                # для админа / тестов: если ни один плагин не подхватил
                # сообщение и !code задан явно с ником — генерируем код из
                # старого пула `accounts/`.
                if msg_lower.startswith("!code"):
                    parts = msg_text.split(maxsplit=1)
                    if len(parts) >= 2:
                        requested_name = parts[1].strip()
                        code = generate_code(requested_name)
                        if code:
                            remaining = seconds_until_code_change()
                            try:
                                playerok_acc.send_message(
                                    chat_id=chat_id,
                                    text=f"🔐 Steam Guard код для {requested_name}:\n{code}\n⏱ Действует ещё {remaining} сек."
                                )
                                cfg = load_config()
                                cfg["stats"]["codes_sent"] += 1
                                cfg["history"].append({
                                    "type": "code", "account": requested_name,
                                    "buyer": buyer_name, "chat_id": chat_id,
                                    "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                                })
                                cfg["history"] = cfg["history"][-200:]
                                save_config(cfg)
                                log.info("[CODE] %s → %s (%s)", requested_name, buyer_name, code)
                                if cfg.get("notify_code_sent"):
                                    try:
                                        bot.send_message(
                                            ADMIN_ID,
                                            f"🔐 *Код отправлен*\n👤 {buyer_name}\n🎮 `{requested_name}`\n🔑 `{code}`",
                                            parse_mode="Markdown",
                                        )
                                    except Exception:
                                        pass
                            except Exception as exc:
                                log.error("Ошибка отправки кода: %s", exc)
                                try:
                                    playerok_acc.send_message(chat_id=chat_id, text="❌ Ошибка отправки кода. Попробуйте позже.")
                                except Exception:
                                    pass
                        else:
                            # Аккаунт не найден
                            names = get_account_names()
                            if names:
                                names_list = ", ".join(names[:10])
                                try:
                                    playerok_acc.send_message(
                                        chat_id=chat_id,
                                        text=f"❌ Аккаунт «{requested_name}» не найден.\n\n📋 Доступные:\n{names_list}"
                                    )
                                except Exception:
                                    pass
                            else:
                                try:
                                    playerok_acc.send_message(chat_id=chat_id, text="❌ Нет доступных аккаунтов.")
                                except Exception:
                                    pass
                    else:
                        # Просто !code без ника
                        acc_name = find_account_for_chat(chat_id)
                        if acc_name:
                            code = generate_code(acc_name)
                            if code:
                                remaining = seconds_until_code_change()
                                try:
                                    playerok_acc.send_message(
                                        chat_id=chat_id,
                                        text=f"🔐 Steam Guard код:\n{code}\n⏱ Действует ещё {remaining} сек."
                                    )
                                    cfg = load_config()
                                    cfg["stats"]["codes_sent"] += 1
                                    cfg["history"].append({
                                        "type": "code", "account": acc_name,
                                        "buyer": buyer_name, "chat_id": chat_id,
                                        "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                                    })
                                    cfg["history"] = cfg["history"][-200:]
                                    save_config(cfg)
                                except Exception:
                                    pass
                        else:
                            try:
                                playerok_acc.send_message(
                                    chat_id=chat_id,
                                    text="ℹ️ Укажите ник аккаунта: !code <ник>"
                                )
                            except Exception:
                                pass
                    continue

                # ─── Автоответчик ───
                if cfg.get("auto_responder"):
                    responses = cfg.get("auto_responses", {})
                    for trigger, response in responses.items():
                        if trigger.lower() in msg_lower:
                            try:
                                playerok_acc.send_message(chat_id=chat_id, text=response)
                                log.info("[AUTO-RESP] %s → %s", trigger, buyer_name)
                            except Exception:
                                pass
                            break

                # ─── Приветствие (первое сообщение в чате) ───
                if cfg.get("auto_greeting"):
                    greeted = cfg.get("greeted_chats", [])
                    if chat_id not in greeted:
                        greeting = cfg.get("greeting_text", "")
                        if greeting:
                            try:
                                playerok_acc.send_message(chat_id=chat_id, text=greeting)
                                cfg["greeted_chats"].append(chat_id)
                                cfg["greeted_chats"] = cfg["greeted_chats"][-500:]
                                save_config(cfg)
                                log.info("[GREETING] → %s", buyer_name)
                            except Exception:
                                pass

            # ═══ ТОВАР ОПЛАЧЕН ═══
            elif event.type is EventTypes.ITEM_PAID:
                deal = event.deal
                buyer = getattr(deal.buyer, 'username', None) or "Покупатель" if hasattr(deal, 'buyer') and deal.buyer else "?"
                item_name = getattr(deal.item, 'name', "Товар") if hasattr(deal, 'item') and deal.item else "Товар"
                price = getattr(deal, 'price', 0)
                price_val = price / 100 if isinstance(price, int) and price > 100 else price

                log.info("[DEAL] Оплата: %s от %s (%.2f₽)", item_name, buyer, price_val or 0)

                cfg = load_config()
                cfg["stats"]["deals_total"] += 1
                cfg["stats"]["revenue"] += float(price_val or 0)
                cfg["history"].append({
                    "type": "deal", "deal_id": deal.id, "item": item_name,
                    "buyer": buyer, "price": price_val,
                    "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                })
                cfg["history"] = cfg["history"][-200:]
                save_config(cfg)

                if cfg.get("notify_new_deal"):
                    try:
                        kb = tg_types.InlineKeyboardMarkup()
                        kb.row(
                            tg_types.InlineKeyboardButton("✅ Подтвердить", callback_data=f"confirm_deal:{deal.id}"),
                            tg_types.InlineKeyboardButton("↩️ Возврат", callback_data=f"rollback_deal:{deal.id}"),
                        )
                        bot.send_message(
                            ADMIN_ID,
                            f"💰 *Новая оплата!*\n\n"
                            f"🛒 {item_name}\n"
                            f"👤 {buyer}\n"
                            f"💵 {price_val:.2f} ₽\n"
                            f"🆔 `{deal.id}`",
                            parse_mode="Markdown", reply_markup=kb,
                        )
                    except Exception:
                        pass

                # Автоподтверждение
                if cfg.get("auto_confirm"):
                    time.sleep(3)
                    try:
                        playerok_acc.update_deal(deal.id, ItemDealStatuses.SENT)
                        cfg = load_config()
                        cfg["stats"]["deals_confirmed"] += 1
                        cfg["history"].append({
                            "type": "auto_confirm", "deal_id": deal.id,
                            "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                        })
                        save_config(cfg)
                        log.info("[AUTO-CONFIRM] %s", deal.id)
                        try:
                            bot.send_message(ADMIN_ID, f"✅ Сделка `{deal.id}` автоподтверждена", parse_mode="Markdown")
                        except Exception:
                            pass
                    except Exception as exc:
                        log.error("Ошибка автоподтверждения: %s", exc)
                        try:
                            bot.send_message(ADMIN_ID, f"❌ Ошибка подтверждения `{deal.id}`: {exc}", parse_mode="Markdown")
                        except Exception:
                            pass

            # ═══ ТОВАР ОТПРАВЛЕН ═══
            elif event.type is EventTypes.ITEM_SENT:
                log.info("[SENT] Сделка %s отправлена", event.deal.id)

            # ═══ СДЕЛКА ПОДТВЕРЖДЕНА ═══
            elif event.type is EventTypes.DEAL_CONFIRMED or (
                hasattr(EventTypes, "DEAL_CONFIRMED_AUTOMATICALLY")
                and event.type is EventTypes.DEAL_CONFIRMED_AUTOMATICALLY
            ):
                deal = event.deal
                log.info("[CONFIRMED] Сделка %s подтверждена", deal.id)
                if cfg.get("notify_deal_confirmed"):
                    try:
                        bot.send_message(ADMIN_ID, f"✅ *Сделка подтверждена*\n🆔 `{deal.id}`", parse_mode="Markdown")
                    except Exception:
                        pass
                # Текст после подтверждения
                after_text = cfg.get("after_confirm_text", "")
                if after_text:
                    try:
                        playerok_acc.send_message(chat_id=event.chat.id, text=after_text)
                    except Exception:
                        pass

                # Автовосстановление лота после продажи
                if cfg.get("auto_restore"):
                    try:
                        item = deal.item
                        item_id = item.id
                        item_name = getattr(item, "name", "Лот")
                        item_price = getattr(item, "price", 0)
                        statuses = playerok_acc.get_item_priority_statuses(item_id, item_price)
                        free_status = next((s for s in statuses if s.price == 0), None)
                        if free_status:
                            playerok_acc.publish_item(item_id, free_status.id)
                            _recently_restored_item_ids[str(item_id)] = time.time()
                            log.info("[AUTO-RESTORE] Лот восстановлен: %s (%s)", item_name, item_id)
                            try:
                                bot.send_message(
                                    ADMIN_ID,
                                    f"\U0001f504 Лот восстановлен: {item_name}",
                                )
                            except Exception:
                                pass
                        else:
                            log.warning("[AUTO-RESTORE] Нет бесплатного статуса для лота %s", item_id)
                    except Exception as exc:
                        log.error("[AUTO-RESTORE] Ошибка восстановления лота: %s", exc)
                        try:
                            bot.send_message(
                                ADMIN_ID,
                                f"\u274c Ошибка автовосстановления лота: {exc}",
                            )
                        except Exception:
                            pass

            # ═══ ПРОБЛЕМА ═══
            elif event.type is EventTypes.DEAL_HAS_PROBLEM:
                if cfg.get("notify_deal_problem"):
                    try:
                        bot.send_message(
                            ADMIN_ID,
                            f"⚠️ *Проблема со сделкой!*\n🆔 `{event.deal.id}`\nПроверь Playerok!",
                            parse_mode="Markdown",
                        )
                    except Exception:
                        pass

            # ═══ НОВАЯ СДЕЛКА ═══
            elif event.type is EventTypes.NEW_DEAL:
                log.info("[NEW_DEAL] %s", event.deal.id)

    except Exception as exc:
        playerok_running = False
        playerok_status["error"] = str(exc)
        playerok_status["connected"] = False
        log.error("Playerok listener упал: %s\n%s", exc, traceback.format_exc())
        try:
            bot.send_message(ADMIN_ID, f"❌ *Playerok listener упал!*\n`{exc}`\n\nПерезапуск через 30 сек...", parse_mode="Markdown")
        except Exception:
            pass
        # Авто-перезапуск через 30 сек
        time.sleep(30)
        try:
            if init_playerok():
                start_playerok_thread()
        except Exception:
            pass


# ═══════════════════════════════════════════════════════════════
#  ВЕЧНЫЙ ОНЛАЙН
# ═══════════════════════════════════════════════════════════════

def permanent_online_loop():
    while True:
        cfg = load_config()
        if not cfg.get("permanent_online") or not playerok_acc or not playerok_status.get("connected"):
            time.sleep(60)
            continue
        try:
            playerok_acc.get_chats(count=1)
            log.debug("[ONLINE] ping")
        except Exception:
            pass
        time.sleep(120)


# ═══════════════════════════════════════════════════════════════
#  АВТОПОДНЯТИЕ ЛОТОВ
# ═══════════════════════════════════════════════════════════════

def _bump_local_now(cfg: dict) -> "datetime":
    """Возвращает datetime «сейчас» в часовом поясе из cfg.bump_tz_offset."""
    from datetime import datetime, timezone, timedelta
    offset = int(cfg.get("bump_tz_offset", 3))
    return datetime.now(timezone(timedelta(hours=offset)))


def _is_bump_hot_hour(cfg: dict) -> bool:
    """True если сейчас попадает в «горячий» диапазон smart_bump_ranges.

    Если smart_bump_enabled=False — всегда True (фича выключена).
    """
    if not cfg.get("smart_bump_enabled"):
        return True
    ranges = cfg.get("smart_bump_ranges") or []
    if not ranges:
        return True
    now = _bump_local_now(cfg)
    weekday = now.isoweekday()  # 1 = Пн, 7 = Вс
    hour = now.hour
    for r in ranges:
        days = r.get("days") or [1, 2, 3, 4, 5, 6, 7]
        if weekday not in days:
            continue
        h_from = int(r.get("from", 0)) % 24
        h_to = int(r.get("to", 0)) % 24
        if h_from == h_to:
            return True  # 24/7 в этот день
        if h_from < h_to:
            if h_from <= hour < h_to:
                return True
        else:  # переход через полночь, e.g. 19→2
            if hour >= h_from or hour < h_to:
                return True
    return False


def auto_bump_loop():
    while True:
        cfg = load_config()
        if not cfg.get("auto_bump") or not playerok_acc or not playerok_status.get("connected"):
            time.sleep(60)
            continue
        if not _is_bump_hot_hour(cfg):
            # «Холодные» часы — спим 5 минут и снова проверяем
            time.sleep(300)
            continue
        interval = cfg.get("auto_bump_interval", 30) * 60
        try:
            items = playerok_acc.get_user_items(count=24)
            bumped = 0
            if items and hasattr(items, 'items'):
                for item in items.items:
                    try:
                        statuses = playerok_acc.get_item_priority_statuses(item.id, item.price)
                        free = next((s for s in statuses if s.price == 0), None)
                        if free:
                            playerok_acc.publish_item(item.id, free.id)
                            bumped += 1
                    except Exception:
                        pass
            if bumped > 0:
                log.info("[AUTO-BUMP] Поднято лотов: %d", bumped)
                try:
                    bot.send_message(ADMIN_ID, f"🚀 Автоподнятие: поднято {bumped} лотов")
                except Exception:
                    pass
        except Exception as exc:
            log.error("Ошибка автоподнятия: %s", exc)
        time.sleep(interval)


# ═══════════════════════════════════════════════════════════════
#  АВТОВОССТАНОВЛЕНИЕ ЛОТОВ (фон)
# ═══════════════════════════════════════════════════════════════

# Deduplication: tracks recently restored item IDs so the background scan
# does not re-publish items already restored by the event handler.
_recently_restored_item_ids: dict[str, float] = {}  # item_id -> timestamp

def _do_restore_scan() -> int:
    """Сканирует проданные/истекшие лоты и восстанавливает их.

    Возвращает количество восстановленных лотов.
    """
    cfg = load_config()
    if not playerok_acc or not playerok_status.get("connected"):
        return 0

    # Clean up recently restored entries older than one scan interval
    scan_interval = cfg.get("auto_restore_interval", 30) * 60
    now = time.time()
    expired_keys = [k for k, ts in _recently_restored_item_ids.items()
                    if now - ts > scan_interval]
    for k in expired_keys:
        _recently_restored_item_ids.pop(k, None)

    statuses_to_scan = [ItemStatuses.SOLD]
    if cfg.get("auto_restore_expired", True):
        statuses_to_scan.append(ItemStatuses.EXPIRED)

    restored = 0
    try:
        items_result = playerok_acc.get_my_items(statuses=statuses_to_scan, count=24)
        if items_result and hasattr(items_result, "items"):
            for item in items_result.items:
                try:
                    item_id = item.id
                    # Skip items recently restored by the event handler
                    if str(item_id) in _recently_restored_item_ids:
                        continue
                    item_name = getattr(item, "name", "Лот")
                    item_price = getattr(item, "price", 0)
                    statuses = playerok_acc.get_item_priority_statuses(item_id, item_price)
                    free_status = next((s for s in statuses if s.price == 0), None)
                    if free_status:
                        playerok_acc.publish_item(item_id, free_status.id)
                        restored += 1
                        log.info("[AUTO-RESTORE] Лот восстановлен: %s (%s)", item_name, item_id)
                        try:
                            bot.send_message(
                                ADMIN_ID,
                                f"\U0001f504 Лот восстановлен: {item_name}",
                            )
                        except Exception:
                            pass
                except Exception as exc:
                    log.error("[AUTO-RESTORE] Ошибка восстановления лота %s: %s",
                              getattr(item, "id", "?"), exc)
    except Exception as exc:
        log.error("[AUTO-RESTORE] Ошибка сканирования лотов: %s", exc)
        try:
            bot.send_message(ADMIN_ID, f"\u274c Ошибка автовосстановления: {exc}")
        except Exception:
            pass

    return restored


def auto_restore_loop():
    """Фоновый цикл периодического восстановления проданных/истекших лотов."""
    while True:
        cfg = load_config()
        if not cfg.get("auto_restore") or not playerok_acc or not playerok_status.get("connected"):
            time.sleep(60)
            continue
        interval = cfg.get("auto_restore_interval", 30) * 60
        restored = _do_restore_scan()
        if restored > 0:
            log.info("[AUTO-RESTORE] Восстановлено лотов: %d", restored)
        time.sleep(interval)


# ═══════════════════════════════════════════════════════════════
#  ЕЖЕДНЕВНАЯ СВОДКА (00:00 МСК)
# ═══════════════════════════════════════════════════════════════

def _build_daily_summary() -> str:
    """Собирает сводку за прошедшие 24 часа из storage/plugins/*/history.json
    и конфига. Возвращает текст в Markdown."""
    import os as _os
    cfg = load_config()
    now = int(time.time())
    cutoff = now - 86400

    def _events(path: str) -> list[dict]:
        try:
            import json as _json
            if not _os.path.exists(path):
                return []
            with open(path, "r", encoding="utf-8") as f:
                data = _json.load(f) or []
            if not isinstance(data, list):
                return []
            return [e for e in data
                    if isinstance(e, dict) and int(e.get("ts", 0)) >= cutoff]
        except Exception:
            return []

    asr_hist = _events("storage/plugins/autosteamrental/history.json")
    aso_hist = _events("storage/plugins/autosteamoffline/history.json")
    auc_hist = _events("storage/plugins/authcode/history.json")

    rentals_delivered = sum(1 for e in asr_hist if e.get("event") == "delivered")
    rentals_started = sum(1 for e in asr_hist if e.get("event") == "rental_started")
    rentals_expired = sum(1 for e in asr_hist if e.get("event") == "rental_expired")
    offline_delivered = sum(1 for e in aso_hist if e.get("event") == "delivered")
    guard_issued = sum(1 for e in aso_hist if e.get("event") == "guard_issued")
    guard_limit = sum(1 for e in aso_hist if e.get("event") == "guard_limit_reached")
    mail_codes = sum(1 for e in auc_hist if e.get("event") == "code_sent")

    # Активные аренды
    try:
        import json as _json
        with open("storage/plugins/autosteamrental/assignments.json", "r",
                  encoding="utf-8") as f:
            assigns = _json.load(f) or []
        active_now = sum(1 for a in assigns
                         if a.get("status") in ("active", "delivered"))
    except Exception:
        active_now = 0

    # Аккаунты с исчерпанным лимитом (autosteamoffline)
    try:
        import json as _json
        with open("storage/plugins/autosteamoffline/assignments.json", "r",
                  encoding="utf-8") as f:
            aso_assigns = _json.load(f) or []
        offline_exhausted_aliases = sorted({a.get("alias")
                                            for a in aso_assigns
                                            if a.get("codes_left", 1) == 0})
    except Exception:
        offline_exhausted_aliases = []

    today = _bump_local_now(cfg).strftime("%d.%m.%Y")
    lines = [
        f"📊 *Ежедневная сводка ({today})*",
        "_за последние 24 ч_",
        "",
        f"🎮 *Аренда*:",
        f"  • выдач: {rentals_delivered}",
        f"  • стартов (после `!steamguard`): {rentals_started}",
        f"  • истекло: {rentals_expired}",
        f"  • активных сейчас: {active_now}",
        "",
        f"🛡 *Оффлайн*:",
        f"  • выдач: {offline_delivered}",
        f"  • Guard кодов: {guard_issued}",
        f"  • достигли лимита: {guard_limit}",
    ]
    if offline_exhausted_aliases:
        lines.append(
            f"  • аккаунты с 0 оставшихся: "
            f"{', '.join(f'`{a}`' for a in offline_exhausted_aliases if a)}"
        )
    if mail_codes:
        lines += ["", f"📧 *Authcode*: выдано mail-кодов: {mail_codes}"]
    return "\n".join(lines)


# ═══════════════════════════════════════════════════════════════
#  Prometheus /metrics
# ═══════════════════════════════════════════════════════════════

def _metrics_snapshot() -> dict[str, float]:
    """Собирает текущие метрики из плагинов и истории."""
    snap: dict[str, float] = {}
    # autosteamrental
    try:
        from plugins import autosteamrental as asr
        items = asr.list_assignments()
        accs = asr.list_accounts()
        snap["asr_assignments_active"] = sum(
            1 for a in items if a.get("status") in ("active", "delivered"))
        snap["asr_assignments_reserved"] = sum(
            1 for a in items if a.get("status") == "reserved")
        snap["asr_accounts_total"] = len(accs)
        snap["asr_accounts_free"] = sum(
            1 for a in accs if not a.get("frozen")
            and not asr._account_in_use(a.get("alias", "")))
        snap["asr_accounts_frozen"] = sum(
            1 for a in accs if a.get("frozen"))
        # Counter из истории
        snap["asr_rentals_delivered_total"] = sum(
            1 for h in asr.common.load_json(asr.HISTORY_FILE, [])
            if h.get("event") == "delivered")
        snap["asr_rentals_expired_total"] = sum(
            1 for h in asr.common.load_json(asr.HISTORY_FILE, [])
            if h.get("event") == "rental_expired")
        snap["asr_blocked_blacklist_total"] = sum(
            1 for h in asr.common.load_json(asr.HISTORY_FILE, [])
            if str(h.get("event", "")).startswith("blocked_by_blacklist"))
    except Exception:
        pass
    # autosteamoffline
    try:
        from plugins import autosteamoffline as aso
        accs = aso.list_accounts()
        snap["aso_accounts_total"] = len(accs)
        snap["aso_accounts_frozen"] = sum(
            1 for a in accs if a.get("frozen"))
        hist = aso.common.load_json(aso.HISTORY_FILE, [])
        snap["aso_delivered_total"] = sum(
            1 for h in hist if h.get("event") == "delivered")
        snap["aso_guard_sent_total"] = sum(
            1 for h in hist if h.get("event") == "guard_sent")
        snap["aso_limit_reached_total"] = sum(
            1 for h in hist if h.get("event") == "limit_reached")
    except Exception:
        pass
    # authcode
    try:
        from plugins import authcode
        hist = authcode.common.load_json(authcode.HISTORY_FILE, [])
        snap["authcode_codes_sent_total"] = sum(
            1 for h in hist if h.get("event") == "mailcode_sent")
    except Exception:
        pass
    return snap


_METRIC_META = {
    # gauge — текущее состояние
    "asr_assignments_active": ("gauge", "Active rentals (delivered or active)"),
    "asr_assignments_reserved": ("gauge", "Pre-reservation holds"),
    "asr_accounts_total": ("gauge", "Rental accounts in pool"),
    "asr_accounts_free": ("gauge", "Free rental accounts"),
    "asr_accounts_frozen": ("gauge", "Frozen rental accounts"),
    "aso_accounts_total": ("gauge", "Offline accounts in pool"),
    "aso_accounts_frozen": ("gauge", "Frozen offline accounts"),
    # counter — кумулятив
    "asr_rentals_delivered_total": ("counter", "Total rental deliveries"),
    "asr_rentals_expired_total": ("counter", "Total rental expirations"),
    "asr_blocked_blacklist_total": ("counter", "Deals blocked by blacklist"),
    "aso_delivered_total": ("counter", "Total offline deliveries"),
    "aso_guard_sent_total": ("counter", "Total Steam Guard codes issued"),
    "aso_limit_reached_total": ("counter", "Total Guard limit-reached"),
    "authcode_codes_sent_total": ("counter", "Total email codes delivered"),
}


def _render_prometheus(snap: dict[str, float]) -> str:
    """Конвертит словарь {metric: value} в Prometheus text-format."""
    lines: list[str] = []
    for key, val in sorted(snap.items()):
        mtype, desc = _METRIC_META.get(
            key, ("counter" if key.endswith("_total") else "gauge", key))
        lines.append(f"# HELP playerok_{key} {desc}")
        lines.append(f"# TYPE playerok_{key} {mtype}")
        lines.append(f"playerok_{key} {float(val)}")
    return "\n".join(lines) + "\n"


def _metrics_server(port: int, bind: str):
    """Простой HTTP-сервер для Prometheus scrape — без внешних зависимостей."""
    from http.server import BaseHTTPRequestHandler, HTTPServer

    class Handler(BaseHTTPRequestHandler):
        def do_GET(self):
            if self.path not in ("/", "/metrics"):
                self.send_response(404)
                self.end_headers()
                return
            try:
                body = _render_prometheus(_metrics_snapshot()).encode("utf-8")
            except Exception:
                log.exception("metrics: snapshot failed")
                self.send_response(500)
                self.end_headers()
                return
            self.send_response(200)
            self.send_header("Content-Type",
                             "text/plain; version=0.0.4; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def log_message(self, fmt, *args):
            # Молчим в stdout — у нас свой логгер.
            log.debug("metrics: %s - %s" % (self.address_string(), fmt % args))

    try:
        srv = HTTPServer((bind, port), Handler)
        log.info("metrics: server listening on %s:%d/metrics", bind, port)
        srv.serve_forever()
    except Exception:
        log.exception("metrics: server crashed")


def metrics_loop():
    cfg = load_config()
    if not cfg.get("metrics_enabled"):
        return
    port = int(cfg.get("metrics_port", 0) or 0)
    if port <= 0:
        return
    bind = str(cfg.get("metrics_bind", "0.0.0.0"))
    _metrics_server(port, bind)


def daily_summary_loop():
    """Раз в день в `daily_summary_hour` (МСК) шлёт админу сводку."""
    last_sent_day: str | None = None
    while True:
        cfg = load_config()
        if not cfg.get("daily_summary_enabled"):
            time.sleep(120)
            continue
        now_local = _bump_local_now(cfg)
        target_hour = int(cfg.get("daily_summary_hour", 0))
        day_key = now_local.strftime("%Y-%m-%d")
        if now_local.hour == target_hour and last_sent_day != day_key:
            try:
                text = _build_daily_summary()
                bot.send_message(ADMIN_ID, text, parse_mode="Markdown")
                last_sent_day = day_key
                log.info("[DAILY-SUMMARY] отправлена сводка за %s", day_key)
            except Exception:
                log.exception("daily_summary_loop: ошибка отправки")
        time.sleep(60)


# ═══════════════════════════════════════════════════════════════
#  TELEGRAM — УТИЛИТЫ
# ═══════════════════════════════════════════════════════════════

def is_admin(uid: int) -> bool:
    return uid == ADMIN_ID


def admin_only(func):
    def wrapper(message):
        if not is_admin(message.from_user.id):
            bot.send_message(message.chat.id, "⛔ Нет доступа.")
            return
        return func(message)
    wrapper.__name__ = func.__name__
    return wrapper


def menu_keyboard() -> tg_types.ReplyKeyboardMarkup:
    kb = tg_types.ReplyKeyboardMarkup(resize_keyboard=True, is_persistent=True)
    kb.row("📊 Панель", "⭐ Автонастройки")
    kb.row("👤 Профиль", "📈 Аналитика")
    kb.row("🎮 Аккаунты", "🔗 Привязки")
    return kb


def back_button(cb_data: str = "back_main") -> tg_types.InlineKeyboardMarkup:
    kb = tg_types.InlineKeyboardMarkup()
    kb.add(tg_types.InlineKeyboardButton("‹ Назад", callback_data=cb_data))
    return kb


# ═══════════════════════════════════════════════════════════════
#  TELEGRAM — /start  ПАНЕЛЬ УПРАВЛЕНИЯ
# ═══════════════════════════════════════════════════════════════

@bot.message_handler(commands=["start", "menu"])
@admin_only
def cmd_start(message):
    # Посылаем сначала лёгкое сообщение с ReplyKeyboard — это включает постоянную
    # нижнюю клавиатуру, которая будет висеть во время всех последующих сообщений (включая те,
    # что с inline-кнопками). Не пропадает до явного ReplyKeyboardRemove.
    try:
        bot.send_message(
            message.chat.id,
            "📋 *Меню активировано* — кнопки внизу остаются на месте.",
            parse_mode="Markdown",
            reply_markup=menu_keyboard(),
        )
    except Exception:
        log.debug("send menu_keyboard failed", exc_info=True)
    send_panel(message.chat.id)


@bot.message_handler(func=lambda m: m.text == "📊 Панель")
@admin_only
def btn_panel(message):
    send_panel(message.chat.id)


def send_panel(chat_id: int, edit_msg_id: int | None = None):
    cfg = load_config()
    st = playerok_status
    connected = st.get("connected", False)
    status_icon = "✅" if connected else "🔴"
    status_text = "Работает" if connected else "Не подключён"

    username = st.get("username", "—")
    email = st.get("email", "—")
    balance = st.get("balance")
    balance_str = f"{balance:.2f} ₽" if balance is not None else "—"
    rating = st.get("rating")
    rating_str = f"{rating}" if rating else "—"
    reviews = st.get("reviews_count", 0)
    last_sync = st.get("last_sync", "—")
    error = st.get("error")

    stats = cfg.get("stats", {})
    codes = stats.get("codes_sent", 0)
    confirms = stats.get("deals_confirmed", 0)
    msgs = stats.get("messages_received", 0)
    deals = stats.get("deals_total", 0)
    revenue = stats.get("revenue", 0.0)
    accs = len(get_account_names())

    auto_confirm = "🟢" if cfg.get("auto_confirm") else "🔴"
    auto_code = "🟢" if cfg.get("auto_code") else "🔴"
    auto_bump_icon = "🟢" if cfg.get("auto_bump") else "🔴"
    auto_restore_icon = "🟢" if cfg.get("auto_restore") else "🔴"

    proxy = cfg.get("playerok_proxy", "")
    proxy_str = f"есть ({proxy})" if proxy else "нет"

    text = (
        f"📍 *Панель управления: {username}*\n\n"
        f"📊 *Статус работоспособности:*\n"
        f"{status_icon} {status_text}\n"
        f"• Username: {username}\n"
        f"• Email: {email}\n"
        f"• Баланс: {balance_str}\n"
        f"• Рейтинг: {rating_str} ({reviews} отзывов)\n"
    )
    if error:
        text += f"• ⚠️ Ошибка: {error}\n"

    text += (
        f"\n💰 *Статистика:*\n"
        f"• Кодов отправлено: {codes}\n"
        f"• Сделок: {deals} (подтверждено: {confirms})\n"
        f"• Сообщений: {msgs}\n"
        f"• Выручка: {revenue:.2f} ₽\n"
        f"• Steam аккаунтов: {accs}\n"
        f"\n🔧 *Состояние аккаунта:*\n"
        f"• Последняя синхронизация: {last_sync}\n"
        f"\n⚙️ *Настройки:*\n"
        f"• Автоподнятие: {auto_bump_icon} (интервал: {cfg.get('auto_bump_interval', 30)} мин)\n"
        f"• Автовосстановление: {auto_restore_icon}\n"
        f"• Автоподтверждение: {auto_confirm}\n"
        f"\n📦 *Прокси:* {proxy_str}\n"
    )

    kb = tg_types.InlineKeyboardMarkup(row_width=2)
    kb.row(
        tg_types.InlineKeyboardButton("⚙️ Настройки", callback_data="settings"),
        tg_types.InlineKeyboardButton("🔐 Прокси", callback_data="proxy_menu"),
    )
    kb.add(tg_types.InlineKeyboardButton("💬 Чаты и заказы", callback_data="chats"))
    kb.add(tg_types.InlineKeyboardButton("📦 Покупатели", callback_data="buyers"))
    kb.row(
        tg_types.InlineKeyboardButton("🛡 autosteamoffline", callback_data="aso:main"),
        tg_types.InlineKeyboardButton("🎮 autosteamrental", callback_data="asr:main"),
    )
    kb.add(tg_types.InlineKeyboardButton("📧 authcode (IMAP)", callback_data="auc:main"))
    kb.add(tg_types.InlineKeyboardButton("🧩 Плагины", callback_data="plugins"))
    kb.add(tg_types.InlineKeyboardButton("🔄 Обновить токен", callback_data="reconnect"))
    kb.add(tg_types.InlineKeyboardButton("✅ Прочитать все сообщения", callback_data="read_all"))

    if edit_msg_id:
        try:
            bot.edit_message_text(text, chat_id, edit_msg_id, parse_mode="Markdown", reply_markup=kb)
            return
        except Exception:
            pass
    bot.send_message(chat_id, text, parse_mode="Markdown", reply_markup=kb)


# ═══════════════════════════════════════════════════════════════
#  TELEGRAM — АВТОНАСТРОЙКИ
# ═══════════════════════════════════════════════════════════════

@bot.message_handler(func=lambda m: m.text == "⭐ Автонастройки")
@admin_only
def btn_autosettings(message):
    send_autosettings(message.chat.id)


def send_autosettings(chat_id: int, edit_msg_id: int | None = None):
    cfg = load_config()
    text = "⭐ *Автонастройки*\n\nВыберите нужный раздел:"
    kb = tg_types.InlineKeyboardMarkup()
    kb.add(tg_types.InlineKeyboardButton("📦 Автовыдача кодов", callback_data="as:auto_code"))
    kb.add(tg_types.InlineKeyboardButton("🤖 Автоответчик", callback_data="as:auto_responder"))
    kb.add(tg_types.InlineKeyboardButton("👋 Приветствие", callback_data="as:greeting"))
    kb.add(tg_types.InlineKeyboardButton("⏰ Напоминание при игноре", callback_data="as:ignore_reminder"))
    kb.add(tg_types.InlineKeyboardButton("📦 Напоминание о подтверждении", callback_data="as:confirm_reminder"))
    kb.add(tg_types.InlineKeyboardButton("✅ Текст после подтверждения", callback_data="as:after_confirm"))
    kb.add(tg_types.InlineKeyboardButton("🤝 Автоподтверждение заказов", callback_data="as:auto_confirm"))
    kb.add(tg_types.InlineKeyboardButton("🔄 Автовосстановление лотов", callback_data="as:auto_restore"))
    kb.add(tg_types.InlineKeyboardButton("🚀 Автоподнятие лотов", callback_data="as:auto_bump"))
    kb.add(tg_types.InlineKeyboardButton("‹ Назад", callback_data="back_main"))

    if edit_msg_id:
        try:
            bot.edit_message_text(text, chat_id, edit_msg_id, parse_mode="Markdown", reply_markup=kb)
            return
        except Exception:
            pass
    bot.send_message(chat_id, text, parse_mode="Markdown", reply_markup=kb)


# ═══════════════════════════════════════════════════════════════
#  TELEGRAM — ПРОФИЛЬ
# ═══════════════════════════════════════════════════════════════

@bot.message_handler(func=lambda m: m.text == "👤 Профиль")
@admin_only
def btn_profile(message):
    send_profile(message.chat.id)


def send_profile(chat_id: int, edit_msg_id: int | None = None):
    status = playerok_status
    balance = status.get("balance")
    balance_str = f"{balance:.2f} \u20bd" if balance is not None else "\u2014"
    rating = status.get("rating")
    rating_str = f"{rating}" if rating is not None else "\u2014"
    reviews = status.get("reviews_count", 0)
    sales = status.get("deals_incoming_finished", 0)
    items = status.get("items_total", 0)
    username = status.get("username") or "\u2014"
    email = status.get("email") or "\u2014"
    last_sync = status.get("last_sync") or "\u2014"

    text = (
        "\U0001f464 *\u041f\u0440\u043e\u0444\u0438\u043b\u044c*\n\n"
        f"\U0001f464 \u0418\u043c\u044f: {username}\n"
        f"\U0001f4e7 Email: {email}\n"
        f"\U0001f4b0 \u0411\u0430\u043b\u0430\u043d\u0441: {balance_str}\n"
        f"\u2b50 \u0420\u0435\u0439\u0442\u0438\u043d\u0433: {rating_str}\n"
        f"\U0001f4ac \u041e\u0442\u0437\u044b\u0432\u044b: {reviews}\n"
        f"\U0001f4e6 \u041b\u043e\u0442\u044b: {items}\n"
        f"\u2705 \u041f\u0440\u043e\u0434\u0430\u0436: {sales}\n"
        f"\n\U0001f504 \u041f\u043e\u0441\u043b. \u0441\u0438\u043d\u0445\u0440: {last_sync}"
    )
    cfg = load_config()
    kb = tg_types.InlineKeyboardMarkup()
    kb.add(tg_types.InlineKeyboardButton("\U0001f504 \u041e\u0431\u043d\u043e\u0432\u0438\u0442\u044c", callback_data="profile_refresh"))
    kb.add(tg_types.InlineKeyboardButton("\U0001f514 \u0423\u0432\u0435\u0434\u043e\u043c\u043b\u0435\u043d\u0438\u044f", callback_data="prof:notifications"))
    kb.add(tg_types.InlineKeyboardButton("\U0001f4ac \u0427\u0430\u0442\u044b \u0438 \u0437\u0430\u043a\u0430\u0437\u044b", callback_data="chats"))
    kb.add(tg_types.InlineKeyboardButton("\U0001f4e6 \u041c\u043e\u0438 \u043a\u043b\u0438\u0435\u043d\u0442\u044b", callback_data="buyers"))
    online_icon = "\U0001f7e2" if cfg.get("permanent_online") else "\U0001f534"
    kb.add(tg_types.InlineKeyboardButton(f"{online_icon} \u0412\u0435\u0447\u043d\u044b\u0439 \u043e\u043d\u043b\u0430\u0439\u043d", callback_data="toggle:permanent_online"))
    kb.add(tg_types.InlineKeyboardButton("\u2039 \u041d\u0430\u0437\u0430\u0434", callback_data="back_main"))

    if edit_msg_id:
        try:
            bot.edit_message_text(text, chat_id, edit_msg_id, parse_mode="Markdown", reply_markup=kb)
            return
        except Exception:
            pass
    bot.send_message(chat_id, text, parse_mode="Markdown", reply_markup=kb)


# ═══════════════════════════════════════════════════════════════
#  TELEGRAM — АНАЛИТИКА
# ═══════════════════════════════════════════════════════════════

@bot.message_handler(func=lambda m: m.text == "📈 Аналитика")
@admin_only
def btn_analytics(message):
    send_analytics(message.chat.id)


def _filter_history_by_period(history: list, period: str) -> list:
    """Filter history entries by period: '24h', '7d', '30d', 'all'."""
    if period == "all":
        return history
    now = datetime.now()
    if period == "24h":
        cutoff = now - timedelta(hours=24)
    elif period == "7d":
        cutoff = now - timedelta(days=7)
    elif period == "30d":
        cutoff = now - timedelta(days=30)
    else:
        return history
    result = []
    for h in history:
        t = h.get("time", "")
        if not t:
            continue
        try:
            entry_time = datetime.strptime(t, "%Y-%m-%d %H:%M:%S")
            if entry_time >= cutoff:
                result.append(h)
        except (ValueError, TypeError):
            continue
    return result


def _build_analytics_text(history: list, stats: dict, period: str) -> str:
    """Build analytics text for the given period."""
    period_labels = {"24h": "24 часа", "7d": "7 дней", "30d": "30 дней", "all": "Всё время"}
    label = period_labels.get(period, period)
    filtered = _filter_history_by_period(history, period)
    period_codes = sum(1 for h in filtered if h.get("type") == "code")
    period_deals = sum(1 for h in filtered if h.get("type") == "deal")
    period_revenue = sum(h.get("price", 0) for h in filtered if h.get("type") == "deal")

    codes = stats.get("codes_sent", 0)
    confirms = stats.get("deals_confirmed", 0)
    msgs = stats.get("messages_received", 0)
    deals = stats.get("deals_total", 0)
    revenue = stats.get("revenue", 0.0)
    started = stats.get("started_at", "\u2014")
    buyers = set(h.get("buyer", "") for h in history if h.get("buyer"))

    text = (
        f"\U0001f4c8 *Аналитика* \u2014 {label}\n\n"
        f"\U0001f4c5 *За период ({label}):*\n"
        f"\u2022 Кодов отправлено: {period_codes}\n"
        f"\u2022 Сделок: {period_deals}\n"
        f"\u2022 Выручка: {period_revenue:.2f} \u20bd\n"
        f"\n\U0001f4ca *Всего:*\n"
        f"\u2022 Кодов отправлено: {codes}\n"
        f"\u2022 Сделок: {deals}\n"
        f"\u2022 Подтверждено: {confirms}\n"
        f"\u2022 Сообщений: {msgs}\n"
        f"\u2022 Выручка: {revenue:.2f} \u20bd\n"
        f"\u2022 Уникальных покупателей: {len(buyers)}\n"
        f"\n\U0001f550 Работает с: {started}"
    )
    return text


def send_analytics(chat_id: int, edit_msg_id: int | None = None, period: str = "24h"):
    cfg = load_config()
    stats = cfg.get("stats", {})
    history = cfg.get("history", [])

    text = _build_analytics_text(history, stats, period)

    kb = tg_types.InlineKeyboardMarkup()
    kb.row(
        tg_types.InlineKeyboardButton("24h", callback_data="stats:24h"),
        tg_types.InlineKeyboardButton("7 дней", callback_data="stats:7d"),
        tg_types.InlineKeyboardButton("30 дней", callback_data="stats:30d"),
        tg_types.InlineKeyboardButton("Всё время", callback_data="stats:all"),
    )
    kb.add(tg_types.InlineKeyboardButton("\U0001f4dc История", callback_data="history"))
    kb.add(tg_types.InlineKeyboardButton("\U0001f504 Обновить", callback_data="analytics"))
    kb.add(tg_types.InlineKeyboardButton("\u2039 Назад", callback_data="back_main"))

    if edit_msg_id:
        try:
            bot.edit_message_text(text, chat_id, edit_msg_id, parse_mode="Markdown", reply_markup=kb)
            return
        except Exception:
            pass
    bot.send_message(chat_id, text, parse_mode="Markdown", reply_markup=kb)


# ═══════════════════════════════════════════════════════════════
#  TELEGRAM — АККАУНТЫ
# ═══════════════════════════════════════════════════════════════

@bot.message_handler(func=lambda m: m.text == "🎮 Аккаунты")
@admin_only
def btn_accounts(message):
    # Кнопка показывает старый пул `accounts/` (исторический Steam Guard
    # «по нику»). Современные аккаунты под аренду/оффлайн управляются
    # через /autosteamrental и /autosteamoffline.
    cfg = load_config()
    if not (_plugins.is_enabled("autosteamoffline", cfg)
            or _plugins.is_enabled("autosteamrental", cfg)):
        bot.send_message(
            message.chat.id,
            "⚠️ Плагины *autosteamoffline* и *autosteamrental* выключены.\n"
            "Включить можно в панели → «🧩 Плагины».",
            parse_mode="Markdown",
        )
        return
    names = get_account_names()
    if not names:
        bot.send_message(message.chat.id, "📭 Нет аккаунтов.\nПоложи `.maFile` в папку `accounts/`.", parse_mode="Markdown")
        return
    kb = tg_types.InlineKeyboardMarkup(row_width=2)
    for n in names:
        kb.add(tg_types.InlineKeyboardButton(f"🔑 {n}", callback_data=f"getcode:{n}"))
    bot.send_message(message.chat.id, f"🎮 *Steam аккаунты ({len(names)}):*", parse_mode="Markdown", reply_markup=kb)


# ═══════════════════════════════════════════════════════════════
#  TELEGRAM — ПРИВЯЗКИ
# ═══════════════════════════════════════════════════════════════

@bot.message_handler(func=lambda m: m.text == "🔗 Привязки")
@admin_only
def btn_links(message):
    cfg = load_config()
    acc_map = cfg.get("account_map", {})
    default_acc = cfg.get("default_account", "")

    text = "🔗 *Привязки аккаунтов к чатам*\n\n"
    if default_acc:
        text += f"📌 Аккаунт по умолчанию: `{default_acc}`\n\n"
    if acc_map:
        for cid, acc in acc_map.items():
            text += f"• Чат `{cid}` → `{acc}`\n"
    else:
        text += "Нет индивидуальных привязок.\n"

    text += (
        "\n*Команды:*\n"
        "`/link <chat_id> <аккаунт>` — привязать\n"
        "`/unlink <chat_id>` — отвязать\n"
        "`/linkall <аккаунт>` — один для всех\n"
    )
    bot.send_message(message.chat.id, text, parse_mode="Markdown")


# ═══════════════════════════════════════════════════════════════
#  TELEGRAM — CALLBACK HANDLERS
# ═══════════════════════════════════════════════════════════════

@bot.callback_query_handler(func=lambda c: c.data == "back_main")
def cb_back_main(call):
    if not is_admin(call.from_user.id):
        return
    send_panel(call.message.chat.id, call.message.message_id)


# ═══════════════════════════════════════════════════════════════
#  TELEGRAM — ПЛАГИНЫ
# ═══════════════════════════════════════════════════════════════

@bot.callback_query_handler(func=lambda c: c.data == "plugins")
def cb_plugins(call):
    if not is_admin(call.from_user.id):
        return
    cfg = load_config()
    plist = _plugins.all_plugins()
    text_lines = ["🧩 *Плагины*\n"]
    if not plist:
        text_lines.append("_Плагинов пока нет._")
    else:
        text_lines.append("Нажми на плагин чтобы прочитать описание и включить/выключить его.")
    kb = tg_types.InlineKeyboardMarkup(row_width=1)
    for p in plist:
        on = _plugins.is_enabled(p.id, cfg)
        status = "🟢" if on else "🔴"
        kb.add(tg_types.InlineKeyboardButton(
            f"{status} {p.icon} {p.name}",
            callback_data=f"plugin:{p.id}",
        ))
    kb.add(tg_types.InlineKeyboardButton("‹ Назад", callback_data="back_main"))
    try:
        bot.edit_message_text(
            "\n".join(text_lines),
            call.message.chat.id,
            call.message.message_id,
            parse_mode="Markdown",
            reply_markup=kb,
        )
    except Exception:
        bot.send_message(call.message.chat.id, "\n".join(text_lines), parse_mode="Markdown", reply_markup=kb)


def _render_plugin_info(chat_id: int, message_id: int | None, plugin_id: str):
    cfg = load_config()
    p = _plugins.get(plugin_id)
    if p is None:
        bot.send_message(chat_id, "❌ Плагин не найден.")
        return
    on = _plugins.is_enabled(p.id, cfg)
    status_line = "🟢 *Статус:* включён" if on else "🔴 *Статус:* выключен"
    text = f"{p.instruction}\n\n{status_line}"
    kb = tg_types.InlineKeyboardMarkup(row_width=1)
    if on:
        kb.add(tg_types.InlineKeyboardButton("🔴 Выключить", callback_data=f"plugin_off:{p.id}"))
    else:
        kb.add(tg_types.InlineKeyboardButton("🟢 Включить", callback_data=f"plugin_on:{p.id}"))
    kb.add(tg_types.InlineKeyboardButton("‹ К плагинам", callback_data="plugins"))
    if message_id is not None:
        try:
            bot.edit_message_text(text, chat_id, message_id, parse_mode="Markdown", reply_markup=kb)
            return
        except Exception:
            pass
    bot.send_message(chat_id, text, parse_mode="Markdown", reply_markup=kb)


@bot.callback_query_handler(func=lambda c: c.data.startswith("plugin:"))
def cb_plugin_info(call):
    if not is_admin(call.from_user.id):
        return
    plugin_id = call.data.split(":", 1)[1]
    _render_plugin_info(call.message.chat.id, call.message.message_id, plugin_id)


@bot.callback_query_handler(func=lambda c: c.data.startswith("plugin_on:") or c.data.startswith("plugin_off:"))
def cb_plugin_toggle(call):
    if not is_admin(call.from_user.id):
        return
    action, plugin_id = call.data.split(":", 1)
    enable = action == "plugin_on"
    cfg = load_config()
    _plugins.set_enabled(plugin_id, cfg, enable)
    save_config(cfg)
    p = _plugins.get(plugin_id)
    name = p.name if p else plugin_id
    try:
        bot.answer_callback_query(
            call.id,
            f"{'✅ Включён' if enable else '⛔ Выключен'}: {name}",
        )
    except Exception:
        pass
    _render_plugin_info(call.message.chat.id, call.message.message_id, plugin_id)


@bot.callback_query_handler(func=lambda c: c.data == "settings")
def cb_settings(call):
    if not is_admin(call.from_user.id):
        return
    cfg = load_config()
    kb = tg_types.InlineKeyboardMarkup()
    kb.add(tg_types.InlineKeyboardButton(
        f"{'🟢' if cfg.get('auto_confirm') else '🔴'} Подтверждение заказа",
        callback_data="toggle:auto_confirm"
    ))
    kb.add(tg_types.InlineKeyboardButton(
        f"{'🟢' if cfg.get('auto_restore') else '🔴'} Восстановление лотов",
        callback_data="toggle:auto_restore"
    ))
    kb.add(tg_types.InlineKeyboardButton(
        f"{'🟢' if cfg.get('auto_bump') else '🔴'} Поднятие лотов",
        callback_data="toggle:auto_bump"
    ))
    kb.add(tg_types.InlineKeyboardButton(
        f"⏱ Интервал поднятия: {cfg.get('auto_bump_interval', 30)} мин.",
        callback_data="bump_interval"
    ))
    kb.add(tg_types.InlineKeyboardButton(
        f"🌙 Smart bump: {'🟢 вкл' if cfg.get('smart_bump_enabled') else '🔴 выкл'}",
        callback_data="smart_bump_menu",
    ))
    kb.add(tg_types.InlineKeyboardButton(
        f"📊 Ежедневная сводка: {'🟢' if cfg.get('daily_summary_enabled') else '🔴'} "
        f"в {int(cfg.get('daily_summary_hour', 0)):02d}:00",
        callback_data="daily_summary_menu",
    ))
    kb.add(tg_types.InlineKeyboardButton(
        f"⚡ Быстрые ответы ({len(cfg.get('quick_replies') or [])})",
        callback_data="quick_replies_menu",
    ))
    kb.add(tg_types.InlineKeyboardButton(
        f"📈 Prometheus /metrics: "
        f"{'🟢 :' + str(int(cfg.get('metrics_port', 9101))) if cfg.get('metrics_enabled') else '🔴 выкл'}",
        callback_data="metrics_menu",
    ))
    kb.add(tg_types.InlineKeyboardButton("‹ Назад", callback_data="back_main"))

    try:
        bot.edit_message_text(
            "⚙️ *Настройки:*",
            call.message.chat.id, call.message.message_id,
            parse_mode="Markdown", reply_markup=kb,
        )
    except Exception:
        pass


@bot.callback_query_handler(func=lambda c: c.data.startswith("toggle:"))
def cb_toggle(call):
    if not is_admin(call.from_user.id):
        return
    key = call.data.split(":", 1)[1]
    cfg = load_config()
    cfg[key] = not cfg.get(key, False)
    save_config(cfg)
    status = "ВКЛ" if cfg[key] else "ВЫКЛ"
    bot.answer_callback_query(call.id, f"{key}: {status}")
    # Обновляем меню
    if key in ("auto_confirm", "auto_restore", "auto_bump"):
        cb_settings(call)
    elif key == "auto_restore_expired":
        # Обновляем панель автовосстановления
        call.data = "as:auto_restore"
        cb_autosetting(call)
    elif key == "smart_bump_enabled":
        _smart_bump_panel(call)
    elif key == "daily_summary_enabled":
        _daily_summary_panel(call)
    elif key == "metrics_enabled":
        _metrics_panel(call)
    elif key == "permanent_online":
        send_profile(call.message.chat.id, call.message.message_id)
    else:
        send_autosettings(call.message.chat.id, call.message.message_id)


# ═══ Smart bump / Ежедневная сводка / Быстрые ответы ═══

_DAYS_RU = ["Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"]


def _smart_bump_panel(call):
    cfg = load_config()
    ranges = cfg.get("smart_bump_ranges") or []
    text = ["🌙 *Smart bump*",
            "_подъём лотов только в выбранные часы._",
            "",
            f"Состояние: {'🟢 включено' if cfg.get('smart_bump_enabled') else '🔴 выключено'}",
            f"Часовой пояс: UTC+{cfg.get('bump_tz_offset', 3)}",
            "",
            "*Расписание:*"]
    if not ranges:
        text.append("_(не задано — будет работать 24/7)_")
    for i, r in enumerate(ranges):
        days = r.get("days") or [1, 2, 3, 4, 5, 6, 7]
        days_txt = ",".join(_DAYS_RU[d - 1] for d in days)
        text.append(
            f"`{i + 1}.` {days_txt}: {int(r.get('from', 0)):02d}:00–"
            f"{int(r.get('to', 0)):02d}:00")
    kb = tg_types.InlineKeyboardMarkup()
    kb.add(tg_types.InlineKeyboardButton(
        ("🔴 Выключить" if cfg.get("smart_bump_enabled") else "🟢 Включить"),
        callback_data="toggle:smart_bump_enabled",
    ))
    kb.add(tg_types.InlineKeyboardButton(
        "🔁 Сбросить расписание (19–02 ежедневно)",
        callback_data="smart_bump_reset",
    ))
    kb.add(tg_types.InlineKeyboardButton(
        "✏️ Редактировать JSON-расписание",
        callback_data="smart_bump_edit",
    ))
    kb.add(tg_types.InlineKeyboardButton("‹ Назад", callback_data="settings"))
    try:
        bot.edit_message_text(
            "\n".join(text), call.message.chat.id, call.message.message_id,
            parse_mode="Markdown", reply_markup=kb,
        )
    except Exception:
        bot.send_message(call.message.chat.id, "\n".join(text),
                         parse_mode="Markdown", reply_markup=kb)


@bot.callback_query_handler(func=lambda c: c.data == "smart_bump_menu")
def cb_smart_bump(call):
    if not is_admin(call.from_user.id):
        return
    _smart_bump_panel(call)


@bot.callback_query_handler(func=lambda c: c.data == "smart_bump_reset")
def cb_smart_bump_reset(call):
    if not is_admin(call.from_user.id):
        return
    cfg = load_config()
    cfg["smart_bump_ranges"] = [
        {"days": [1, 2, 3, 4, 5, 6, 7], "from": 19, "to": 2},
    ]
    save_config(cfg)
    bot.answer_callback_query(call.id, "Сброшено к 19:00–02:00")
    _smart_bump_panel(call)


@bot.callback_query_handler(func=lambda c: c.data == "smart_bump_edit")
def cb_smart_bump_edit(call):
    if not is_admin(call.from_user.id):
        return
    bot.answer_callback_query(call.id)
    cfg = load_config()
    sample = json.dumps(cfg.get("smart_bump_ranges") or [],
                        ensure_ascii=False, indent=2)
    msg = bot.send_message(
        call.message.chat.id,
        "✏️ Пришли JSON массив диапазонов. Каждый объект:\n"
        "`{\"days\": [1,2,3,4,5,6,7], \"from\": 19, \"to\": 2}`\n"
        "Дни: 1=Пн, 7=Вс. `from`/`to` — час (0–23).\n\n"
        f"Текущее:\n```\n{sample}\n```",
        parse_mode="Markdown",
    )
    bot.register_next_step_handler(msg, _process_smart_bump_edit)


def _process_smart_bump_edit(message):
    try:
        ranges = json.loads(message.text.strip())
        assert isinstance(ranges, list)
        for r in ranges:
            assert isinstance(r, dict)
            int(r.get("from", 0))
            int(r.get("to", 0))
    except Exception as exc:
        bot.send_message(message.chat.id, f"❌ Некорректный JSON: {exc}")
        return
    cfg = load_config()
    cfg["smart_bump_ranges"] = ranges
    save_config(cfg)
    bot.send_message(message.chat.id, "✅ Расписание сохранено.")


def _daily_summary_panel(call):
    cfg = load_config()
    text = [
        "📊 *Ежедневная сводка*",
        "_шлётся раз в сутки в указанный час МСК._",
        "",
        f"Состояние: {'🟢 включено' if cfg.get('daily_summary_enabled') else '🔴 выключено'}",
        f"Час отправки: {int(cfg.get('daily_summary_hour', 0)):02d}:00 "
        f"(UTC+{cfg.get('bump_tz_offset', 3)})",
    ]
    kb = tg_types.InlineKeyboardMarkup()
    kb.add(tg_types.InlineKeyboardButton(
        ("🔴 Выключить" if cfg.get("daily_summary_enabled") else "🟢 Включить"),
        callback_data="toggle:daily_summary_enabled",
    ))
    kb.add(tg_types.InlineKeyboardButton(
        "🕒 Изменить час", callback_data="daily_summary_hour"))
    kb.add(tg_types.InlineKeyboardButton(
        "📨 Прислать сводку сейчас", callback_data="daily_summary_now"))
    kb.add(tg_types.InlineKeyboardButton("‹ Назад", callback_data="settings"))
    try:
        bot.edit_message_text(
            "\n".join(text), call.message.chat.id, call.message.message_id,
            parse_mode="Markdown", reply_markup=kb,
        )
    except Exception:
        bot.send_message(call.message.chat.id, "\n".join(text),
                         parse_mode="Markdown", reply_markup=kb)


@bot.callback_query_handler(func=lambda c: c.data == "daily_summary_menu")
def cb_daily_summary(call):
    if not is_admin(call.from_user.id):
        return
    _daily_summary_panel(call)


@bot.callback_query_handler(func=lambda c: c.data == "daily_summary_now")
def cb_daily_summary_now(call):
    if not is_admin(call.from_user.id):
        return
    bot.answer_callback_query(call.id, "Собираю…")
    try:
        bot.send_message(call.message.chat.id, _build_daily_summary(),
                         parse_mode="Markdown")
    except Exception as exc:
        bot.send_message(call.message.chat.id, f"❌ Ошибка: {exc}")


@bot.callback_query_handler(func=lambda c: c.data == "daily_summary_hour")
def cb_daily_summary_hour(call):
    if not is_admin(call.from_user.id):
        return
    bot.answer_callback_query(call.id)
    msg = bot.send_message(call.message.chat.id,
                           "🕒 Введи час отправки (0–23):")
    bot.register_next_step_handler(msg, _process_daily_summary_hour)


def _process_daily_summary_hour(message):
    try:
        h = int(message.text.strip())
        assert 0 <= h <= 23
    except Exception:
        bot.send_message(message.chat.id, "❌ Час должен быть числом 0–23.")
        return
    cfg = load_config()
    cfg["daily_summary_hour"] = h
    save_config(cfg)
    bot.send_message(message.chat.id, f"✅ Сводка будет в {h:02d}:00.")


def _quick_replies_panel(call):
    cfg = load_config()
    templates = cfg.get("quick_replies") or []
    lines = ["⚡ *Быстрые ответы*",
             "_кнопки появятся под уведомлением «Новое сообщение»._",
             ""]
    if not templates:
        lines.append("_(шаблонов нет — добавь хотя бы один)_")
    for i, t in enumerate(templates):
        lines.append(f"`{i + 1}.` {t}")
    kb = tg_types.InlineKeyboardMarkup()
    kb.add(tg_types.InlineKeyboardButton("➕ Добавить",
                                         callback_data="qr_add"))
    if templates:
        kb.add(tg_types.InlineKeyboardButton(
            "🗑 Удалить по номеру", callback_data="qr_del"))
        kb.add(tg_types.InlineKeyboardButton(
            "♻️ Сбросить к стандартным", callback_data="qr_reset"))
    kb.add(tg_types.InlineKeyboardButton("‹ Назад", callback_data="settings"))
    try:
        bot.edit_message_text(
            "\n".join(lines), call.message.chat.id, call.message.message_id,
            parse_mode="Markdown", reply_markup=kb,
        )
    except Exception:
        bot.send_message(call.message.chat.id, "\n".join(lines),
                         parse_mode="Markdown", reply_markup=kb)


@bot.callback_query_handler(func=lambda c: c.data == "quick_replies_menu")
def cb_quick_replies(call):
    if not is_admin(call.from_user.id):
        return
    _quick_replies_panel(call)


@bot.callback_query_handler(func=lambda c: c.data == "qr_add")
def cb_qr_add(call):
    if not is_admin(call.from_user.id):
        return
    bot.answer_callback_query(call.id)
    msg = bot.send_message(call.message.chat.id,
                           "✏️ Пришли текст нового быстрого ответа:")
    bot.register_next_step_handler(msg, _process_qr_add)


def _process_qr_add(message):
    text = (message.text or "").strip()
    if not text:
        return
    cfg = load_config()
    qr = cfg.get("quick_replies") or []
    qr.append(text[:200])
    cfg["quick_replies"] = qr[:6]  # максимум 6 шаблонов
    save_config(cfg)
    bot.send_message(message.chat.id, "✅ Добавлено.")


@bot.callback_query_handler(func=lambda c: c.data == "qr_del")
def cb_qr_del(call):
    if not is_admin(call.from_user.id):
        return
    bot.answer_callback_query(call.id)
    msg = bot.send_message(call.message.chat.id,
                           "🗑 Введи номер шаблона для удаления:")
    bot.register_next_step_handler(msg, _process_qr_del)


def _process_qr_del(message):
    try:
        idx = int(message.text.strip()) - 1
    except Exception:
        bot.send_message(message.chat.id, "❌ Не число.")
        return
    cfg = load_config()
    qr = cfg.get("quick_replies") or []
    if not 0 <= idx < len(qr):
        bot.send_message(message.chat.id, "❌ Нет такого номера.")
        return
    removed = qr.pop(idx)
    cfg["quick_replies"] = qr
    save_config(cfg)
    bot.send_message(message.chat.id, f"✅ Удалено: _{removed}_",
                     parse_mode="Markdown")


@bot.callback_query_handler(func=lambda c: c.data == "qr_reset")
def cb_qr_reset(call):
    if not is_admin(call.from_user.id):
        return
    cfg = load_config()
    cfg["quick_replies"] = [
        "Здравствуйте! Спасибо за заказ.",
        "Сейчас отвечу — одну минуту.",
        "Технические работы, скоро вернусь.",
    ]
    save_config(cfg)
    bot.answer_callback_query(call.id, "Сброшено")
    _quick_replies_panel(call)


# ═══ Prometheus /metrics ═══

def _metrics_panel(call):
    cfg = load_config()
    state = "🟢 включено" if cfg.get("metrics_enabled") else "🔴 выключено"
    text = [
        "📈 *Prometheus /metrics*",
        "_HTTP-эндпоинт для Prometheus scrape._",
        "",
        f"Состояние: {state}",
        f"Bind: `{cfg.get('metrics_bind', '0.0.0.0')}`",
        f"Порт: `{int(cfg.get('metrics_port', 9101))}`",
        "",
        "После включения требуется перезапуск бота, чтобы сервер поднялся.",
    ]
    kb = tg_types.InlineKeyboardMarkup()
    kb.add(tg_types.InlineKeyboardButton(
        ("🔴 Выключить" if cfg.get("metrics_enabled") else "🟢 Включить"),
        callback_data="toggle:metrics_enabled",
    ))
    kb.add(tg_types.InlineKeyboardButton(
        "🔢 Изменить порт", callback_data="metrics_port"))
    kb.add(tg_types.InlineKeyboardButton("‹ Назад", callback_data="settings"))
    try:
        bot.edit_message_text(
            "\n".join(text), call.message.chat.id, call.message.message_id,
            parse_mode="Markdown", reply_markup=kb,
        )
    except Exception:
        bot.send_message(call.message.chat.id, "\n".join(text),
                         parse_mode="Markdown", reply_markup=kb)


@bot.callback_query_handler(func=lambda c: c.data == "metrics_menu")
def cb_metrics_menu(call):
    if not is_admin(call.from_user.id):
        return
    _metrics_panel(call)


@bot.callback_query_handler(func=lambda c: c.data == "metrics_port")
def cb_metrics_port(call):
    if not is_admin(call.from_user.id):
        return
    bot.answer_callback_query(call.id)
    msg = bot.send_message(call.message.chat.id, "🔢 Порт (1–65535):")
    bot.register_next_step_handler(msg, _process_metrics_port)


def _process_metrics_port(message):
    try:
        p = int(message.text.strip())
        assert 1 <= p <= 65535
    except Exception:
        bot.send_message(message.chat.id, "❌ Порт должен быть числом 1–65535.")
        return
    cfg = load_config()
    cfg["metrics_port"] = p
    save_config(cfg)
    bot.send_message(message.chat.id, f"✅ Порт: {p} (после перезапуска).")


@bot.callback_query_handler(func=lambda c: c.data == "reconnect")
def cb_reconnect(call):
    if not is_admin(call.from_user.id):
        return
    bot.answer_callback_query(call.id, "Переподключаюсь...")
    if init_playerok():
        start_playerok_thread()
        bot.send_message(call.message.chat.id, f"✅ Подключён: {playerok_acc.username}")
    else:
        bot.send_message(call.message.chat.id, f"❌ Ошибка: {playerok_status.get('error')}")


@bot.callback_query_handler(func=lambda c: c.data == "read_all")
def cb_read_all(call):
    if not is_admin(call.from_user.id):
        return
    if not playerok_acc or not playerok_status.get("connected"):
        bot.answer_callback_query(call.id, "Playerok не подключён")
        return
    try:
        chats = playerok_acc.get_chats(count=24)
        count = 0
        if chats and hasattr(chats, 'chats'):
            for c in chats.chats:
                try:
                    playerok_acc.mark_chat_as_read(c.id)
                    count += 1
                except Exception:
                    pass
        bot.answer_callback_query(call.id, f"Прочитано {count} чатов")
    except Exception as exc:
        bot.answer_callback_query(call.id, f"Ошибка: {exc}")


@bot.callback_query_handler(func=lambda c: c.data == "chats")
def cb_chats(call):
    if not is_admin(call.from_user.id):
        return
    if not playerok_acc or not playerok_status.get("connected"):
        bot.answer_callback_query(call.id, "Playerok не подключён")
        return
    try:
        chat_list = playerok_acc.get_chats(count=12)
        if not chat_list or not hasattr(chat_list, 'chats') or not chat_list.chats:
            bot.answer_callback_query(call.id, "Нет чатов")
            return
        my_username = playerok_status.get('username')
        text = f"💬 *Чаты и заказы: {my_username}*\n\nВыберите чат:"
        kb = tg_types.InlineKeyboardMarkup()
        for c in chat_list.chats:
            unread = getattr(c, 'unread_messages_counter', 0) or 0
            other = _get_other_username(c, my_username)
            kb.add(tg_types.InlineKeyboardButton(
                f"[{unread}] {other}",
                callback_data=f"chat:{c.id}"
            ))
        kb.add(tg_types.InlineKeyboardButton("‹ Назад к панели", callback_data="back_main"))
        try:
            bot.edit_message_text(
                text, call.message.chat.id, call.message.message_id,
                parse_mode="Markdown", reply_markup=kb,
            )
        except Exception:
            bot.send_message(call.message.chat.id, text, parse_mode="Markdown", reply_markup=kb)
    except Exception as exc:
        bot.answer_callback_query(call.id, f"Ошибка: {exc}")


@bot.callback_query_handler(func=lambda c: c.data.startswith("chat:"))
def cb_chat_view(call):
    if not is_admin(call.from_user.id):
        return
    chat_id = call.data.split(":", 1)[1]
    try:
        msgs = playerok_acc.get_chat_messages(chat_id, count=10)
        if not msgs or not hasattr(msgs, 'messages') or not msgs.messages:
            bot.answer_callback_query(call.id, "Нет сообщений")
            return
        lines = []
        for m in reversed(msgs.messages):
            sender = getattr(m.user, 'username', '?') if hasattr(m, 'user') and m.user else "?"
            text = m.text or "[медиа]"
            if text.startswith("{{") and text.endswith("}}"):
                text = f"[системное: {text}]"
            lines.append(f"*{sender}*: {text}")
        kb = tg_types.InlineKeyboardMarkup()
        kb.row(
            tg_types.InlineKeyboardButton("💬 Ответить", callback_data=f"reply:{chat_id}"),
            tg_types.InlineKeyboardButton("🔑 Код", callback_data=f"pickcode:{chat_id}"),
        )
        kb.add(tg_types.InlineKeyboardButton("‹ К чатам", callback_data="chats"))
        result = f"💬 *Чат* `{chat_id}`\n\n" + "\n".join(lines[-10:])
        try:
            bot.edit_message_text(
                result, call.message.chat.id, call.message.message_id,
                parse_mode="Markdown", reply_markup=kb,
            )
        except Exception:
            bot.send_message(call.message.chat.id, result, parse_mode="Markdown", reply_markup=kb)
    except Exception as exc:
        bot.answer_callback_query(call.id, f"Ошибка: {exc}")


@bot.callback_query_handler(func=lambda c: c.data == "buyers")
def cb_buyers(call):
    if not is_admin(call.from_user.id):
        return
    cfg = load_config()
    history = cfg.get("history", [])
    # Сегменты покупателей
    all_buyers = {}
    for h in history:
        buyer = h.get("buyer", "")
        if not buyer or buyer in ("?", "Покупатель"):
            continue
        if buyer not in all_buyers:
            all_buyers[buyer] = {"deals": 0, "codes": 0, "last": ""}
        if h.get("type") == "deal":
            all_buyers[buyer]["deals"] += 1
        if h.get("type") == "code":
            all_buyers[buyer]["codes"] += 1
        all_buyers[buyer]["last"] = h.get("time", "")

    text = (
        f"📦 *Покупатели для {playerok_status.get('username', '?')}*\n\n"
        f"Всего уникальных: {len(all_buyers)}\n"
    )

    if all_buyers:
        text += "\n"
        for name, info in list(all_buyers.items())[:15]:
            text += f"• {name} — сделок: {info['deals']}, кодов: {info['codes']}\n"
        if len(all_buyers) > 15:
            text += f"\n... и ещё {len(all_buyers) - 15}"

    kb = tg_types.InlineKeyboardMarkup()
    kb.add(tg_types.InlineKeyboardButton("🔄 Обновить", callback_data="buyers"))
    kb.add(tg_types.InlineKeyboardButton("‹ К панели", callback_data="back_main"))

    try:
        bot.edit_message_text(
            text, call.message.chat.id, call.message.message_id,
            parse_mode="Markdown", reply_markup=kb,
        )
    except Exception:
        bot.send_message(call.message.chat.id, text, parse_mode="Markdown", reply_markup=kb)


@bot.callback_query_handler(func=lambda c: c.data == "history")
def cb_history(call):
    if not is_admin(call.from_user.id):
        return
    cfg = load_config()
    history = cfg.get("history", [])
    if not history:
        bot.answer_callback_query(call.id, "История пуста")
        return
    lines = []
    for entry in reversed(history[-20:]):
        t = entry.get("type", "?")
        ts = entry.get("time", "")
        if t == "code":
            lines.append(f"🔑 `{entry.get('account','')}` → {entry.get('buyer','')} ({ts})")
        elif t == "deal":
            lines.append(f"💰 {entry.get('item','')} от {entry.get('buyer','')} — {entry.get('price',0):.2f}₽ ({ts})")
        elif t == "auto_confirm":
            lines.append(f"✅ Подтверждение `{entry.get('deal_id','')}` ({ts})")
    text = "📜 *Последние события:*\n\n" + "\n".join(lines)
    kb = tg_types.InlineKeyboardMarkup()
    kb.add(tg_types.InlineKeyboardButton("‹ К аналитике", callback_data="analytics"))
    try:
        bot.edit_message_text(
            text, call.message.chat.id, call.message.message_id,
            parse_mode="Markdown", reply_markup=kb,
        )
    except Exception:
        bot.send_message(call.message.chat.id, text, parse_mode="Markdown", reply_markup=kb)


@bot.callback_query_handler(func=lambda c: c.data == "analytics")
def cb_analytics(call):
    if not is_admin(call.from_user.id):
        return
    send_analytics(call.message.chat.id, call.message.message_id)


@bot.callback_query_handler(func=lambda c: c.data and c.data.startswith("stats:"))
def cb_stats_period(call):
    if not is_admin(call.from_user.id):
        return
    period = call.data.split(":", 1)[1]
    if period not in ("24h", "7d", "30d", "all"):
        period = "24h"
    send_analytics(call.message.chat.id, call.message.message_id, period=period)


@bot.callback_query_handler(func=lambda c: c.data == "proxy_menu")
def cb_proxy_menu(call):
    if not is_admin(call.from_user.id):
        return
    cfg = load_config()
    proxy = cfg.get("playerok_proxy", "")
    text = "🔐 *Прокси*\n\n"
    if proxy:
        text += f"• Активный: `{proxy}`\n"
    else:
        text += "• Нет активного прокси\n"
    text += "\nУстановить: `/proxy user:pass@ip:port`\nУбрать: `/proxy off`"
    kb = tg_types.InlineKeyboardMarkup()
    kb.add(tg_types.InlineKeyboardButton("‹ К панели", callback_data="back_main"))
    try:
        bot.edit_message_text(
            text, call.message.chat.id, call.message.message_id,
            parse_mode="Markdown", reply_markup=kb,
        )
    except Exception:
        bot.send_message(call.message.chat.id, text, parse_mode="Markdown", reply_markup=kb)


@bot.callback_query_handler(func=lambda c: c.data == "profile_refresh")
def cb_profile_refresh(call):
    if not is_admin(call.from_user.id):
        return
    try:
        if playerok_acc:
            global playerok_status
            playerok_acc.get()
            # Update status dict from refreshed account data without recreating listener
            balance_val = None
            rating_val = None
            reviews = 0
            items_total = 0
            deals_in_total = 0
            deals_in_finished = 0
            try:
                if hasattr(playerok_acc, 'balance') and playerok_acc.balance:
                    balance_val = playerok_acc.balance.value / 100 if hasattr(playerok_acc.balance, 'value') else None
                if hasattr(playerok_acc, 'stats') and playerok_acc.stats:
                    if hasattr(playerok_acc.stats, 'items'):
                        items_total = playerok_acc.stats.items.total
                    if hasattr(playerok_acc.stats, 'deals') and playerok_acc.stats.deals:
                        if hasattr(playerok_acc.stats.deals, 'incoming'):
                            deals_in_total = playerok_acc.stats.deals.incoming.total
                            deals_in_finished = playerok_acc.stats.deals.incoming.finished
                if hasattr(playerok_acc, 'rating'):
                    rating_val = playerok_acc.rating
                if hasattr(playerok_acc, 'reviews_count'):
                    reviews = playerok_acc.reviews_count
            except Exception:
                pass
            playerok_status = {
                "connected": True,
                "last_sync": datetime.now().strftime("%d.%m.%Y %H:%M:%S"),
                "error": None,
                "username": playerok_acc.username,
                "email": getattr(playerok_acc, 'email', None),
                "balance": balance_val,
                "rating": rating_val,
                "reviews_count": reviews,
                "items_total": items_total,
                "deals_incoming_total": deals_in_total,
                "deals_incoming_finished": deals_in_finished,
            }
    except Exception:
        pass
    send_profile(call.message.chat.id, call.message.message_id)


@bot.callback_query_handler(func=lambda c: c.data == "prof:notifications")
def cb_notifications(call):
    if not is_admin(call.from_user.id):
        return
    cfg = load_config()
    kb = tg_types.InlineKeyboardMarkup()
    notif_keys = [
        ("notify_new_message", "💬 Новые сообщения"),
        ("notify_new_deal", "💰 Новые сделки"),
        ("notify_deal_confirmed", "✅ Подтверждения"),
        ("notify_deal_problem", "⚠️ Проблемы"),
        ("notify_code_sent", "🔑 Отправка кодов"),
    ]
    for key, label in notif_keys:
        icon = "🟢" if cfg.get(key) else "🔴"
        kb.add(tg_types.InlineKeyboardButton(f"{icon} {label}", callback_data=f"toggle:{key}"))
    kb.add(tg_types.InlineKeyboardButton("‹ К профилю", callback_data="prof_back"))
    try:
        bot.edit_message_text(
            "🔔 *Уведомления:*",
            call.message.chat.id, call.message.message_id,
            parse_mode="Markdown", reply_markup=kb,
        )
    except Exception:
        pass


@bot.callback_query_handler(func=lambda c: c.data == "prof_back")
def cb_prof_back(call):
    if not is_admin(call.from_user.id):
        return
    send_profile(call.message.chat.id, call.message.message_id)


# ─── Автонастройки callbacks ───

@bot.callback_query_handler(func=lambda c: c.data.startswith("as:"))
def cb_autosetting(call):
    if not is_admin(call.from_user.id):
        return
    key = call.data.split(":", 1)[1]
    cfg = load_config()

    if key == "auto_code":
        icon = "🟢" if cfg.get("auto_code") else "🔴"
        text = f"📦 *Автовыдача кодов:* {icon}\n\nКогда покупатель пишет `!code <ник>` — бот автоматически генерирует и отправляет Steam Guard код."
        kb = tg_types.InlineKeyboardMarkup()
        kb.add(tg_types.InlineKeyboardButton(f"{icon} Вкл/Выкл", callback_data="toggle:auto_code"))
        kb.add(tg_types.InlineKeyboardButton("‹ Назад", callback_data="as_back"))

    elif key == "auto_responder":
        icon = "🟢" if cfg.get("auto_responder") else "🔴"
        resp = cfg.get("auto_responses", {})
        resp_text = "\n".join(f"• `{k}` → {v}" for k, v in list(resp.items())[:10])
        text = f"🤖 *Автоответчик:* {icon}\n\nОтвечает на ключевые слова:\n{resp_text}\n\nДобавить: `/addresponse <триггер> | <ответ>`\nУдалить: `/delresponse <триггер>`"
        kb = tg_types.InlineKeyboardMarkup()
        kb.add(tg_types.InlineKeyboardButton(f"{icon} Вкл/Выкл", callback_data="toggle:auto_responder"))
        kb.add(tg_types.InlineKeyboardButton("‹ Назад", callback_data="as_back"))

    elif key == "greeting":
        icon = "🟢" if cfg.get("auto_greeting") else "🔴"
        gt = cfg.get("greeting_text", "")
        text = f"👋 *Приветствие:* {icon}\n\nТекст:\n`{gt}`\n\nИзменить: `/greeting <текст>`"
        kb = tg_types.InlineKeyboardMarkup()
        kb.add(tg_types.InlineKeyboardButton(f"{icon} Вкл/Выкл", callback_data="toggle:auto_greeting"))
        kb.add(tg_types.InlineKeyboardButton("‹ Назад", callback_data="as_back"))

    elif key == "ignore_reminder":
        icon = "🟢" if cfg.get("ignore_reminder") else "🔴"
        mins = cfg.get("ignore_reminder_minutes", 10)
        rt = cfg.get("ignore_reminder_text", "")
        text = f"⏰ *Напоминание при игноре:* {icon}\n\nЧерез {mins} мин если покупатель не отвечает.\nТекст: `{rt}`\n\nИзменить: `/ignoretext <текст>`\nИнтервал: `/ignoretime <минуты>`"
        kb = tg_types.InlineKeyboardMarkup()
        kb.add(tg_types.InlineKeyboardButton(f"{icon} Вкл/Выкл", callback_data="toggle:ignore_reminder"))
        kb.add(tg_types.InlineKeyboardButton("‹ Назад", callback_data="as_back"))

    elif key == "confirm_reminder":
        icon = "🟢" if cfg.get("confirm_reminder") else "🔴"
        mins = cfg.get("confirm_reminder_minutes", 30)
        rt = cfg.get("confirm_reminder_text", "")
        text = f"📦 *Напоминание о подтверждении:* {icon}\n\nЧерез {mins} мин после отправки.\nТекст: `{rt}`\n\nИзменить: `/confirmtext <текст>`\nИнтервал: `/confirmtime <минуты>`"
        kb = tg_types.InlineKeyboardMarkup()
        kb.add(tg_types.InlineKeyboardButton(f"{icon} Вкл/Выкл", callback_data="toggle:confirm_reminder"))
        kb.add(tg_types.InlineKeyboardButton("‹ Назад", callback_data="as_back"))

    elif key == "after_confirm":
        at = cfg.get("after_confirm_text", "")
        text = f"✅ *Текст после подтверждения:*\n\n`{at}`\n\nИзменить: `/afterconfirm <текст>`"
        kb = tg_types.InlineKeyboardMarkup()
        kb.add(tg_types.InlineKeyboardButton("‹ Назад", callback_data="as_back"))

    elif key == "auto_confirm":
        icon = "🟢" if cfg.get("auto_confirm") else "🔴"
        text = f"🤝 *Автоподтверждение заказов:* {icon}\n\nАвтоматически подтверждает выполнение сделки после оплаты."
        kb = tg_types.InlineKeyboardMarkup()
        kb.add(tg_types.InlineKeyboardButton(f"{icon} Вкл/Выкл", callback_data="toggle:auto_confirm"))
        kb.add(tg_types.InlineKeyboardButton("‹ Назад", callback_data="as_back"))

    elif key == "auto_restore":
        icon = "🟢" if cfg.get("auto_restore") else "🔴"
        interval = cfg.get("auto_restore_interval", 30)
        expired_icon = "🟢" if cfg.get("auto_restore_expired", True) else "🔴"
        text = (
            f"🔄 *Автовосстановление лотов:* {icon}\n\n"
            f"Автоматически восстанавливает лоты после продажи.\n\n"
            f"⏱ Интервал проверки: {interval} мин.\n"
            f"{expired_icon} Восстанавливать истекшие: {'да' if cfg.get('auto_restore_expired', True) else 'нет'}\n\n"
            f"Изменить интервал: `/restoreinterval <минуты>`"
        )
        kb = tg_types.InlineKeyboardMarkup()
        kb.add(tg_types.InlineKeyboardButton(f"{icon} Вкл/Выкл", callback_data="toggle:auto_restore"))
        kb.add(tg_types.InlineKeyboardButton(
            f"{expired_icon} Восстанавливать истекшие",
            callback_data="toggle:auto_restore_expired",
        ))
        kb.add(tg_types.InlineKeyboardButton(
            f"⏱ Интервал: {interval} мин.",
            callback_data="restore_interval",
        ))
        kb.add(tg_types.InlineKeyboardButton(
            "🔄 Восстановить сейчас",
            callback_data="restore_now",
        ))
        kb.add(tg_types.InlineKeyboardButton("‹ Назад", callback_data="as_back"))

    elif key == "auto_bump":
        icon = "🟢" if cfg.get("auto_bump") else "🔴"
        interval = cfg.get("auto_bump_interval", 30)
        text = f"🚀 *Автоподнятие лотов:* {icon}\n\nИнтервал: {interval} мин.\n\nИзменить интервал: `/bumpinterval <минуты>`"
        kb = tg_types.InlineKeyboardMarkup()
        kb.add(tg_types.InlineKeyboardButton(f"{icon} Вкл/Выкл", callback_data="toggle:auto_bump"))
        kb.add(tg_types.InlineKeyboardButton("‹ Назад", callback_data="as_back"))
    else:
        return

    try:
        bot.edit_message_text(
            text, call.message.chat.id, call.message.message_id,
            parse_mode="Markdown", reply_markup=kb,
        )
    except Exception:
        bot.send_message(call.message.chat.id, text, parse_mode="Markdown", reply_markup=kb)


@bot.callback_query_handler(func=lambda c: c.data == "as_back")
def cb_as_back(call):
    if not is_admin(call.from_user.id):
        return
    send_autosettings(call.message.chat.id, call.message.message_id)


@bot.callback_query_handler(func=lambda c: c.data.startswith("getcode:"))
def cb_getcode(call):
    if not is_admin(call.from_user.id):
        return
    if not _plugins.is_enabled("steam_guard", load_config()):
        try:
            bot.answer_callback_query(call.id, "⚠️ Плагин Steam Guard выключен", show_alert=True)
        except Exception:
            pass
        return
    name = call.data.split(":", 1)[1]
    code = generate_code(name)
    if code:
        remaining = seconds_until_code_change()
        bot.answer_callback_query(call.id, f"Код: {code} ({remaining}с)")
        bot.send_message(call.message.chat.id, f"🔐 `{name}`: `{code}`\n⏱ {remaining} сек", parse_mode="Markdown")
    else:
        bot.answer_callback_query(call.id, "Не найден")


@bot.callback_query_handler(func=lambda c: c.data.startswith("confirm_deal:"))
def cb_confirm_deal(call):
    if not is_admin(call.from_user.id):
        return
    deal_id = call.data.split(":", 1)[1]
    if not playerok_acc:
        bot.answer_callback_query(call.id, "Playerok не подключён")
        return
    try:
        playerok_acc.update_deal(deal_id, ItemDealStatuses.SENT)
        bot.answer_callback_query(call.id, "Подтверждено!")
        bot.send_message(call.message.chat.id, f"✅ Сделка `{deal_id}` подтверждена", parse_mode="Markdown")
    except Exception as exc:
        bot.answer_callback_query(call.id, f"Ошибка: {exc}")


@bot.callback_query_handler(func=lambda c: c.data.startswith("rollback_deal:"))
def cb_rollback_deal(call):
    if not is_admin(call.from_user.id):
        return
    deal_id = call.data.split(":", 1)[1]
    if not playerok_acc:
        bot.answer_callback_query(call.id, "Playerok не подключён")
        return
    try:
        playerok_acc.update_deal(deal_id, ItemDealStatuses.ROLLED_BACK)
        bot.answer_callback_query(call.id, "Возврат оформлен")
        bot.send_message(call.message.chat.id, f"↩️ Сделка `{deal_id}` — возврат", parse_mode="Markdown")
    except Exception as exc:
        bot.answer_callback_query(call.id, f"Ошибка: {exc}")


@bot.callback_query_handler(func=lambda c: c.data.startswith("reply:"))
def cb_reply(call):
    if not is_admin(call.from_user.id):
        return
    chat_id = call.data.split(":", 1)[1]
    bot.answer_callback_query(call.id)
    msg = bot.send_message(call.message.chat.id, f"✏️ Напиши ответ для чата `{chat_id}`:", parse_mode="Markdown")
    bot.register_next_step_handler(msg, process_reply, chat_id)


@bot.callback_query_handler(func=lambda c: c.data.startswith("qr:"))
def cb_quick_reply(call):
    """Быстрый ответ — отправляет один из шаблонов quick_replies прямо в чат."""
    if not is_admin(call.from_user.id):
        return
    try:
        _, chat_id, idx = call.data.split(":", 2)
        i = int(idx)
    except Exception:
        bot.answer_callback_query(call.id, "bad data")
        return
    cfg = load_config()
    templates = cfg.get("quick_replies") or []
    if i < 0 or i >= len(templates):
        bot.answer_callback_query(call.id, "шаблон не найден")
        return
    text = templates[i]
    if not playerok_acc:
        bot.answer_callback_query(call.id, "Playerok не подключён")
        return
    try:
        playerok_acc.send_message(chat_id=chat_id, text=text)
        bot.answer_callback_query(call.id, "✅ Отправлено")
        try:
            bot.send_message(
                ADMIN_ID,
                f"⚡ Быстрый ответ в чат `{chat_id}`:\n_{text}_",
                parse_mode="Markdown",
            )
        except Exception:
            pass
    except Exception as exc:
        bot.answer_callback_query(call.id, f"Ошибка: {exc}", show_alert=True)


def process_reply(message, chat_id: str):
    if not playerok_acc:
        bot.send_message(message.chat.id, "❌ Playerok не подключён")
        return
    try:
        playerok_acc.send_message(chat_id=chat_id, text=message.text)
        bot.send_message(message.chat.id, f"✅ Отправлено в чат `{chat_id}`", parse_mode="Markdown")
    except Exception as exc:
        bot.send_message(message.chat.id, f"❌ Ошибка: {exc}")


@bot.callback_query_handler(func=lambda c: c.data.startswith("pickcode:"))
def cb_pickcode(call):
    if not is_admin(call.from_user.id):
        return
    chat_id = call.data.split(":", 1)[1]
    names = get_account_names()
    if not names:
        bot.answer_callback_query(call.id, "Нет аккаунтов")
        return
    kb = tg_types.InlineKeyboardMarkup(row_width=2)
    for n in names:
        kb.add(tg_types.InlineKeyboardButton(f"🔑 {n}", callback_data=f"sendcode:{chat_id}:{n}"))
    kb.add(tg_types.InlineKeyboardButton("‹ Отмена", callback_data=f"chat:{chat_id}"))
    try:
        bot.edit_message_text(
            "🔑 Выбери аккаунт для отправки кода:",
            call.message.chat.id, call.message.message_id, reply_markup=kb,
        )
    except Exception:
        bot.send_message(call.message.chat.id, "🔑 Выбери аккаунт:", reply_markup=kb)


@bot.callback_query_handler(func=lambda c: c.data.startswith("sendcode:"))
def cb_sendcode(call):
    if not is_admin(call.from_user.id):
        return
    parts = call.data.split(":", 2)
    chat_id = parts[1]
    acc_name = parts[2]
    if not playerok_acc:
        bot.answer_callback_query(call.id, "Playerok не подключён")
        return
    code = generate_code(acc_name)
    if not code:
        bot.answer_callback_query(call.id, "Аккаунт не найден")
        return
    try:
        remaining = seconds_until_code_change()
        playerok_acc.send_message(
            chat_id=chat_id,
            text=f"🔐 Steam Guard код для {acc_name}:\n{code}\n⏱ Действует ещё {remaining} сек."
        )
        bot.answer_callback_query(call.id, f"Код {code} отправлен!")
        bot.send_message(call.message.chat.id, f"✅ Код `{code}` отправлен в чат `{chat_id}`", parse_mode="Markdown")
        cfg = load_config()
        cfg["stats"]["codes_sent"] += 1
        cfg["history"].append({
            "type": "code", "account": acc_name, "buyer": "manual", "chat_id": chat_id,
            "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        })
        save_config(cfg)
    except Exception as exc:
        bot.answer_callback_query(call.id, f"Ошибка: {exc}")


@bot.callback_query_handler(func=lambda c: c.data == "bump_interval")
def cb_bump_interval(call):
    if not is_admin(call.from_user.id):
        return
    msg = bot.send_message(call.message.chat.id, "⏱ Введи интервал поднятия (в минутах):")
    bot.register_next_step_handler(msg, process_bump_interval)


def process_bump_interval(message):
    try:
        val = int(message.text)
        if val < 5:
            val = 5
        cfg = load_config()
        cfg["auto_bump_interval"] = val
        save_config(cfg)
        bot.send_message(message.chat.id, f"✅ Интервал поднятия: {val} мин")
    except ValueError:
        bot.send_message(message.chat.id, "❌ Введи число")


@bot.callback_query_handler(func=lambda c: c.data == "restore_interval")
def cb_restore_interval(call):
    if not is_admin(call.from_user.id):
        return
    msg = bot.send_message(call.message.chat.id, "⏱ Введи интервал восстановления (в минутах):")
    bot.register_next_step_handler(msg, process_restore_interval)


def process_restore_interval(message):
    try:
        val = int(message.text)
        if val < 5:
            val = 5
        cfg = load_config()
        cfg["auto_restore_interval"] = val
        save_config(cfg)
        bot.send_message(message.chat.id, f"✅ Интервал восстановления: {val} мин")
    except ValueError:
        bot.send_message(message.chat.id, "❌ Введи число")


@bot.callback_query_handler(func=lambda c: c.data == "restore_now")
def cb_restore_now(call):
    if not is_admin(call.from_user.id):
        return
    bot.answer_callback_query(call.id, "🔄 Запуск восстановления...")
    try:
        restored = _do_restore_scan()
        if restored > 0:
            bot.send_message(
                call.message.chat.id,
                f"✅ Восстановлено лотов: {restored}",
            )
        else:
            bot.send_message(
                call.message.chat.id,
                "ℹ️ Нет лотов для восстановления.",
            )
    except Exception as exc:
        bot.send_message(
            call.message.chat.id,
            f"❌ Ошибка: {exc}",
        )


# ═══════════════════════════════════════════════════════════════
#  TELEGRAM — ТЕКСТОВЫЕ КОМАНДЫ
# ═══════════════════════════════════════════════════════════════

@bot.message_handler(commands=["cookies"])
@admin_only
def cmd_cookies(message):
    parts = message.text.split(maxsplit=1)
    if len(parts) < 2:
        bot.send_message(
            message.chat.id,
            "🍪 *Установка куки Playerok:*\n\n"
            "`/cookies <строка_куки>`\n\n"
            "Как получить:\n"
            "1. Установи EditThisCookie в Chrome\n"
            "2. Зайди на playerok.com\n"
            "3. Открой EditThisCookie\n"
            "4. Скопируй в формате:\n`__ddg3=...;token=...;__ddg5_=...`\n\n"
            "Или вставь полную строку куки из DevTools (F12 → Application → Cookies).",
            parse_mode="Markdown",
        )
        return
    cfg = load_config()
    cfg["playerok_cookies"] = parts[1].strip()
    save_config(cfg)
    if init_playerok():
        start_playerok_thread()
        bot.send_message(message.chat.id, f"✅ Подключён как: *{playerok_acc.username}*", parse_mode="Markdown")
    else:
        bot.send_message(message.chat.id, f"❌ Ошибка: {playerok_status.get('error')}")


@bot.message_handler(commands=["useragent"])
@admin_only
def cmd_useragent(message):
    parts = message.text.split(maxsplit=1)
    if len(parts) < 2:
        cfg = load_config()
        bot.send_message(message.chat.id, f"User-Agent: `{cfg.get('playerok_user_agent', 'по умолчанию')}`\n\n`/useragent <строка>`", parse_mode="Markdown")
        return
    cfg = load_config()
    cfg["playerok_user_agent"] = parts[1].strip()
    save_config(cfg)
    bot.send_message(message.chat.id, "✅ User-Agent обновлён.")


@bot.message_handler(commands=["proxy"])
@admin_only
def cmd_proxy(message):
    parts = message.text.split(maxsplit=1)
    if len(parts) < 2:
        cfg = load_config()
        p = cfg.get("playerok_proxy", "")
        bot.send_message(
            message.chat.id,
            f"Прокси: `{p or 'нет'}`\n\n"
            f"Формат: `/proxy user:pass@ip:port`\n"
            f"Пример: `/proxy kBoryP:1msy1g@213.166.74.99:9656`\n"
            f"Выключить: `/proxy off`\n\n"
            f"⚠️ Без `http://` — просто `user:pass@ip:port`",
            parse_mode="Markdown",
        )
        return
    cfg = load_config()
    val = parts[1].strip()
    if val.lower() == "off":
        cfg["playerok_proxy"] = ""
    else:
        # Нормализуем: убираем http(s):// если есть
        val = val.replace("https://", "").replace("http://", "").strip()
        # Проверяем формат: должен быть user:pass@ip:port или ip:port
        if "@" in val:
            # user:pass@ip:port
            auth, host = val.rsplit("@", 1)
            if ":" not in auth or ":" not in host:
                bot.send_message(
                    message.chat.id,
                    "❌ Неверный формат!\nПравильно: `user:pass@ip:port`\nПример: `kBoryP:1msy1g@213.166.74.99:9656`",
                    parse_mode="Markdown",
                )
                return
        cfg["playerok_proxy"] = val
    save_config(cfg)
    _proxy_status = cfg['playerok_proxy'] or 'выключен'
    bot.send_message(message.chat.id, f"✅ Прокси: `{_proxy_status}`", parse_mode="Markdown")


@bot.message_handler(commands=["logs"])
@admin_only
def cmd_logs(message):
    parts = message.text.split()
    n = 30
    if len(parts) > 1:
        try:
            n = int(parts[1])
        except (ValueError, TypeError):
            pass
    _send_logs(message.chat.id, n)


# Patterns to redact from log output sent via Telegram
_SENSITIVE_PATTERNS = re.compile(
    r'(token[=:]\s*)([^\s&;,\"\']+)'
    r'|(authorization[=:]\s*)([^\s&;,\"\']+)'
    r'|(cookie[=:]\s*)([^\s&;,\"\']+)'
    r'|(\b\w+:\w+@[\d.]+:\d+)',
    re.IGNORECASE,
)


def _redact_sensitive(line: str) -> str:
    """Mask tokens, auth headers, and credential-like patterns in log lines."""
    return _SENSITIVE_PATTERNS.sub(lambda m: m.group(0)[:6] + "***REDACTED***", line)


def _send_logs(chat_id: int, n: int = 30):
    """Read last N lines from LOG_FILE and send to admin."""
    n = max(1, min(n, 200))
    try:
        if not os.path.exists(LOG_FILE):
            bot.send_message(chat_id, "\u274c \u0424\u0430\u0439\u043b \u043b\u043e\u0433\u0430 \u043d\u0435 \u043d\u0430\u0439\u0434\u0435\u043d.")
            return
        with open(LOG_FILE, "r", encoding="utf-8", errors="replace") as f:
            lines = f.readlines()
        lines = lines[-n:]
        # Truncate long lines and redact sensitive patterns
        truncated_lines = []
        for line in lines:
            line = line.rstrip("\n")
            line = _redact_sensitive(line)
            if len(line) > 200:
                line = line[:200] + "..."
            truncated_lines.append(line)
        full_text = "\n".join(truncated_lines)
        # Split into chunks of max 4000 chars
        chunks = []
        while full_text:
            if len(full_text) <= 4000:
                chunks.append(full_text)
                break
            # Find a good split point
            split_at = full_text.rfind("\n", 0, 4000)
            if split_at <= 0:
                split_at = 4000
            chunks.append(full_text[:split_at])
            full_text = full_text[split_at:].lstrip("\n")

        for chunk in chunks:
            bot.send_message(chat_id, f"```\n{chunk}\n```", parse_mode="Markdown")

        kb = tg_types.InlineKeyboardMarkup()
        kb.row(
            tg_types.InlineKeyboardButton("10", callback_data="logs:10"),
            tg_types.InlineKeyboardButton("30", callback_data="logs:30"),
            tg_types.InlineKeyboardButton("50", callback_data="logs:50"),
            tg_types.InlineKeyboardButton("100", callback_data="logs:100"),
        )
        bot.send_message(chat_id, "\U0001f4cb \u0412\u044b\u0431\u0435\u0440\u0438\u0442\u0435 \u043a\u043e\u043b-\u0432\u043e \u0441\u0442\u0440\u043e\u043a:", reply_markup=kb)
    except Exception as exc:
        bot.send_message(chat_id, f"\u274c \u041e\u0448\u0438\u0431\u043a\u0430: {exc}")


@bot.callback_query_handler(func=lambda c: c.data and c.data.startswith("logs:"))
def cb_logs(call):
    if not is_admin(call.from_user.id):
        return
    try:
        n = int(call.data.split(":")[1])
    except (ValueError, IndexError):
        n = 30
    _send_logs(call.message.chat.id, n)


@bot.message_handler(commands=["link"])
@admin_only
def cmd_link(message):
    parts = message.text.split()
    if len(parts) < 3:
        bot.send_message(message.chat.id, "🔗 `/link <chat_id> <имя_аккаунта>`\n\nChat ID видно в уведомлениях.", parse_mode="Markdown")
        return
    chat_id = parts[1]
    acc_name = parts[2]
    names_lower = {n.lower(): n for n in get_account_names()}
    if acc_name.lower() not in names_lower:
        bot.send_message(message.chat.id, f"❌ Аккаунт `{acc_name}` не найден.", parse_mode="Markdown")
        return
    cfg = load_config()
    cfg.setdefault("account_map", {})[chat_id] = names_lower[acc_name.lower()]
    save_config(cfg)
    bot.send_message(message.chat.id, f"✅ Чат `{chat_id}` → `{names_lower[acc_name.lower()]}`", parse_mode="Markdown")


@bot.message_handler(commands=["unlink"])
@admin_only
def cmd_unlink(message):
    parts = message.text.split()
    if len(parts) < 2:
        bot.send_message(message.chat.id, "`/unlink <chat_id>`", parse_mode="Markdown")
        return
    cfg = load_config()
    cid = parts[1]
    if cid in cfg.get("account_map", {}):
        del cfg["account_map"][cid]
        save_config(cfg)
        bot.send_message(message.chat.id, f"✅ Привязка `{cid}` удалена.", parse_mode="Markdown")
    else:
        bot.send_message(message.chat.id, "❌ Нет такой привязки.")


@bot.message_handler(commands=["linkall"])
@admin_only
def cmd_linkall(message):
    parts = message.text.split()
    if len(parts) < 2:
        bot.send_message(message.chat.id, "`/linkall <имя_аккаунта>`", parse_mode="Markdown")
        return
    acc_name = parts[1]
    names_lower = {n.lower(): n for n in get_account_names()}
    if acc_name.lower() not in names_lower:
        bot.send_message(message.chat.id, f"❌ Аккаунт `{acc_name}` не найден.", parse_mode="Markdown")
        return
    cfg = load_config()
    cfg["default_account"] = names_lower[acc_name.lower()]
    save_config(cfg)
    bot.send_message(message.chat.id, f"✅ `{names_lower[acc_name.lower()]}` — аккаунт по умолчанию для всех чатов.", parse_mode="Markdown")


@bot.message_handler(commands=["code"])
@admin_only
def cmd_code(message):
    if not _plugins.is_enabled("steam_guard", load_config()):
        bot.send_message(message.chat.id, "⚠️ Плагин *Steam Guard коды* выключен.", parse_mode="Markdown")
        return
    parts = message.text.split()
    if len(parts) < 2:
        names = get_account_names()
        if not names:
            bot.send_message(message.chat.id, "📭 Нет аккаунтов.")
            return
        kb = tg_types.InlineKeyboardMarkup(row_width=2)
        for n in names:
            kb.add(tg_types.InlineKeyboardButton(f"🔑 {n}", callback_data=f"getcode:{n}"))
        bot.send_message(message.chat.id, "🔑 Выбери аккаунт:", reply_markup=kb)
        return
    code = generate_code(parts[1])
    if code:
        remaining = seconds_until_code_change()
        bot.send_message(message.chat.id, f"🔐 `{parts[1]}`: `{code}`\n⏱ {remaining} сек", parse_mode="Markdown")
    else:
        bot.send_message(message.chat.id, f"❌ `{parts[1]}` не найден.", parse_mode="Markdown")


@bot.message_handler(commands=["sendcode"])
@admin_only
def cmd_sendcode(message):
    if not _plugins.is_enabled("steam_guard", load_config()):
        bot.send_message(message.chat.id, "⚠️ Плагин *Steam Guard коды* выключен.", parse_mode="Markdown")
        return
    parts = message.text.split()
    if len(parts) < 3:
        bot.send_message(message.chat.id, "`/sendcode <chat_id> <аккаунт>`", parse_mode="Markdown")
        return
    if not playerok_acc or not playerok_status.get("connected"):
        bot.send_message(message.chat.id, "❌ Playerok не подключён.")
        return
    code = generate_code(parts[2])
    if not code:
        bot.send_message(message.chat.id, f"❌ `{parts[2]}` не найден.", parse_mode="Markdown")
        return
    try:
        remaining = seconds_until_code_change()
        playerok_acc.send_message(chat_id=parts[1], text=f"🔐 Steam Guard код для {parts[2]}:\n{code}\n⏱ Действует ещё {remaining} сек.")
        bot.send_message(message.chat.id, f"✅ `{code}` → чат `{parts[1]}`", parse_mode="Markdown")
    except Exception as exc:
        bot.send_message(message.chat.id, f"❌ {exc}")


@bot.message_handler(commands=["msg"])
@admin_only
def cmd_msg(message):
    parts = message.text.split(maxsplit=2)
    if len(parts) < 3:
        bot.send_message(message.chat.id, "`/msg <chat_id> <текст>`", parse_mode="Markdown")
        return
    if not playerok_acc or not playerok_status.get("connected"):
        bot.send_message(message.chat.id, "❌ Playerok не подключён.")
        return
    try:
        playerok_acc.send_message(chat_id=parts[1], text=parts[2])
        bot.send_message(message.chat.id, f"✅ Отправлено в `{parts[1]}`", parse_mode="Markdown")
    except Exception as exc:
        bot.send_message(message.chat.id, f"❌ {exc}")


@bot.message_handler(commands=["greeting"])
@admin_only
def cmd_greeting(message):
    parts = message.text.split(maxsplit=1)
    if len(parts) < 2:
        cfg = load_config()
        bot.send_message(message.chat.id, f"👋 Текст: `{cfg.get('greeting_text', '')}`\n\n`/greeting <текст>`", parse_mode="Markdown")
        return
    cfg = load_config()
    cfg["greeting_text"] = parts[1].strip()
    save_config(cfg)
    bot.send_message(message.chat.id, "✅ Приветствие обновлено.")


@bot.message_handler(commands=["afterconfirm"])
@admin_only
def cmd_afterconfirm(message):
    parts = message.text.split(maxsplit=1)
    if len(parts) < 2:
        cfg = load_config()
        bot.send_message(message.chat.id, f"✅ Текст: `{cfg.get('after_confirm_text', '')}`\n\n`/afterconfirm <текст>`", parse_mode="Markdown")
        return
    cfg = load_config()
    cfg["after_confirm_text"] = parts[1].strip()
    save_config(cfg)
    bot.send_message(message.chat.id, "✅ Обновлено.")


@bot.message_handler(commands=["ignoretext"])
@admin_only
def cmd_ignoretext(message):
    parts = message.text.split(maxsplit=1)
    cfg = load_config()
    if len(parts) < 2:
        bot.send_message(message.chat.id, f"Текст: `{cfg.get('ignore_reminder_text', '')}`\n\n`/ignoretext <текст>`", parse_mode="Markdown")
        return
    cfg["ignore_reminder_text"] = parts[1].strip()
    save_config(cfg)
    bot.send_message(message.chat.id, "✅ Обновлено.")


@bot.message_handler(commands=["ignoretime"])
@admin_only
def cmd_ignoretime(message):
    parts = message.text.split()
    cfg = load_config()
    if len(parts) < 2:
        bot.send_message(message.chat.id, f"Интервал: {cfg.get('ignore_reminder_minutes', 10)} мин\n\n`/ignoretime <мин>`", parse_mode="Markdown")
        return
    try:
        cfg["ignore_reminder_minutes"] = int(parts[1])
        save_config(cfg)
        bot.send_message(message.chat.id, f"✅ Интервал: {parts[1]} мин")
    except ValueError:
        bot.send_message(message.chat.id, "❌ Введи число")


@bot.message_handler(commands=["confirmtext"])
@admin_only
def cmd_confirmtext(message):
    parts = message.text.split(maxsplit=1)
    cfg = load_config()
    if len(parts) < 2:
        bot.send_message(message.chat.id, f"Текст: `{cfg.get('confirm_reminder_text', '')}`\n\n`/confirmtext <текст>`", parse_mode="Markdown")
        return
    cfg["confirm_reminder_text"] = parts[1].strip()
    save_config(cfg)
    bot.send_message(message.chat.id, "✅ Обновлено.")


@bot.message_handler(commands=["confirmtime"])
@admin_only
def cmd_confirmtime(message):
    parts = message.text.split()
    cfg = load_config()
    if len(parts) < 2:
        bot.send_message(message.chat.id, f"Интервал: {cfg.get('confirm_reminder_minutes', 30)} мин\n\n`/confirmtime <мин>`", parse_mode="Markdown")
        return
    try:
        cfg["confirm_reminder_minutes"] = int(parts[1])
        save_config(cfg)
        bot.send_message(message.chat.id, f"✅ Интервал: {parts[1]} мин")
    except ValueError:
        bot.send_message(message.chat.id, "❌ Введи число")


@bot.message_handler(commands=["bumpinterval"])
@admin_only
def cmd_bumpinterval(message):
    parts = message.text.split()
    cfg = load_config()
    if len(parts) < 2:
        bot.send_message(message.chat.id, f"Интервал: {cfg.get('auto_bump_interval', 30)} мин\n\n`/bumpinterval <мин>`", parse_mode="Markdown")
        return
    try:
        val = max(5, int(parts[1]))
        cfg["auto_bump_interval"] = val
        save_config(cfg)
        bot.send_message(message.chat.id, f"✅ Интервал поднятия: {val} мин")
    except ValueError:
        bot.send_message(message.chat.id, "❌ Введи число")


@bot.message_handler(commands=["restoreinterval"])
@admin_only
def cmd_restoreinterval(message):
    parts = message.text.split()
    cfg = load_config()
    if len(parts) < 2:
        bot.send_message(message.chat.id, f"Интервал: {cfg.get('auto_restore_interval', 30)} мин\n\n`/restoreinterval <мин>`", parse_mode="Markdown")
        return
    try:
        val = max(5, int(parts[1]))
        cfg["auto_restore_interval"] = val
        save_config(cfg)
        bot.send_message(message.chat.id, f"✅ Интервал восстановления: {val} мин")
    except ValueError:
        bot.send_message(message.chat.id, "❌ Введи число")


@bot.message_handler(commands=["addresponse"])
@admin_only
def cmd_addresponse(message):
    parts = message.text.split(maxsplit=1)
    if len(parts) < 2 or "|" not in parts[1]:
        bot.send_message(message.chat.id, "`/addresponse <триггер> | <ответ>`", parse_mode="Markdown")
        return
    trigger, response = parts[1].split("|", 1)
    cfg = load_config()
    cfg.setdefault("auto_responses", {})[trigger.strip().lower()] = response.strip()
    save_config(cfg)
    bot.send_message(message.chat.id, f"✅ `{trigger.strip()}` → `{response.strip()}`", parse_mode="Markdown")


@bot.message_handler(commands=["delresponse"])
@admin_only
def cmd_delresponse(message):
    parts = message.text.split(maxsplit=1)
    if len(parts) < 2:
        bot.send_message(message.chat.id, "`/delresponse <триггер>`", parse_mode="Markdown")
        return
    cfg = load_config()
    key = parts[1].strip().lower()
    if key in cfg.get("auto_responses", {}):
        del cfg["auto_responses"][key]
        save_config(cfg)
        bot.send_message(message.chat.id, f"✅ `{key}` удалён.", parse_mode="Markdown")
    else:
        bot.send_message(message.chat.id, "❌ Не найден.")


@bot.message_handler(commands=["keywords"])
@admin_only
def cmd_keywords(message):
    parts = message.text.split(maxsplit=1)
    cfg = load_config()
    if len(parts) < 2:
        kws = cfg.get("code_keywords", [])
        bot.send_message(message.chat.id, f"Ключевые слова: `{', '.join(kws)}`\n\n`/keywords <через запятую>`", parse_mode="Markdown")
        return
    new_kws = [kw.strip().lower() for kw in parts[1].split(",") if kw.strip()]
    cfg["code_keywords"] = new_kws
    save_config(cfg)
    bot.send_message(message.chat.id, f"✅ `{', '.join(new_kws)}`", parse_mode="Markdown")


@bot.message_handler(commands=["resetstats"])
@admin_only
def cmd_resetstats(message):
    cfg = load_config()
    cfg["stats"] = deepcopy(DEFAULT_CONFIG["stats"])
    cfg["stats"]["started_at"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    cfg["history"] = []
    save_config(cfg)
    bot.send_message(message.chat.id, "✅ Статистика сброшена.")


@bot.message_handler(commands=["help"])
@admin_only
def cmd_help(message):
    bot.send_message(
        message.chat.id,
        "📖 *Команды Playerok бота:*\n\n"
        "*Подключение:*\n"
        "/cookies — задать куки Playerok\n"
        "/useragent — задать User-Agent\n"
        "/proxy — задать прокси\n\n"
        "*Привязки:*\n"
        "/link — привязать аккаунт к чату\n"
        "/unlink — отвязать\n"
        "/linkall — один аккаунт для всех\n\n"
        "*Коды:*\n"
        "/code — получить код\n"
        "/sendcode — отправить код в чат\n\n"
        "*Сообщения:*\n"
        "/msg — написать в чат\n\n"
        "*Автонастройки:*\n"
        "/greeting — текст приветствия\n"
        "/afterconfirm — текст после подтверждения\n"
        "/ignoretext, /ignoretime — напоминание\n"
        "/confirmtext, /confirmtime — подтверждение\n"
        "/bumpinterval — интервал поднятия\n"
        "/restoreinterval — интервал восстановления\n"
        "/addresponse, /delresponse — автоответы\n"
        "/keywords — слова-триггеры кода\n\n"
        "*Прочее:*\n"
        "/resetstats — сброс статистики\n"
        "/start — панель управления",
        parse_mode="Markdown",
        reply_markup=menu_keyboard(),
    )


# ═══════════════════════════════════════════════════════════════
#  UPLOAD .maFile
# ═══════════════════════════════════════════════════════════════

@bot.message_handler(content_types=["document"])
@admin_only
def handle_document(message):
    doc = message.document
    if not doc.file_name:
        return
    if not _plugins.is_enabled("steam_guard", load_config()):
        bot.send_message(
            message.chat.id,
            "⚠️ Плагин *Steam Guard коды* выключен — загрузка .maFile отключена.",
            parse_mode="Markdown",
        )
        return

    if doc.file_name.endswith(".maFile"):
        file_info = bot.get_file(doc.file_id)
        data = bot.download_file(file_info.file_path)
        try:
            ma_data = json.loads(data.decode("utf-8"))
            if not ma_data.get("shared_secret"):
                bot.send_message(message.chat.id, "❌ В файле нет `shared_secret`.")
                return
            name = ma_data.get("account_name", doc.file_name.replace(".maFile", ""))
            folder = ACCOUNTS_FOLDER
            os.makedirs(folder, exist_ok=True)
            path = os.path.join(folder, doc.file_name)
            with open(path, "w", encoding="utf-8") as f:
                json.dump(ma_data, f, indent=2, ensure_ascii=False)
            if _db is not None:
                try:
                    _db.save_file(path)
                except Exception:
                    log.debug("db.save_file(maFile) failed", exc_info=True)
            bot.send_message(message.chat.id, f"✅ Аккаунт `{name}` добавлен!", parse_mode="Markdown")
        except Exception as exc:
            bot.send_message(message.chat.id, f"❌ Ошибка: {exc}")

    elif doc.file_name.endswith(".zip"):
        import zipfile
        import io
        file_info = bot.get_file(doc.file_id)
        data = bot.download_file(file_info.file_path)
        try:
            added = 0
            skipped = 0
            names_added = []
            with zipfile.ZipFile(io.BytesIO(data)) as zf:
                for zi in zf.infolist():
                    if zi.filename.endswith(".maFile") and not zi.is_dir():
                        try:
                            raw = zf.read(zi.filename)
                            ma = json.loads(raw.decode("utf-8"))
                            if not ma.get("shared_secret"):
                                skipped += 1
                                continue
                            fname = os.path.basename(zi.filename)
                            name = ma.get("account_name", fname.replace(".maFile", ""))
                            os.makedirs(ACCOUNTS_FOLDER, exist_ok=True)
                            path = os.path.join(ACCOUNTS_FOLDER, fname)
                            with open(path, "w", encoding="utf-8") as f:
                                json.dump(ma, f, indent=2, ensure_ascii=False)
                            if _db is not None:
                                try:
                                    _db.save_file(path)
                                except Exception:
                                    log.debug("db.save_file(maFile) failed", exc_info=True)
                            added += 1
                            names_added.append(name)
                        except Exception:
                            skipped += 1
            text = f"✅ Импорт: добавлено {added}"
            if names_added:
                text += "\n• " + "\n• ".join(names_added)
            if skipped:
                text += f"\n⚠️ Пропущено: {skipped}"
            bot.send_message(message.chat.id, text)
        except Exception as exc:
            bot.send_message(message.chat.id, f"❌ Ошибка: {exc}")


# ═══════════════════════════════════════════════════════════════
#  ЗАПУСК
# ═══════════════════════════════════════════════════════════════

def start_playerok_thread():
    global playerok_thread, playerok_running
    if playerok_thread and playerok_thread.is_alive():
        playerok_running = False
        time.sleep(2)
    playerok_thread = threading.Thread(target=playerok_loop, daemon=True)
    playerok_thread.start()


def start_background_threads():
    global online_thread, bump_thread
    online_thread = threading.Thread(target=permanent_online_loop, daemon=True)
    online_thread.start()
    bump_thread = threading.Thread(target=auto_bump_loop, daemon=True)
    bump_thread.start()
    restore_thread = threading.Thread(target=auto_restore_loop, daemon=True)
    restore_thread.start()
    summary_thread = threading.Thread(target=daily_summary_loop, daemon=True)
    summary_thread.start()
    # Prometheus /metrics — стартует только если включено в конфиге.
    if load_config().get("metrics_enabled"):
        metrics_thread = threading.Thread(target=metrics_loop, daemon=True,
                                          name="metrics-server")
        metrics_thread.start()


if __name__ == "__main__":
    try:
        log.info("=" * 50)
        log.info("Playerok Steam Guard Bot запускается")
        log.info("Python: %s", sys.version)
        log.info("Admin ID: %s", ADMIN_ID)

        # Postgres-бэкап: подключаемся, восстанавливаем файлы из БД, запускаем фон-sync.
        if _db is not None:
            try:
                if _db.init():
                    _db.hydrate([CONFIG_FILE, ACCOUNTS_FOLDER])
                    _db.start_sync_loop([CONFIG_FILE, ACCOUNTS_FOLDER])
            except Exception:
                log.exception("DB init failed — продолжаю без Postgres-бэкапа")

        cfg = load_config()
        save_config(cfg)

        # Поднимаем контекст плагинов и регистрируем их Telegram-хендлеры.
        _plugin_ctx = _plugins.PluginContext(
            playerok_acc=None,
            bot=bot,
            admin_id=ADMIN_ID,
            get_config=load_config,
            save_config=save_config,
            log=log,
        )
        _plugins.register_telegram_all(_plugin_ctx)
        _plugins.setup_all(_plugin_ctx)
        _plugins.start_background_all(_plugin_ctx)

        if cfg.get("playerok_cookies"):
            log.info("Куки найдены, подключаюсь к Playerok...")
            if init_playerok():
                start_playerok_thread()
            else:
                log.warning("Не удалось подключиться: %s", playerok_status.get("error"))
        else:
            log.info("Куки не заданы. Отправь /cookies в Telegram.")

        start_background_threads()
        log.info("Telegram бот запущен. Ожидаю сообщений...")
        bot.infinity_polling(timeout=60, long_polling_timeout=30)
    except Exception:
        error_msg = traceback.format_exc()
        log.error("БОТ УПАЛ!\n%s", error_msg)
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(f"\nБОТ УПАЛ!\n{error_msg}\n")
        raise
