"""Pytest fixtures для playerok_bot.

Ключевая мысль — все тесты бегают в изолированной CWD (`tmp_path`), и
storage плагинов туда же. Заодно patch'им модули, которых нет в
тестовом окружении (`telebot.types`, `playerokapi.enums`).
"""
from __future__ import annotations

import os
import sys
import types
from pathlib import Path

import pytest


ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))


@pytest.fixture(autouse=True)
def isolated_cwd(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    """Каждый тест запускается в свежей tmp директории."""
    monkeypatch.chdir(tmp_path)
    # Сбрасываем SQLite-флаг по умолчанию (если кто-то выставил выше)
    monkeypatch.delenv("PLAYEROK_USE_SQLITE", raising=False)
    # А также форсируем перезапуск SQLite-коннекта, чтобы тесты не делили БД
    if "plugins._sqlite_store" in sys.modules:
        sys.modules["plugins._sqlite_store"]._conn = None  # type: ignore[attr-defined]
    return tmp_path


@pytest.fixture
def stub_playerokapi(monkeypatch: pytest.MonkeyPatch):
    """Минимальный стаб playerokapi.enums.EventTypes — реальный модуль может
    отсутствовать в CI."""
    if "playerokapi" not in sys.modules:
        pkg = types.ModuleType("playerokapi")
        sys.modules["playerokapi"] = pkg
    if "playerokapi.enums" not in sys.modules:
        enums = types.ModuleType("playerokapi.enums")

        class EventTypes:
            NEW_MESSAGE = "NEW_MESSAGE"
            ITEM_PAID = "ITEM_PAID"
            ITEM_SENT = "ITEM_SENT"
            DEAL_CONFIRMED = "DEAL_CONFIRMED"
            DEAL_HAS_PROBLEM = "DEAL_HAS_PROBLEM"
            NEW_DEAL = "NEW_DEAL"

        class ItemDealStatuses:
            PENDING = "PENDING"
            PAID = "PAID"

        enums.EventTypes = EventTypes
        enums.ItemDealStatuses = ItemDealStatuses
        sys.modules["playerokapi.enums"] = enums
    if "playerokapi.account" not in sys.modules:
        account = types.ModuleType("playerokapi.account")

        class Account:
            def __init__(self, *a, **kw):
                pass

        account.Account = Account
        sys.modules["playerokapi.account"] = account
    if "playerokapi.listener" not in sys.modules:
        listener_pkg = types.ModuleType("playerokapi.listener")
        sys.modules["playerokapi.listener"] = listener_pkg
    if "playerokapi.listener.listener" not in sys.modules:
        lmod = types.ModuleType("playerokapi.listener.listener")

        class EventListener:
            def __init__(self, *a, **kw):
                pass

        lmod.EventListener = EventListener
        sys.modules["playerokapi.listener.listener"] = lmod
    return sys.modules["playerokapi.enums"]
