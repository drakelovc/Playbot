"""Тесты для plugins/authcode.py — проверяем парсинг и обработку
сообщения. IMAP-вызов мокаем."""
from __future__ import annotations

import sys
from unittest.mock import MagicMock

import pytest


@pytest.fixture(autouse=True)
def stub_pacc(stub_playerokapi):
    return stub_playerokapi


@pytest.fixture
def auc_module():
    for name in list(sys.modules):
        if name.startswith("plugins"):
            del sys.modules[name]
    import plugins.authcode as auc  # noqa
    return auc


def _make_ctx():
    ctx = MagicMock()
    ctx.playerok_acc = MagicMock()
    ctx.playerok_acc.id = "seller"
    return ctx


def _msg_event(text: str, chat_id: str = "chat-1"):
    from playerokapi.enums import EventTypes
    ev = MagicMock()
    ev.type = EventTypes.NEW_MESSAGE
    ev.message = MagicMock()
    ev.message.text = text
    ev.message.user = MagicMock()
    ev.message.user.id = "buyer"
    ev.chat = MagicMock()
    ev.chat.id = chat_id
    return ev


def test_mailcode_without_imap_returns_no_config(auc_module, monkeypatch):
    auc = auc_module
    cfg = auc.get_config()
    cfg["allow_without_assignment"] = True   # пропускаем assignment-check
    auc.save_config(cfg)
    ctx = _make_ctx()
    ev = _msg_event("!mailcode")
    handled = auc.HANDLER.on_event(ev, ctx)
    assert handled is True
    text = ctx.playerok_acc.send_message.call_args.kwargs.get("text") \
        or ctx.playerok_acc.send_message.call_args.args[1]
    assert "не настроен доступ" in text.lower() or "не настроена" in text.lower()


def test_mailcode_returns_code(auc_module, monkeypatch):
    auc = auc_module
    cfg = auc.get_config()
    cfg["allow_without_assignment"] = True
    cfg["imap_host"] = "imap.example.com"
    cfg["imap_login"] = "u"
    cfg["imap_password"] = "p"
    auc.save_config(cfg)

    monkeypatch.setattr(
        auc, "fetch_latest_code",
        lambda **kw: {"code": "X1Y2Z", "sent_ts": 1, "subject": "Steam",
                      "from": "noreply@steampowered.com"},
    )

    ctx = _make_ctx()
    ev = _msg_event("!mailcode")
    auc.HANDLER.on_event(ev, ctx)
    text = ctx.playerok_acc.send_message.call_args.kwargs.get("text") \
        or ctx.playerok_acc.send_message.call_args.args[1]
    assert "X1Y2Z" in text


def test_mailcode_aliases(auc_module, monkeypatch):
    auc = auc_module
    cfg = auc.get_config()
    cfg["allow_without_assignment"] = True
    cfg["imap_host"] = "imap.example.com"
    cfg["imap_login"] = "u"
    cfg["imap_password"] = "p"
    auc.save_config(cfg)
    monkeypatch.setattr(auc, "fetch_latest_code",
                        lambda **kw: {"code": "Q9Q9Q"})
    ctx = _make_ctx()
    auc.HANDLER.on_event(_msg_event("!authcode"), ctx)
    auc.HANDLER.on_event(_msg_event("!письмо"), ctx)
    assert ctx.playerok_acc.send_message.call_count == 2


def test_decode_subject_with_mime() -> None:
    import plugins.authcode as auc
    encoded = "=?utf-8?b?0J/RgNC40LLQtdGCINGB0LXQtNC10YDQv9C+0LzQuQ==?="
    decoded = auc._decode(encoded)
    assert "ривет" in decoded or "сдер" in decoded or encoded != decoded
