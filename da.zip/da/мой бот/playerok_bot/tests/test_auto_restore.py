"""Tests for the auto-restore (item restoration) feature in playerok_bot."""
from __future__ import annotations

import sys
import types
import json
import os
from unittest.mock import MagicMock, patch

import pytest


@pytest.fixture
def stub_bot_module(stub_playerokapi, monkeypatch, tmp_path):
    """Stubs the heavy dependencies and imports playerok_bot for testing."""
    # Add ItemStatuses and DEAL_CONFIRMED_AUTOMATICALLY to stub enums
    enums = sys.modules["playerokapi.enums"]
    if not hasattr(enums.EventTypes, "DEAL_CONFIRMED_AUTOMATICALLY"):
        enums.EventTypes.DEAL_CONFIRMED_AUTOMATICALLY = "DEAL_CONFIRMED_AUTOMATICALLY"

    class ItemStatuses:
        EXPIRED = "EXPIRED"
        SOLD = "SOLD"
        APPROVED = "APPROVED"

    enums.ItemStatuses = ItemStatuses

    # Stub telebot
    tbot = types.ModuleType("telebot")

    class FakeBot:
        def __init__(self, *a, **kw):
            self.sent = []

        def message_handler(self, *a, **kw):
            def d(f):
                return f
            return d

        def callback_query_handler(self, *a, **kw):
            def d(f):
                return f
            return d

        def register_next_step_handler(self, *a, **kw):
            pass

        def send_message(self, *a, **kw):
            self.sent.append((a, kw))

        def answer_callback_query(self, *a, **kw):
            pass

        def edit_message_text(self, *a, **kw):
            pass

        def infinity_polling(self, *a, **kw):
            pass

    tbot.TeleBot = FakeBot
    tbot_types = types.ModuleType("telebot.types")

    class InlineKeyboardMarkup:
        def __init__(self, *a, **kw):
            pass
        def add(self, *a, **kw):
            pass
        def row(self, *a, **kw):
            pass

    class InlineKeyboardButton:
        def __init__(self, *a, **kw):
            pass

    class ReplyKeyboardMarkup:
        def __init__(self, *a, **kw):
            pass
        def row(self, *a, **kw):
            pass

    tbot_types.InlineKeyboardMarkup = InlineKeyboardMarkup
    tbot_types.InlineKeyboardButton = InlineKeyboardButton
    tbot_types.ReplyKeyboardMarkup = ReplyKeyboardMarkup
    tbot.types = tbot_types
    sys.modules["telebot"] = tbot
    sys.modules["telebot.types"] = tbot_types

    # Stub steampy
    steampy = types.ModuleType("steampy")
    guard_mod = types.ModuleType("steampy.guard")
    guard_mod.generate_one_time_code = lambda *a: "12345"
    sys.modules["steampy"] = steampy
    sys.modules["steampy.guard"] = guard_mod

    # Stub db module
    sys.modules["db"] = None

    # Remove cached playerok_bot if present
    if "playerok_bot" in sys.modules:
        del sys.modules["playerok_bot"]
    if "plugins" in sys.modules:
        del sys.modules["plugins"]

    # Stub plugins module
    plugins_mod = types.ModuleType("plugins")
    plugins_mod.PluginContext = MagicMock
    plugins_mod.dispatch_event = MagicMock()
    plugins_mod.register_telegram_all = MagicMock()
    plugins_mod.setup_all = MagicMock()
    plugins_mod.start_background_all = MagicMock()
    plugins_mod.all_plugins = MagicMock(return_value=[])
    plugins_mod.is_enabled = MagicMock(return_value=True)
    plugins_mod.set_enabled = MagicMock()
    plugins_mod.get = MagicMock(return_value=None)
    sys.modules["plugins"] = plugins_mod

    import playerok_bot
    return playerok_bot


def test_default_config_has_restore_keys(stub_bot_module):
    """DEFAULT_CONFIG contains auto_restore_interval and auto_restore_expired."""
    cfg = stub_bot_module.DEFAULT_CONFIG
    assert "auto_restore" in cfg
    assert "auto_restore_interval" in cfg
    assert "auto_restore_expired" in cfg
    assert cfg["auto_restore_interval"] == 30
    assert cfg["auto_restore_expired"] is True


def test_do_restore_scan_restores_items(stub_bot_module, monkeypatch):
    """_do_restore_scan finds sold items and restores them."""
    mod = stub_bot_module

    # Save a config with auto_restore enabled
    cfg = mod.load_config()
    cfg["auto_restore"] = True
    cfg["auto_restore_expired"] = True
    mod.save_config(cfg)

    # Mock playerok_acc
    mock_acc = MagicMock()
    monkeypatch.setattr(mod, "playerok_acc", mock_acc)
    monkeypatch.setattr(mod, "playerok_status", {"connected": True})

    # Create fake items
    item1 = MagicMock()
    item1.id = "item_1"
    item1.name = "Test Item 1"
    item1.price = 100

    item2 = MagicMock()
    item2.id = "item_2"
    item2.name = "Test Item 2"
    item2.price = 200

    items_result = MagicMock()
    items_result.items = [item1, item2]
    mock_acc.get_my_items.return_value = items_result

    # Create free priority status
    free_status = MagicMock()
    free_status.price = 0
    free_status.id = "free_status_id"

    paid_status = MagicMock()
    paid_status.price = 100
    paid_status.id = "paid_status_id"

    mock_acc.get_item_priority_statuses.return_value = [paid_status, free_status]

    restored = mod._do_restore_scan()

    assert restored == 2
    assert mock_acc.publish_item.call_count == 2
    mock_acc.publish_item.assert_any_call("item_1", "free_status_id")
    mock_acc.publish_item.assert_any_call("item_2", "free_status_id")


def test_do_restore_scan_skips_when_no_free_status(stub_bot_module, monkeypatch):
    """_do_restore_scan does not restore if there is no free priority status."""
    mod = stub_bot_module

    cfg = mod.load_config()
    cfg["auto_restore"] = True
    mod.save_config(cfg)

    mock_acc = MagicMock()
    monkeypatch.setattr(mod, "playerok_acc", mock_acc)
    monkeypatch.setattr(mod, "playerok_status", {"connected": True})

    item1 = MagicMock()
    item1.id = "item_1"
    item1.name = "Test Item"
    item1.price = 100

    items_result = MagicMock()
    items_result.items = [item1]
    mock_acc.get_my_items.return_value = items_result

    # Only paid statuses
    paid_status = MagicMock()
    paid_status.price = 50
    paid_status.id = "paid_id"
    mock_acc.get_item_priority_statuses.return_value = [paid_status]

    restored = mod._do_restore_scan()

    assert restored == 0
    mock_acc.publish_item.assert_not_called()


def test_do_restore_scan_skips_when_disabled(stub_bot_module, monkeypatch):
    """_do_restore_scan returns 0 when playerok is not connected."""
    mod = stub_bot_module

    monkeypatch.setattr(mod, "playerok_acc", None)
    monkeypatch.setattr(mod, "playerok_status", {"connected": False})

    restored = mod._do_restore_scan()
    assert restored == 0


def test_do_restore_scan_respects_expired_flag(stub_bot_module, monkeypatch):
    """_do_restore_scan only scans SOLD when auto_restore_expired is False."""
    mod = stub_bot_module
    enums = sys.modules["playerokapi.enums"]

    cfg = mod.load_config()
    cfg["auto_restore"] = True
    cfg["auto_restore_expired"] = False
    mod.save_config(cfg)

    mock_acc = MagicMock()
    monkeypatch.setattr(mod, "playerok_acc", mock_acc)
    monkeypatch.setattr(mod, "playerok_status", {"connected": True})

    items_result = MagicMock()
    items_result.items = []
    mock_acc.get_my_items.return_value = items_result

    mod._do_restore_scan()

    # Check that get_my_items was called with only SOLD status
    call_args = mock_acc.get_my_items.call_args
    statuses_arg = call_args[1].get("statuses") or call_args[0][0] if call_args[0] else call_args[1]["statuses"]
    assert enums.ItemStatuses.SOLD in statuses_arg
    assert enums.ItemStatuses.EXPIRED not in statuses_arg


def test_do_restore_scan_includes_expired(stub_bot_module, monkeypatch):
    """_do_restore_scan includes EXPIRED when auto_restore_expired is True."""
    mod = stub_bot_module
    enums = sys.modules["playerokapi.enums"]

    cfg = mod.load_config()
    cfg["auto_restore"] = True
    cfg["auto_restore_expired"] = True
    mod.save_config(cfg)

    mock_acc = MagicMock()
    monkeypatch.setattr(mod, "playerok_acc", mock_acc)
    monkeypatch.setattr(mod, "playerok_status", {"connected": True})

    items_result = MagicMock()
    items_result.items = []
    mock_acc.get_my_items.return_value = items_result

    mod._do_restore_scan()

    call_args = mock_acc.get_my_items.call_args
    statuses_arg = call_args[1]["statuses"]
    assert enums.ItemStatuses.SOLD in statuses_arg
    assert enums.ItemStatuses.EXPIRED in statuses_arg
