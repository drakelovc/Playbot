"""Tests for plugins/autoconfirm.py."""
from __future__ import annotations

import sys
import time
from unittest.mock import MagicMock, patch

import pytest


@pytest.fixture
def ac_module(stub_playerokapi):
    # Add statuses needed by autoconfirm plugin
    enums = sys.modules["playerokapi.enums"]
    for attr in ("SENT", "CONFIRMED", "CONFIRMED_AUTOMATICALLY", "ROLLED_BACK"):
        if not hasattr(enums.ItemDealStatuses, attr):
            setattr(enums.ItemDealStatuses, attr, attr)
    for name in list(sys.modules):
        if name.startswith("plugins"):
            del sys.modules[name]
    import plugins.autoconfirm as ac
    return ac


def _make_ctx(ac):
    ctx = MagicMock()
    ctx.playerok_acc = MagicMock()
    ctx.bot = MagicMock()
    ctx.admin_id = 123
    ctx.log = MagicMock()
    ctx.get_config = ac.get_config
    ctx.save_config = ac.save_config
    return ctx


def test_plugin_metadata(ac_module):
    assert ac_module.PLUGIN.id == "autoconfirm"
    assert ac_module.PLUGIN.icon == "\u23f2\ufe0f"
    assert ac_module.PLUGIN.default_enabled is True


def test_default_config(ac_module):
    cfg = ac_module.get_config()
    assert cfg["enabled"] is False
    assert cfg["delay_minutes"] == 15
    assert cfg["notify_on_confirm"] is True


def test_on_event_item_paid_adds_pending(ac_module):
    ac = ac_module
    ctx = _make_ctx(ac)

    # Enable the plugin
    cfg = ac.get_config()
    cfg["enabled"] = True
    cfg["delay_minutes"] = 10
    ac.save_config(cfg)

    from playerokapi.enums import EventTypes
    ev = MagicMock()
    ev.type = EventTypes.ITEM_PAID
    ev.deal_id = "deal-abc-123"
    ev.id = "deal-abc-123"

    result = ac.HANDLER.on_event(ev, ctx)
    assert result is False

    pending = ac.load_pending()
    assert len(pending) == 1
    assert pending[0]["deal_id"] == "deal-abc-123"
    assert pending[0]["confirm_after_minutes"] == 10


def test_on_event_disabled_does_not_add_pending(ac_module):
    ac = ac_module
    ctx = _make_ctx(ac)

    # Keep plugin disabled (default)
    from playerokapi.enums import EventTypes
    ev = MagicMock()
    ev.type = EventTypes.ITEM_PAID
    ev.deal_id = "deal-xyz"
    ev.id = "deal-xyz"

    result = ac.HANDLER.on_event(ev, ctx)
    assert result is False

    pending = ac.load_pending()
    assert len(pending) == 0


def test_process_pending_confirms_expired(ac_module):
    ac = ac_module
    ctx = _make_ctx(ac)

    cfg = ac.get_config()
    cfg["enabled"] = True
    cfg["delay_minutes"] = 5
    ac.save_config(cfg)

    # Add a pending entry that is already expired (scheduled 10 minutes ago)
    ac.save_pending([{
        "deal_id": "deal-old-1",
        "scheduled_at": int(time.time()) - 600,
        "confirm_after_minutes": 5,
    }])

    ac.HANDLER._process_pending(ctx)

    ctx.playerok_acc.update_deal.assert_called_once()
    call_args = ctx.playerok_acc.update_deal.call_args
    assert call_args[0][0] == "deal-old-1"

    # Pending should be empty now
    pending = ac.load_pending()
    assert len(pending) == 0


def test_remove_pending(ac_module):
    ac = ac_module
    ac.save_pending([
        {"deal_id": "d1", "scheduled_at": 100, "confirm_after_minutes": 5},
        {"deal_id": "d2", "scheduled_at": 200, "confirm_after_minutes": 10},
    ])
    assert ac.remove_pending("d1") is True
    pending = ac.load_pending()
    assert len(pending) == 1
    assert pending[0]["deal_id"] == "d2"

    assert ac.remove_pending("nonexistent") is False
