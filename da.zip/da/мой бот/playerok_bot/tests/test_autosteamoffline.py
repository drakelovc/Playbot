"""Тесты для plugins/autosteamoffline.py."""
from __future__ import annotations

import sys
from unittest.mock import MagicMock

import pytest


@pytest.fixture(autouse=True)
def stub_pacc(stub_playerokapi):
    return stub_playerokapi


@pytest.fixture
def aso_module():
    for name in list(sys.modules):
        if name.startswith("plugins"):
            del sys.modules[name]
    import plugins.autosteamoffline as aso  # noqa
    return aso


def _make_ctx(aso):
    ctx = MagicMock()
    ctx.playerok_acc = MagicMock()
    ctx.playerok_acc.id = "seller-1"
    ctx.bot = MagicMock()
    ctx.admin_id = 0
    ctx.log = MagicMock()
    ctx.get_config = aso.get_config
    ctx.save_config = aso.save_config
    return ctx


def _make_event(*, etype: str, msg_text: str = "",
                item_name: str = "Оффлайн активация Steam",
                deal_id: str = "deal-A", chat_id: str = "chat-A"):
    from playerokapi.enums import EventTypes
    ev = MagicMock()
    ev.type = getattr(EventTypes, etype)
    if etype in ("ITEM_PAID", "NEW_DEAL"):
        ev.deal = MagicMock()
        ev.deal.id = deal_id
        ev.deal.comment_from_buyer = None
        ev.deal.price = 50
        ev.deal.item = MagicMock()
        ev.deal.item.id = "item-A"
        ev.deal.item.name = item_name
        ev.deal.item.description = ""
        ev.deal.chat = MagicMock()
        ev.deal.chat.id = chat_id
        ev.chat = ev.deal.chat
        ev.deal.user = MagicMock()
        ev.deal.user.username = "buyer"
    elif etype == "NEW_MESSAGE":
        ev.message = MagicMock()
        ev.message.text = msg_text
        ev.message.user = MagicMock()
        ev.message.user.id = "buyer"
        ev.chat = MagicMock()
        ev.chat.id = chat_id
    return ev


def _add_account(aso, alias="off1"):
    aso.upsert_account({
        "alias": alias, "login": "loginX", "password": "passX",
        "mafile": {"shared_secret": "S", "identity_secret": "I"},
        "frozen": False,
    })


def test_item_paid_offline_delivers(aso_module):
    aso = aso_module
    _add_account(aso)
    ctx = _make_ctx(aso)
    ev = _make_event(etype="ITEM_PAID")
    assert aso.HANDLER.on_event(ev, ctx) is True
    # Логин/пароль ушли в чат
    args = ctx.playerok_acc.send_message.call_args
    text = args.kwargs.get("text") or args.args[1]
    assert "loginX" in text and "passX" in text


def test_guard_command_respects_limit(aso_module, monkeypatch):
    aso = aso_module
    _add_account(aso)
    ctx = _make_ctx(aso)
    # Выдача
    aso.HANDLER.on_event(_make_event(etype="ITEM_PAID"), ctx)
    monkeypatch.setattr(aso.common, "generate_code", lambda s: "11111")

    # 3 успешных !guard
    for i in range(3):
        ctx.playerok_acc.send_message.reset_mock()
        ev = _make_event(etype="NEW_MESSAGE", msg_text="!guard")
        aso.HANDLER.on_event(ev, ctx)
        text = ctx.playerok_acc.send_message.call_args.kwargs.get("text") \
            or ctx.playerok_acc.send_message.call_args.args[1]
        assert "11111" in text, f"итерация {i}"

    # 4-я попытка — должен сказать «лимит исчерпан» (или эквивалент)
    ctx.playerok_acc.send_message.reset_mock()
    ev = _make_event(etype="NEW_MESSAGE", msg_text="!guard")
    aso.HANDLER.on_event(ev, ctx)
    text = ctx.playerok_acc.send_message.call_args.kwargs.get("text") \
        or ctx.playerok_acc.send_message.call_args.args[1]
    assert "11111" not in text
