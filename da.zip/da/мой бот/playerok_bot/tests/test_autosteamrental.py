"""Тесты для plugins/autosteamrental.py.

Покрываем основные сценарии:
- `_handle_item_paid` выдаёт аккаунт из пула, парсит длительность.
- `_handle_new_message` (`!steamguard <ник>`) запускает таймер.
- `_tick` отправляет напоминание и помечает истёкшие выдачи.
- `bump_stat` инкрементирует per-account аналитику.
"""
from __future__ import annotations

import sys
import time
import types
from pathlib import Path
from unittest.mock import MagicMock

import pytest


@pytest.fixture(autouse=True)
def stub_pacc(stub_playerokapi):
    """Активируем stub-модуль playerokapi.enums до импорта плагина."""
    return stub_playerokapi


@pytest.fixture
def asr_module():
    """Свежий импорт plugins.autosteamrental в каждом тесте."""
    for name in list(sys.modules):
        if name.startswith("plugins"):
            del sys.modules[name]
    import plugins.autosteamrental as asr  # noqa: WPS433
    return asr


def _make_ctx(asr):
    ctx = MagicMock()
    ctx.playerok_acc = MagicMock()
    ctx.playerok_acc.id = "seller-1"
    ctx.bot = MagicMock()
    ctx.admin_id = 0
    ctx.log = MagicMock()
    ctx.get_config = asr.get_config
    ctx.save_config = asr.save_config
    return ctx


def _make_event(*, etype: str, deal_id: str | None = None,
                item_name: str = "Аренда Steam на 2 часа",
                item_id: str = "item-1",
                chat_id: str = "chat-1",
                msg_text: str = "",
                seller_id: str = "seller-1"):
    from playerokapi.enums import EventTypes
    ev = MagicMock()
    ev.type = getattr(EventTypes, etype)
    if etype in ("ITEM_PAID", "NEW_DEAL"):
        ev.deal = MagicMock()
        ev.deal.id = deal_id or "deal-1"
        ev.deal.comment_from_buyer = None
        ev.deal.price = 100
        ev.deal.item = MagicMock()
        ev.deal.item.id = item_id
        ev.deal.item.name = item_name
        ev.deal.item.description = ""
        ev.deal.chat = MagicMock()
        ev.deal.chat.id = chat_id
        ev.chat = ev.deal.chat
        ev.deal.user = MagicMock()
        ev.deal.user.username = "buyer-1"
    elif etype == "NEW_MESSAGE":
        ev.message = MagicMock()
        ev.message.text = msg_text
        ev.message.user = MagicMock()
        ev.message.user.id = "buyer-2"
        ev.chat = MagicMock()
        ev.chat.id = chat_id
    return ev


def _add_test_account(asr, alias="leshaman111", login="loginA",
                      password="passA"):
    asr.upsert_account({
        "alias": alias, "login": login, "password": password,
        "mafile": {"shared_secret": "AAA", "identity_secret": "BBB",
                   "Session": {"SteamID": "76561"}},
        "frozen": False,
    })


def test_item_paid_picks_account_and_creates_assignment(asr_module):
    asr = asr_module
    _add_test_account(asr)
    ctx = _make_ctx(asr)
    ev = _make_event(etype="ITEM_PAID")
    handler = asr.HANDLER

    assert handler.on_event(ev, ctx) is True
    # send_message покупателю должен быть отправлен
    assert ctx.playerok_acc.send_message.call_count == 1
    text = ctx.playerok_acc.send_message.call_args.kwargs.get("text") \
        or ctx.playerok_acc.send_message.call_args.args[1]
    assert "loginA" in text
    assert "passA" in text

    # Создалась assignment
    items = asr.list_assignments()
    assert len(items) == 1
    a = items[0]
    assert a["deal_id"] == "deal-1"
    assert a["alias"] == "leshaman111"
    assert a["duration_minutes"] == 120  # «на 2 часа»
    assert a["status"] == "delivered"

    # bump_stat — delivered_count = 1
    acc = asr.find_account("leshaman111")
    assert (acc.get("stats") or {}).get("delivered_count") == 1


def test_item_paid_no_accounts_warns(asr_module):
    asr = asr_module
    ctx = _make_ctx(asr)
    ev = _make_event(etype="ITEM_PAID")
    asr.HANDLER.on_event(ev, ctx)
    # Сообщение покупателю — «нет аккаунтов»
    assert ctx.playerok_acc.send_message.call_count == 1


def test_steamguard_starts_timer(asr_module, monkeypatch):
    asr = asr_module
    _add_test_account(asr)
    ctx = _make_ctx(asr)

    # 1. Выдача
    asr.HANDLER.on_event(_make_event(etype="ITEM_PAID"), ctx)
    # 2. Команда !steamguard <ник>
    monkeypatch.setattr(asr.common, "generate_code", lambda secret: "12345")
    ctx.playerok_acc.send_message.reset_mock()
    ev = _make_event(etype="NEW_MESSAGE", msg_text="!steamguard leshaman111")
    assert asr.HANDLER.on_event(ev, ctx) is True

    a = asr.find_assignment_by_chat("chat-1")
    assert a is not None
    assert a["status"] == "active"
    assert a["started_at"] > 0
    assert a["expires_at"] > a["started_at"]
    text = ctx.playerok_acc.send_message.call_args.kwargs.get("text") \
        or ctx.playerok_acc.send_message.call_args.args[1]
    assert "12345" in text

    # active_count = 1
    acc = asr.find_account("leshaman111")
    assert (acc.get("stats") or {}).get("active_count") == 1


def test_tick_marks_expired_and_bumps_stats(asr_module, monkeypatch):
    asr = asr_module
    _add_test_account(asr)
    ctx = _make_ctx(asr)

    monkeypatch.setattr(asr.common, "generate_code", lambda secret: "ABCDE")
    asr.HANDLER.on_event(_make_event(etype="ITEM_PAID"), ctx)
    asr.HANDLER.on_event(_make_event(etype="NEW_MESSAGE",
                                      msg_text="!steamguard leshaman111"), ctx)

    # Сдвигаем expires_at в прошлое
    a = asr.find_assignment_by_chat("chat-1")
    a["expires_at"] = int(time.time()) - 10
    asr.update_assignment(a["deal_id"], expires_at=a["expires_at"])

    asr.HANDLER._tick(ctx)
    fresh = asr.find_assignment_by_deal("deal-1")
    assert fresh is not None
    assert fresh["status"] == "expired"
    acc = asr.find_account("leshaman111")
    assert (acc.get("stats") or {}).get("rentals_count") == 1
    assert (acc.get("stats") or {}).get("total_minutes") == 120


def test_bump_stat_creates_first_used_at(asr_module):
    asr = asr_module
    _add_test_account(asr, alias="z1")
    asr.bump_stat("z1", delivered_count=1)
    s = asr.find_account("z1")["stats"]
    assert s["delivered_count"] == 1
    assert s["first_used_at"] > 0
    assert s["last_used_at"] >= s["first_used_at"]


def test_bump_hot_hour_logic():
    """Smart bump: проверяем переход через полночь.

    Реализация в `playerok_bot._is_bump_hot_hour` — мы дублируем её
    тут (это тривиальный pure-function), чтобы не тянуть весь
    playerok_bot.py с импортом playerokapi/telebot."""
    def _is_hot(cfg, hour: int, weekday: int = 1):
        if not cfg.get("smart_bump_enabled"):
            return True
        ranges = cfg.get("smart_bump_ranges") or []
        if not ranges:
            return True
        for r in ranges:
            days = r.get("days") or [1, 2, 3, 4, 5, 6, 7]
            if weekday not in days:
                continue
            h_from = int(r.get("from", 0)) % 24
            h_to = int(r.get("to", 0)) % 24
            if h_from == h_to:
                return True
            if h_from < h_to:
                if h_from <= hour < h_to:
                    return True
            else:
                if hour >= h_from or hour < h_to:
                    return True
        return False

    cfg = {
        "smart_bump_enabled": True,
        "smart_bump_ranges": [
            {"days": [1, 2, 3, 4, 5, 6, 7], "from": 19, "to": 2},
        ],
    }
    for hour, expected in [
        (20, True), (1, True), (15, False), (3, False), (19, True), (2, False),
    ]:
        assert _is_hot(cfg, hour) is expected, (
            f"hour={hour} expected={expected}")

    cfg_off = {"smart_bump_enabled": False}
    assert _is_hot(cfg_off, 5) is True  # отключено → всегда «горячий»


# ═════════════════════════════════════════════════════════════════
# v3: Pre-reservation, blacklist, recovery, operator actions
# ═════════════════════════════════════════════════════════════════

def test_new_deal_reserves_account(asr_module):
    asr = asr_module
    _add_test_account(asr)
    ctx = _make_ctx(asr)

    cfg = asr.get_config()
    cfg["pre_reservation_enabled"] = True
    cfg["pre_reservation_minutes"] = 5
    asr.save_config(cfg)

    ev = _make_event(etype="NEW_DEAL")
    assert asr.HANDLER.on_event(ev, ctx) is True

    items = asr.list_assignments()
    assert len(items) == 1
    a = items[0]
    assert a["status"] == "reserved"
    assert a["alias"] == "leshaman111"
    assert a["reserved_until"] > 0

    # Аккаунт занят — второй NEW_DEAL не сможет зарезервировать тот же
    ev2 = _make_event(etype="NEW_DEAL", deal_id="deal-2", chat_id="chat-2")
    asr.HANDLER.on_event(ev2, ctx)
    items = asr.list_assignments()
    # Второй deal не создал новой резервации (нет свободных)
    reserved = [a for a in items if a["status"] == "reserved"]
    assert len(reserved) == 1
    assert reserved[0]["deal_id"] == "deal-1"


def test_item_paid_promotes_reservation(asr_module):
    asr = asr_module
    _add_test_account(asr)
    ctx = _make_ctx(asr)

    asr.HANDLER.on_event(_make_event(etype="NEW_DEAL"), ctx)
    # Тот же deal_id приходит как ITEM_PAID
    ctx.playerok_acc.send_message.reset_mock()
    asr.HANDLER.on_event(_make_event(etype="ITEM_PAID"), ctx)

    items = asr.list_assignments()
    assert len(items) == 1
    a = items[0]
    assert a["status"] == "delivered"
    # Выдан текст с логином/паролем
    assert ctx.playerok_acc.send_message.called


def test_reservation_expires_in_tick(asr_module):
    asr = asr_module
    _add_test_account(asr)
    ctx = _make_ctx(asr)
    asr.HANDLER.on_event(_make_event(etype="NEW_DEAL"), ctx)
    a = asr.list_assignments()[0]
    a["reserved_until"] = int(time.time()) - 10
    asr.update_assignment(a["deal_id"], reserved_until=a["reserved_until"])

    asr.HANDLER._tick(ctx)
    fresh = asr.find_assignment_by_deal("deal-1")
    assert fresh["status"] == "reservation_expired"


def test_blacklist_blocks_new_deal(asr_module):
    asr = asr_module
    _add_test_account(asr)
    ctx = _make_ctx(asr)
    assert asr.add_buyer_to_blacklist("buyer-1") is True

    ev = _make_event(etype="NEW_DEAL")
    asr.HANDLER.on_event(ev, ctx)
    # Не было создано assignment
    assert asr.list_assignments() == []


def test_blacklist_remove(asr_module):
    asr = asr_module
    assert asr.add_buyer_to_blacklist("Spammer") is True
    assert "spammer" in (asr.get_config().get("buyer_blacklist") or [])
    assert asr.remove_buyer_from_blacklist("spammer") is True
    assert "spammer" not in (asr.get_config().get("buyer_blacklist") or [])


def test_deal_problem_auto_blacklists(asr_module):
    asr = asr_module
    ctx = _make_ctx(asr)
    cfg = asr.get_config()
    cfg["auto_blacklist_on_refund"] = True
    asr.save_config(cfg)

    ev = _make_event(etype="ITEM_PAID")  # base, then patch
    from playerokapi.enums import EventTypes
    if not hasattr(EventTypes, "DEAL_HAS_PROBLEM"):
        EventTypes.DEAL_HAS_PROBLEM = "DEAL_HAS_PROBLEM"
    ev.type = EventTypes.DEAL_HAS_PROBLEM

    asr.HANDLER.on_event(ev, ctx)
    bl = [str(x).lower() for x in (asr.get_config().get("buyer_blacklist") or [])]
    assert "buyer-1" in bl


def test_recovery_marks_expired(asr_module):
    asr = asr_module
    ctx = _make_ctx(asr)
    asr.add_assignment({
        "deal_id": "old-1", "alias": "x", "buyer": "b",
        "chat_id": "c", "status": "active",
        "started_at": 1, "expires_at": 100, "duration_minutes": 30,
    })
    asr.add_assignment({
        "deal_id": "res-1", "alias": "y", "buyer": "b",
        "chat_id": "c", "status": "reserved",
        "reserved_until": 100, "duration_minutes": 30,
    })

    asr.HANDLER._recover_on_start(ctx)
    a1 = asr.find_assignment_by_deal("old-1")
    a2 = asr.find_assignment_by_deal("res-1")
    assert a1["status"] == "expired"
    assert a1.get("recovered") is True
    assert a2["status"] == "reservation_expired"


def test_operator_extend(asr_module, monkeypatch):
    asr = asr_module
    _add_test_account(asr)
    ctx = _make_ctx(asr)
    monkeypatch.setattr(asr.common, "generate_code", lambda secret: "12345")

    asr.HANDLER.on_event(_make_event(etype="ITEM_PAID"), ctx)
    asr.HANDLER.on_event(_make_event(etype="NEW_MESSAGE",
                                      msg_text="!steamguard leshaman111"), ctx)
    a = asr.find_assignment_by_deal("deal-1")
    old_exp = a["expires_at"]
    short = asr.common.short_id(a["deal_id"])

    res = asr._operator_extend(short, 30, ctx)
    assert res is not None
    fresh = asr.find_assignment_by_deal("deal-1")
    assert fresh["expires_at"] - old_exp == 30 * 60


def test_operator_stop_marks_expired(asr_module, monkeypatch):
    asr = asr_module
    _add_test_account(asr)
    ctx = _make_ctx(asr)
    monkeypatch.setattr(asr.common, "generate_code", lambda secret: "12345")

    asr.HANDLER.on_event(_make_event(etype="ITEM_PAID"), ctx)
    asr.HANDLER.on_event(_make_event(etype="NEW_MESSAGE",
                                      msg_text="!steamguard leshaman111"), ctx)
    a = asr.find_assignment_by_deal("deal-1")
    short = asr.common.short_id(a["deal_id"])

    res = asr._operator_stop(short, ctx)
    assert res is not None
    fresh = asr.find_assignment_by_deal("deal-1")
    assert fresh["status"] == "expired"
    assert fresh.get("stopped_by_operator") is True


def test_operator_switch_creates_new_assignment(asr_module, monkeypatch):
    asr = asr_module
    _add_test_account(asr, alias="a1", login="loginA", password="passA")
    _add_test_account(asr, alias="a2", login="loginB", password="passB")
    ctx = _make_ctx(asr)
    monkeypatch.setattr(asr.common, "generate_code", lambda secret: "11111")

    asr.HANDLER.on_event(_make_event(etype="ITEM_PAID"), ctx)
    asr.HANDLER.on_event(_make_event(etype="NEW_MESSAGE",
                                      msg_text="!steamguard a1"), ctx)
    a = asr.find_assignment_by_deal("deal-1")
    short = asr.common.short_id(a["deal_id"])

    res = asr._operator_switch_account(short, ctx)
    assert isinstance(res, dict)
    items = asr.list_assignments()
    by_status = {a["status"] for a in items}
    assert "expired" in by_status
    assert "delivered" in by_status


# ═════════════════════════════════════════════════════════════════
# v4: Warmup (anti-dormant)
# ═════════════════════════════════════════════════════════════════

def _set_acc_stats(asr, alias: str, **stats):
    acc = asr.find_account(alias)
    acc.setdefault("stats", {}).update(stats)
    asr.upsert_account(acc)


def test_is_due_for_warmup_picks_old(asr_module):
    asr = asr_module
    _add_test_account(asr, alias="old")
    _add_test_account(asr, alias="fresh")
    _set_acc_stats(asr, "old", last_used_at=time.time() - 30 * 24 * 3600)
    _set_acc_stats(asr, "fresh", last_used_at=time.time() - 1 * 24 * 3600)
    old = asr.find_account("old")
    fresh = asr.find_account("fresh")
    H = asr.HANDLER
    assert H._is_due_for_warmup(old, interval_days=7) is True
    assert H._is_due_for_warmup(fresh, interval_days=7) is False


def test_is_due_for_warmup_skips_frozen(asr_module):
    asr = asr_module
    _add_test_account(asr, alias="x")
    acc = asr.find_account("x")
    acc["frozen"] = True
    asr.upsert_account(acc)
    _set_acc_stats(asr, "x", last_used_at=time.time() - 30 * 24 * 3600)
    assert asr.HANDLER._is_due_for_warmup(asr.find_account("x"), 7) is False


def test_is_due_for_warmup_skips_in_use(asr_module):
    asr = asr_module
    _add_test_account(asr, alias="x")
    asr.add_assignment({
        "deal_id": "d1", "alias": "x", "buyer": "b",
        "chat_id": "c", "status": "active",
        "started_at": 1, "expires_at": time.time() + 3600,
    })
    _set_acc_stats(asr, "x", last_used_at=time.time() - 30 * 24 * 3600)
    assert asr.HANDLER._is_due_for_warmup(asr.find_account("x"), 7) is False


def test_is_due_for_warmup_requires_mafile(asr_module):
    asr = asr_module
    asr.upsert_account({
        "alias": "noma", "login": "x", "password": "y",
        "mafile": {},  # без shared_secret
        "frozen": False,
    })
    assert asr.HANDLER._is_due_for_warmup(asr.find_account("noma"), 7) is False


def test_warmup_account_updates_stats_on_success(asr_module, monkeypatch):
    asr = asr_module
    _add_test_account(asr, alias="a1")
    ctx = _make_ctx(asr)

    monkeypatch.setattr(asr.HANDLER, "_do_warmup",
                        staticmethod(lambda acc, idle: True))
    asr.HANDLER._warmup_running = True  # симулируем что было запущено
    asr.HANDLER._warmup_account(ctx, asr.find_account("a1"), 5)
    acc = asr.find_account("a1")
    stats = acc.get("stats") or {}
    assert stats.get("warmup_count") == 1
    assert stats.get("warmup_failures") == 0
    assert stats.get("last_warmup_at", 0) > 0
    # лок снят
    assert asr.HANDLER._warmup_running is False


def test_warmup_failure_freezes_after_threshold(asr_module, monkeypatch):
    asr = asr_module
    _add_test_account(asr, alias="a1")
    ctx = _make_ctx(asr)

    monkeypatch.setattr(asr.HANDLER, "_do_warmup",
                        staticmethod(lambda acc, idle: False))
    for _ in range(3):
        asr.HANDLER._warmup_running = True
        asr.HANDLER._warmup_account(ctx, asr.find_account("a1"), 5)
    acc = asr.find_account("a1")
    assert acc.get("frozen") is True
    assert "warmup failures" in (acc.get("freeze_reason") or "")
    assert (acc.get("stats") or {}).get("warmup_failures") == 3


def test_warmup_tick_respects_check_interval(asr_module, monkeypatch):
    asr = asr_module
    _add_test_account(asr, alias="a1")
    _set_acc_stats(asr, "a1", last_used_at=time.time() - 30 * 24 * 3600)
    ctx = _make_ctx(asr)
    cfg = asr.get_config()
    cfg["warmup_enabled"] = True
    cfg["warmup_interval_days"] = 7
    cfg["warmup_check_interval_hours"] = 6
    asr.save_config(cfg)

    # Stub steam_session так чтобы tick прошёл фильтр `is None`
    fake_sess_mod = types.SimpleNamespace(SteamSession=MagicMock())
    monkeypatch.setattr(asr, "steam_session", fake_sess_mod)

    spawned: list = []

    def fake_thread_target(*args, **kwargs):
        # перехватываем создание Thread в _warmup_tick
        spawned.append(kwargs.get("name") or "?")
        t = MagicMock()
        t.start = lambda: None
        return t

    monkeypatch.setattr(asr.threading, "Thread", fake_thread_target)

    asr.HANDLER._last_warmup_check = 0
    asr.HANDLER._warmup_running = False
    asr.HANDLER._warmup_tick(ctx)
    assert len(spawned) == 1  # один тред заспавнен

    # Повторный вызов — `_last_warmup_check` теперь свежий, не должен спавнить
    spawned.clear()
    asr.HANDLER._warmup_running = False
    asr.HANDLER._warmup_tick(ctx)
    assert spawned == []


def test_warmup_tick_disabled_does_nothing(asr_module, monkeypatch):
    asr = asr_module
    _add_test_account(asr, alias="a1")
    _set_acc_stats(asr, "a1", last_used_at=time.time() - 30 * 24 * 3600)
    cfg = asr.get_config()
    cfg["warmup_enabled"] = False
    asr.save_config(cfg)
    ctx = _make_ctx(asr)

    called: list = []
    monkeypatch.setattr(asr.threading, "Thread",
                        lambda *a, **kw: called.append(1))
    asr.HANDLER._last_warmup_check = 0
    asr.HANDLER._warmup_running = False
    asr.HANDLER._warmup_tick(ctx)
    assert called == []
