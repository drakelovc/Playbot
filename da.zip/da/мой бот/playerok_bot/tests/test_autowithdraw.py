"""Tests for plugins/autowithdraw.py."""
from __future__ import annotations

import sys
from unittest.mock import MagicMock, patch

import pytest


@pytest.fixture(autouse=True)
def stub_pacc(stub_playerokapi, monkeypatch):
    """Extend the base stub with TransactionProviderIds and TransactionPaymentMethodIds."""
    enums_mod = stub_playerokapi
    # The stub from conftest only has EventTypes and ItemDealStatuses.
    # We need TransactionProviderIds and TransactionPaymentMethodIds for withdrawal tests.
    import sys
    enums = sys.modules["playerokapi.enums"]

    class TransactionProviderIds:
        SBP = "SBP"
        BANK_CARD_RU = "BANK_CARD_RU"
        USDT = "USDT"
        YMONEY = "YMONEY"

    class TransactionPaymentMethodIds:
        MIR = "MIR"
        VISA_MASTERCARD = "VISA_MASTERCARD"

    class TransactionStatuses:
        PENDING = "PENDING"
        PROCESSING = "PROCESSING"
        CONFIRMED = "CONFIRMED"
        ROLLED_BACK = "ROLLED_BACK"
        FAILED = "FAILED"

    class TransactionOperations:
        DEPOSIT = 0
        BUY = 1
        SELL = 2
        WITHDRAW = 5

    if not hasattr(enums, "TransactionProviderIds"):
        enums.TransactionProviderIds = TransactionProviderIds
    if not hasattr(enums, "TransactionPaymentMethodIds"):
        enums.TransactionPaymentMethodIds = TransactionPaymentMethodIds
    if not hasattr(enums, "TransactionStatuses"):
        enums.TransactionStatuses = TransactionStatuses
    if not hasattr(enums, "TransactionOperations"):
        enums.TransactionOperations = TransactionOperations
    return enums_mod


@pytest.fixture
def aw_module():
    for name in list(sys.modules):
        if name.startswith("plugins"):
            del sys.modules[name]
    import plugins.autowithdraw as aw
    return aw


def _make_ctx(aw):
    ctx = MagicMock()
    ctx.playerok_acc = MagicMock()
    ctx.playerok_acc.id = "seller-1"
    ctx.bot = MagicMock()
    ctx.admin_id = 0
    ctx.log = MagicMock()
    ctx.get_config = aw.get_config
    ctx.save_config = aw.save_config
    return ctx


def test_plugin_metadata(aw_module):
    aw = aw_module
    assert aw.PLUGIN.id == "autowithdraw"
    assert aw.PLUGIN.name == "Автовывод"
    assert aw.PLUGIN.icon == "\U0001f4b8"


def test_default_config_created(aw_module):
    aw = aw_module
    cfg = aw.get_config()
    assert cfg["auto_withdraw_enabled"] is False
    assert cfg["withdraw_threshold"] == 1000
    assert cfg["withdraw_provider"] == "SBP"
    assert cfg["withdraw_reserve"] == 0


def test_do_withdraw_skips_when_below_threshold(aw_module):
    aw = aw_module
    ctx = _make_ctx(aw)
    cfg = aw.get_config()
    cfg["auto_withdraw_enabled"] = True
    cfg["withdraw_account"] = "+79001234567"
    cfg["withdraw_threshold"] = 1000
    cfg["withdraw_reserve"] = 0
    aw.save_config(cfg)

    # Balance 500 rub (50000 kopeks) < threshold 1000 rub
    balance = MagicMock()
    balance.withdrawable = 50000
    ctx.playerok_acc.balance = balance

    aw.HANDLER._do_withdraw(ctx)
    ctx.playerok_acc.request_withdrawal.assert_not_called()


def test_do_withdraw_succeeds_when_above_threshold(aw_module):
    aw = aw_module
    ctx = _make_ctx(aw)
    cfg = aw.get_config()
    cfg["auto_withdraw_enabled"] = True
    cfg["withdraw_account"] = "+79001234567"
    cfg["withdraw_threshold"] = 1000
    cfg["withdraw_reserve"] = 200
    aw.save_config(cfg)

    # Balance 2000 rub (200000 kopeks) >= threshold+reserve (1200 rub)
    balance = MagicMock()
    balance.withdrawable = 200000
    ctx.playerok_acc.balance = balance

    result_txn = MagicMock()
    result_txn.id = "txn-123"
    ctx.playerok_acc.request_withdrawal.return_value = result_txn

    aw.HANDLER._do_withdraw(ctx)

    # Should withdraw: 200000 - 200*100 = 180000 kopeks
    ctx.playerok_acc.request_withdrawal.assert_called_once()
    call_kwargs = ctx.playerok_acc.request_withdrawal.call_args.kwargs
    assert call_kwargs["value"] == 180000

    # History should have an entry
    history = aw.load_history()
    assert len(history) == 1
    assert history[0]["status"] == "success"
    assert history[0]["amount"] == 180000


def test_do_withdraw_disables_after_3_failures(aw_module):
    aw = aw_module
    ctx = _make_ctx(aw)
    cfg = aw.get_config()
    cfg["auto_withdraw_enabled"] = True
    cfg["withdraw_account"] = "+79001234567"
    cfg["withdraw_threshold"] = 100
    cfg["withdraw_reserve"] = 0
    aw.save_config(cfg)

    balance = MagicMock()
    balance.withdrawable = 50000  # 500 rub
    ctx.playerok_acc.balance = balance
    ctx.playerok_acc.request_withdrawal.side_effect = Exception("API error")

    aw.HANDLER._consecutive_failures = 0

    # 3 failures
    for _ in range(3):
        aw.HANDLER._do_withdraw(ctx)

    # After 3 failures, auto_withdraw_enabled should be False
    cfg = aw.get_config()
    assert cfg["auto_withdraw_enabled"] is False
    assert aw.HANDLER._consecutive_failures >= 3


def test_on_event_deal_confirmed(aw_module):
    aw = aw_module
    from playerokapi.enums import EventTypes

    ctx = _make_ctx(aw)
    ev = MagicMock()
    ev.type = EventTypes.DEAL_CONFIRMED

    # on_event should return False (does not claim exclusive handling)
    # but should spawn a delayed check thread
    with patch.object(aw.HANDLER, "_delayed_check") as mock_delayed:
        # We patch threading.Thread to check it's called
        with patch("plugins.autowithdraw.threading.Thread") as mock_thread:
            mock_thread.return_value.start = MagicMock()
            result = aw.HANDLER.on_event(ev, ctx)
            assert result is False
            mock_thread.assert_called_once()
            # Verify the target is _delayed_check
            call_kwargs = mock_thread.call_args.kwargs
            assert call_kwargs["target"] == aw.HANDLER._delayed_check


def test_history_limited_to_100(aw_module):
    aw = aw_module
    # Add 110 entries
    for i in range(110):
        aw.add_history_entry({"ts": i, "amount": i * 100, "status": "success",
                              "provider": "SBP"})
    history = aw.load_history()
    assert len(history) == 100
    # Should keep the last 100
    assert history[0]["ts"] == 10


def test_do_withdraw_skips_when_no_account_set(aw_module):
    aw = aw_module
    ctx = _make_ctx(aw)
    cfg = aw.get_config()
    cfg["auto_withdraw_enabled"] = True
    cfg["withdraw_account"] = ""
    aw.save_config(cfg)

    balance = MagicMock()
    balance.withdrawable = 999999
    ctx.playerok_acc.balance = balance

    aw.HANDLER._do_withdraw(ctx)
    ctx.playerok_acc.request_withdrawal.assert_not_called()


# === Tests for withdrawal status notifications (FEAT-002) ===


def test_pending_saved_after_successful_withdrawal(aw_module):
    """After a successful withdrawal, transaction ID is saved to pending.json."""
    aw = aw_module
    ctx = _make_ctx(aw)
    cfg = aw.get_config()
    cfg["auto_withdraw_enabled"] = True
    cfg["withdraw_account"] = "+79001234567"
    cfg["withdraw_threshold"] = 1000
    cfg["withdraw_reserve"] = 0
    aw.save_config(cfg)

    balance = MagicMock()
    balance.withdrawable = 200000  # 2000 rub
    ctx.playerok_acc.balance = balance

    result_txn = MagicMock()
    result_txn.id = "txn-pending-001"
    ctx.playerok_acc.request_withdrawal.return_value = result_txn

    aw.HANDLER._do_withdraw(ctx)

    pending = aw.load_pending()
    assert len(pending) == 1
    assert pending[0]["id"] == "txn-pending-001"
    assert pending[0]["amount"] == 200000
    assert pending[0]["provider"] == "SBP"
    assert "created_at" in pending[0]


def test_status_check_confirms_credited(aw_module):
    """Status check detects CONFIRMED transaction and sends notification."""
    aw = aw_module
    import sys
    enums = sys.modules["playerokapi.enums"]

    # Ensure TransactionStatuses and TransactionOperations are available
    from playerokapi.enums import TransactionStatuses, TransactionOperations

    ctx = _make_ctx(aw)

    # Set up pending entry
    import time
    aw.save_pending([{
        "id": "txn-100",
        "amount": 150000,
        "provider": "SBP",
        "created_at": int(time.time()),
    }])

    # Set up history entry with matching transaction_id
    aw.add_history_entry({
        "ts": int(time.time()),
        "amount": 150000,
        "provider": "SBP",
        "status": "success",
        "transaction_id": "txn-100",
    })

    # Mock get_transactions to return a confirmed transaction
    txn = MagicMock()
    txn.id = "txn-100"
    txn.status = TransactionStatuses.CONFIRMED
    txn.status_description = None

    txn_list = MagicMock()
    txn_list.transactions = [txn]
    ctx.playerok_acc.get_transactions.return_value = txn_list

    aw.HANDLER._check_pending_statuses(ctx)

    # Pending should be empty now
    pending = aw.load_pending()
    assert len(pending) == 0

    # History should have final_status = "credited"
    history = aw.load_history()
    assert history[0]["final_status"] == "credited"

    # Admin notification sent
    ctx.bot.send_message.assert_called()
    call_args = ctx.bot.send_message.call_args
    assert "зачислен" in call_args[0][1].lower() or "зачислен" in str(call_args)


def test_status_check_detects_failed(aw_module):
    """Status check detects FAILED transaction and sends rejection notification."""
    aw = aw_module
    from playerokapi.enums import TransactionStatuses, TransactionOperations

    ctx = _make_ctx(aw)

    import time
    aw.save_pending([{
        "id": "txn-200",
        "amount": 100000,
        "provider": "BANK_CARD_RU",
        "created_at": int(time.time()),
    }])

    aw.add_history_entry({
        "ts": int(time.time()),
        "amount": 100000,
        "provider": "BANK_CARD_RU",
        "status": "success",
        "transaction_id": "txn-200",
    })

    txn = MagicMock()
    txn.id = "txn-200"
    txn.status = TransactionStatuses.FAILED
    txn.status_description = "Insufficient bank funds"

    txn_list = MagicMock()
    txn_list.transactions = [txn]
    ctx.playerok_acc.get_transactions.return_value = txn_list

    aw.HANDLER._check_pending_statuses(ctx)

    pending = aw.load_pending()
    assert len(pending) == 0

    history = aw.load_history()
    assert history[0]["final_status"] == "rejected"

    ctx.bot.send_message.assert_called()
    call_args = ctx.bot.send_message.call_args
    assert "отклонен" in call_args[0][1].lower() or "отклонен" in str(call_args)


def test_status_check_detects_rolled_back(aw_module):
    """Status check detects ROLLED_BACK transaction and sends rejection notification."""
    aw = aw_module
    from playerokapi.enums import TransactionStatuses, TransactionOperations

    ctx = _make_ctx(aw)

    import time
    aw.save_pending([{
        "id": "txn-300",
        "amount": 50000,
        "provider": "USDT",
        "created_at": int(time.time()),
    }])

    aw.add_history_entry({
        "ts": int(time.time()),
        "amount": 50000,
        "provider": "USDT",
        "status": "success",
        "transaction_id": "txn-300",
    })

    txn = MagicMock()
    txn.id = "txn-300"
    txn.status = TransactionStatuses.ROLLED_BACK
    txn.status_description = ""

    txn_list = MagicMock()
    txn_list.transactions = [txn]
    ctx.playerok_acc.get_transactions.return_value = txn_list

    aw.HANDLER._check_pending_statuses(ctx)

    pending = aw.load_pending()
    assert len(pending) == 0

    history = aw.load_history()
    assert history[0]["final_status"] == "rejected"


def test_status_check_cleans_stale_entries(aw_module):
    """Pending entries older than 24 hours are cleaned up."""
    aw = aw_module
    from playerokapi.enums import TransactionStatuses, TransactionOperations

    ctx = _make_ctx(aw)

    import time
    old_ts = int(time.time()) - 86401  # More than 24 hours ago
    aw.save_pending([{
        "id": "txn-stale",
        "amount": 75000,
        "provider": "SBP",
        "created_at": old_ts,
    }])

    # Return empty transactions (stale entry won't be found anyway)
    txn_list = MagicMock()
    txn_list.transactions = []
    ctx.playerok_acc.get_transactions.return_value = txn_list

    aw.HANDLER._check_pending_statuses(ctx)

    pending = aw.load_pending()
    assert len(pending) == 0

    # Should log a warning
    ctx.log.warning.assert_called()


def test_status_check_keeps_pending_if_still_processing(aw_module):
    """Pending entries with PENDING/PROCESSING status stay in pending.json."""
    aw = aw_module
    from playerokapi.enums import TransactionStatuses, TransactionOperations

    ctx = _make_ctx(aw)

    import time
    aw.save_pending([{
        "id": "txn-processing",
        "amount": 60000,
        "provider": "YMONEY",
        "created_at": int(time.time()),
    }])

    txn = MagicMock()
    txn.id = "txn-processing"
    txn.status = TransactionStatuses.PROCESSING

    txn_list = MagicMock()
    txn_list.transactions = [txn]
    ctx.playerok_acc.get_transactions.return_value = txn_list

    aw.HANDLER._check_pending_statuses(ctx)

    pending = aw.load_pending()
    assert len(pending) == 1
    assert pending[0]["id"] == "txn-processing"


def test_default_config_has_status_check_interval(aw_module):
    """DEFAULT_CONFIG includes the new withdraw_status_check_interval_minutes key."""
    aw = aw_module
    cfg = aw.get_config()
    assert cfg["withdraw_status_check_interval_minutes"] == 5
