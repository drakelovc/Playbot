"""Tests for plugins/chat_manager.py."""
from __future__ import annotations

import sys
from unittest.mock import MagicMock

import pytest


@pytest.fixture
def cm_module(stub_playerokapi):
    for name in list(sys.modules):
        if name.startswith("plugins"):
            del sys.modules[name]
    import plugins.chat_manager as cm
    return cm


def _make_ctx(cm):
    ctx = MagicMock()
    ctx.playerok_acc = MagicMock()
    ctx.bot = MagicMock()
    ctx.admin_id = 123
    ctx.log = MagicMock()
    ctx.get_config = cm.get_config
    ctx.save_config = cm.save_config
    return ctx


def test_plugin_metadata(cm_module):
    assert cm_module.PLUGIN.id == "chat_manager"
    assert cm_module.PLUGIN.icon == "\U0001f4ac"
    assert cm_module.PLUGIN.default_enabled is True


def test_default_config(cm_module):
    cfg = cm_module.get_config()
    assert cfg["enabled"] is True
    assert cfg["notify_new_messages"] is True
    assert cfg["show_image_button"] is True


def test_on_event_new_message_notifies(cm_module):
    cm = cm_module
    ctx = _make_ctx(cm)

    from playerokapi.enums import EventTypes
    ev = MagicMock()
    ev.type = EventTypes.NEW_MESSAGE
    ev.text = "Hello seller"
    ev.sender_name = "Buyer123"

    result = cm.HANDLER.on_event(ev, ctx)
    assert result is False
    ctx.bot.send_message.assert_called()


def test_on_event_new_message_respects_config(cm_module):
    cm = cm_module
    ctx = _make_ctx(cm)

    cfg = cm.get_config()
    cfg["notify_new_messages"] = False
    cm.save_config(cfg)

    from playerokapi.enums import EventTypes
    ev = MagicMock()
    ev.type = EventTypes.NEW_MESSAGE
    ev.text = "Hello"
    ev.sender_name = "Buyer"

    result = cm.HANDLER.on_event(ev, ctx)
    assert result is False
    ctx.bot.send_message.assert_not_called()


def test_on_event_ignores_other_events(cm_module):
    cm = cm_module
    ctx = _make_ctx(cm)

    from playerokapi.enums import EventTypes
    ev = MagicMock()
    ev.type = EventTypes.DEAL_CONFIRMED

    result = cm.HANDLER.on_event(ev, ctx)
    assert result is False
    ctx.bot.send_message.assert_not_called()
