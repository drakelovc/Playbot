"""Tests for plugins/custom_commands.py."""
from __future__ import annotations

import sys
from unittest.mock import MagicMock

import pytest


@pytest.fixture
def ccmd_module(stub_playerokapi):
    for name in list(sys.modules):
        if name.startswith("plugins"):
            del sys.modules[name]
    import plugins.custom_commands as ccmd
    return ccmd


def test_plugin_metadata(ccmd_module):
    ccmd = ccmd_module
    assert ccmd.PLUGIN.id == "custom_commands"
    assert ccmd.PLUGIN.name == "\u041a\u0430\u0441\u0442\u043e\u043c\u043d\u044b\u0435 \u043a\u043e\u043c\u0430\u043d\u0434\u044b"
    assert ccmd.PLUGIN.icon == "\U0001f916"


def test_default_commands_empty(ccmd_module):
    ccmd = ccmd_module
    cmds = ccmd.get_commands()
    assert cmds == []


def test_add_and_remove_command(ccmd_module):
    ccmd = ccmd_module
    cmds = ccmd.get_commands()
    cmds.append({
        "keyword": "hello",
        "response": "Hi there!",
        "enabled": True,
        "match_type": "exact",
    })
    ccmd.save_commands(cmds)
    loaded = ccmd.get_commands()
    assert len(loaded) == 1
    assert loaded[0]["keyword"] == "hello"

    # Remove
    loaded.pop(0)
    ccmd.save_commands(loaded)
    assert ccmd.get_commands() == []


def test_match_command_exact(ccmd_module):
    ccmd = ccmd_module
    commands = [
        {"keyword": "hello", "response": "Hi!", "enabled": True, "match_type": "exact"},
        {"keyword": "price", "response": "100 rub", "enabled": True, "match_type": "exact"},
    ]
    # Exact match
    result = ccmd.match_command("hello", commands)
    assert result is not None
    assert result["response"] == "Hi!"

    # Case insensitive
    result = ccmd.match_command("HELLO", commands)
    assert result is not None
    assert result["response"] == "Hi!"

    # No match
    result = ccmd.match_command("hello world", commands)
    assert result is None


def test_match_command_contains(ccmd_module):
    ccmd = ccmd_module
    commands = [
        {"keyword": "price", "response": "100 rub", "enabled": True, "match_type": "contains"},
    ]
    # Contains match
    result = ccmd.match_command("what is the price?", commands)
    assert result is not None
    assert result["response"] == "100 rub"

    # No match
    result = ccmd.match_command("hello world", commands)
    assert result is None


def test_disabled_command_skipped(ccmd_module):
    ccmd = ccmd_module
    commands = [
        {"keyword": "hello", "response": "Hi!", "enabled": False, "match_type": "exact"},
    ]
    result = ccmd.match_command("hello", commands)
    assert result is None


def test_on_event_new_message(ccmd_module):
    ccmd = ccmd_module
    from playerokapi.enums import EventTypes

    # Save a command
    ccmd.save_commands([
        {"keyword": "help", "response": "I can help!", "enabled": True, "match_type": "exact"},
    ])

    ctx = MagicMock()
    ctx.playerok_acc = MagicMock()
    ctx.log = MagicMock()
    ctx.get_config = ccmd.get_commands
    ctx.save_config = ccmd.save_commands

    ev = MagicMock()
    ev.type = EventTypes.NEW_MESSAGE
    ev.text = "help"
    ev.chat_id = "chat-123"

    result = ccmd.HANDLER.on_event(ev, ctx)
    assert result is False
    ctx.playerok_acc.send_message.assert_called_once_with("chat-123", "I can help!")


def test_on_event_no_match(ccmd_module):
    ccmd = ccmd_module
    from playerokapi.enums import EventTypes

    ccmd.save_commands([
        {"keyword": "help", "response": "I can help!", "enabled": True, "match_type": "exact"},
    ])

    ctx = MagicMock()
    ctx.playerok_acc = MagicMock()
    ctx.log = MagicMock()

    ev = MagicMock()
    ev.type = EventTypes.NEW_MESSAGE
    ev.text = "something else"
    ev.chat_id = "chat-123"

    result = ccmd.HANDLER.on_event(ev, ctx)
    assert result is False
    ctx.playerok_acc.send_message.assert_not_called()
