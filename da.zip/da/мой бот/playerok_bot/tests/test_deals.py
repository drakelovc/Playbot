"""Tests for plugins/deals.py."""
from __future__ import annotations

import sys
from unittest.mock import MagicMock

import pytest


@pytest.fixture
def dl_module(stub_playerokapi):
    # Add statuses needed by deals plugin
    enums = sys.modules["playerokapi.enums"]
    for attr in ("SENT", "CONFIRMED", "CONFIRMED_AUTOMATICALLY", "ROLLED_BACK"):
        if not hasattr(enums.ItemDealStatuses, attr):
            setattr(enums.ItemDealStatuses, attr, attr)
    for name in list(sys.modules):
        if name.startswith("plugins"):
            del sys.modules[name]
    import plugins.deals as dl
    return dl


def _make_ctx(dl):
    ctx = MagicMock()
    ctx.playerok_acc = MagicMock()
    ctx.bot = MagicMock()
    ctx.admin_id = 123
    ctx.log = MagicMock()
    ctx.get_config = dl.get_config
    ctx.save_config = dl.save_config
    return ctx


def test_plugin_metadata(dl_module):
    assert dl_module.PLUGIN.id == "deals"
    assert dl_module.PLUGIN.icon == "\U0001f91d"
    assert dl_module.PLUGIN.default_enabled is True


def test_default_config(dl_module):
    cfg = dl_module.get_config()
    assert cfg["notify_new_deals"] is True


def test_on_event_returns_false(dl_module):
    dl = dl_module
    ctx = _make_ctx(dl)

    from playerokapi.enums import EventTypes
    ev = MagicMock()
    ev.type = EventTypes.NEW_MESSAGE

    result = dl.HANDLER.on_event(ev, ctx)
    assert result is False


def test_status_label(dl_module):
    dl = dl_module
    # Test that _status_label handles an attribute-like status
    status_mock = MagicMock()
    status_mock.name = "PAID"
    label = dl._status_label(status_mock)
    assert "\u041e\u043f\u043b\u0430\u0447\u0435\u043d\u0430" in label
