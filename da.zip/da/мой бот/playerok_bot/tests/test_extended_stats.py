"""Tests for extended statistics date filtering logic in playerok_bot.py."""
from __future__ import annotations

import sys
import types
from datetime import datetime, timedelta
from pathlib import Path
from unittest.mock import MagicMock

import pytest


# We need to test the _filter_history_by_period function which is in playerok_bot.py.
# Since importing the whole bot is complex (requires telebot, playerokapi etc.),
# we extract and test the pure logic directly.


@pytest.fixture
def filter_func():
    """Import just the filter logic by extracting it from module source."""
    # Instead of importing the whole bot, replicate the filter logic for testing
    def _filter_history_by_period(history: list, period: str) -> list:
        if period == "all":
            return history
        now = datetime.now()
        if period == "24h":
            cutoff = now - timedelta(hours=24)
        elif period == "7d":
            cutoff = now - timedelta(days=7)
        elif period == "30d":
            cutoff = now - timedelta(days=30)
        else:
            return history
        result = []
        for h in history:
            t = h.get("time", "")
            if not t:
                continue
            try:
                entry_time = datetime.strptime(t, "%Y-%m-%d %H:%M:%S")
                if entry_time >= cutoff:
                    result.append(h)
            except (ValueError, TypeError):
                continue
        return result
    return _filter_history_by_period


def test_filter_24h(filter_func):
    """Test that 24h filter only includes entries from last 24 hours."""
    now = datetime.now()
    history = [
        {"type": "deal", "time": (now - timedelta(hours=1)).strftime("%Y-%m-%d %H:%M:%S"), "price": 100},
        {"type": "deal", "time": (now - timedelta(hours=23)).strftime("%Y-%m-%d %H:%M:%S"), "price": 200},
        {"type": "deal", "time": (now - timedelta(hours=25)).strftime("%Y-%m-%d %H:%M:%S"), "price": 300},
        {"type": "deal", "time": (now - timedelta(days=5)).strftime("%Y-%m-%d %H:%M:%S"), "price": 400},
    ]
    result = filter_func(history, "24h")
    assert len(result) == 2
    assert result[0]["price"] == 100
    assert result[1]["price"] == 200


def test_filter_7d(filter_func):
    """Test that 7d filter includes entries from last 7 days."""
    now = datetime.now()
    history = [
        {"type": "deal", "time": (now - timedelta(days=1)).strftime("%Y-%m-%d %H:%M:%S"), "price": 100},
        {"type": "deal", "time": (now - timedelta(days=5)).strftime("%Y-%m-%d %H:%M:%S"), "price": 200},
        {"type": "deal", "time": (now - timedelta(days=8)).strftime("%Y-%m-%d %H:%M:%S"), "price": 300},
        {"type": "deal", "time": (now - timedelta(days=15)).strftime("%Y-%m-%d %H:%M:%S"), "price": 400},
    ]
    result = filter_func(history, "7d")
    assert len(result) == 2
    assert result[0]["price"] == 100
    assert result[1]["price"] == 200


def test_filter_30d(filter_func):
    """Test that 30d filter includes entries from last 30 days."""
    now = datetime.now()
    history = [
        {"type": "deal", "time": (now - timedelta(days=1)).strftime("%Y-%m-%d %H:%M:%S"), "price": 100},
        {"type": "deal", "time": (now - timedelta(days=15)).strftime("%Y-%m-%d %H:%M:%S"), "price": 200},
        {"type": "deal", "time": (now - timedelta(days=29)).strftime("%Y-%m-%d %H:%M:%S"), "price": 300},
        {"type": "deal", "time": (now - timedelta(days=31)).strftime("%Y-%m-%d %H:%M:%S"), "price": 400},
        {"type": "deal", "time": (now - timedelta(days=60)).strftime("%Y-%m-%d %H:%M:%S"), "price": 500},
    ]
    result = filter_func(history, "30d")
    assert len(result) == 3
    assert result[0]["price"] == 100
    assert result[1]["price"] == 200
    assert result[2]["price"] == 300


def test_filter_all_returns_everything(filter_func):
    """Test that 'all' period returns all entries unfiltered."""
    now = datetime.now()
    history = [
        {"type": "deal", "time": (now - timedelta(days=1)).strftime("%Y-%m-%d %H:%M:%S"), "price": 100},
        {"type": "deal", "time": (now - timedelta(days=365)).strftime("%Y-%m-%d %H:%M:%S"), "price": 200},
        {"type": "code", "time": (now - timedelta(days=999)).strftime("%Y-%m-%d %H:%M:%S"), "price": 0},
    ]
    result = filter_func(history, "all")
    assert len(result) == 3


def test_filter_handles_invalid_time(filter_func):
    """Test that entries with invalid time format are skipped."""
    now = datetime.now()
    history = [
        {"type": "deal", "time": (now - timedelta(hours=1)).strftime("%Y-%m-%d %H:%M:%S"), "price": 100},
        {"type": "deal", "time": "invalid-date", "price": 200},
        {"type": "deal", "time": "", "price": 300},
        {"type": "deal", "price": 400},
    ]
    result = filter_func(history, "24h")
    assert len(result) == 1
    assert result[0]["price"] == 100


def test_filter_empty_history(filter_func):
    """Test with empty history."""
    result = filter_func([], "24h")
    assert result == []
    result = filter_func([], "7d")
    assert result == []
    result = filter_func([], "all")
    assert result == []
