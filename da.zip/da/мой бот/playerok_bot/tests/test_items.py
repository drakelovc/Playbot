"""Tests for plugins/items.py."""
from __future__ import annotations

import sys
from unittest.mock import MagicMock

import pytest


@pytest.fixture
def it_module(stub_playerokapi):
    # Add ItemStatuses to stub
    enums = sys.modules["playerokapi.enums"]
    if not hasattr(enums, "ItemStatuses"):
        class ItemStatuses:
            APPROVED = "APPROVED"
            EXPIRED = "EXPIRED"
            SOLD = "SOLD"
            DRAFT = "DRAFT"
        enums.ItemStatuses = ItemStatuses
    for name in list(sys.modules):
        if name.startswith("plugins"):
            del sys.modules[name]
    import plugins.items as it
    return it


def _make_ctx(it):
    ctx = MagicMock()
    ctx.playerok_acc = MagicMock()
    ctx.bot = MagicMock()
    ctx.admin_id = 123
    ctx.log = MagicMock()
    ctx.get_config = it.get_config
    ctx.save_config = it.save_config
    return ctx


def test_plugin_metadata(it_module):
    assert it_module.PLUGIN.id == "items"
    assert it_module.PLUGIN.icon == "\U0001f4e6"
    assert it_module.PLUGIN.default_enabled is True


def test_default_config(it_module):
    cfg = it_module.get_config()
    assert cfg["items_per_page"] == 10


def test_on_event_returns_false(it_module):
    it = it_module
    ctx = _make_ctx(it)

    from playerokapi.enums import EventTypes
    ev = MagicMock()
    ev.type = EventTypes.NEW_MESSAGE

    result = it.HANDLER.on_event(ev, ctx)
    assert result is False


def test_handler_has_required_methods(it_module):
    handler = it_module.HANDLER
    assert hasattr(handler, "setup")
    assert hasattr(handler, "register_telegram")
    assert hasattr(handler, "on_event")
    assert callable(handler.setup)
    assert callable(handler.register_telegram)
    assert callable(handler.on_event)
