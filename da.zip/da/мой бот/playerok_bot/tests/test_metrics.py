"""Тесты Prometheus /metrics: рендер и snapshot."""
from __future__ import annotations

import sys
import types
from unittest.mock import MagicMock


def _make_bot_stub():
    """Создаёт sufficient stubs для импорта playerok_bot.py без побочных
    эффектов (telebot.TeleBot, playerokapi и т.п.)."""
    if "telebot" not in sys.modules:
        telebot = types.ModuleType("telebot")
        telebot.TeleBot = MagicMock
        telebot.types = MagicMock()
        telebot.apihelper = MagicMock()
        telebot.apihelper.ApiTelegramException = Exception
        sys.modules["telebot"] = telebot
        sys.modules["telebot.types"] = telebot.types
        sys.modules["telebot.apihelper"] = telebot.apihelper


def test_render_prometheus_format(stub_playerokapi):
    _make_bot_stub()
    for name in list(sys.modules):
        if name.startswith("plugins") or name == "playerok_bot":
            del sys.modules[name]
    # Импортируем _render_prometheus напрямую из исходника, чтобы не
    # запускать heavy import всего бота.
    import importlib.util
    spec = importlib.util.spec_from_file_location(
        "_pb_metrics_test", "playerok_bot.py")
    # Не выполняем модуль целиком — просто вырезаем нужные функции.
    from pathlib import Path
    pb_path = Path(__file__).resolve().parent.parent / "playerok_bot.py"
    src = pb_path.read_text(encoding="utf-8")

    # Вырезаем _METRIC_META + _render_prometheus в один кусок
    meta_start = src.find("_METRIC_META = {")
    func_start = src.find("def _render_prometheus")
    assert meta_start > 0 and func_start > 0
    func_end = src.find("\ndef ", func_start + 1)
    chunk = src[meta_start:func_end]

    g: dict = {}
    exec(chunk, g)
    out = g["_render_prometheus"]({
        "asr_accounts_total": 3,
        "aso_guard_sent_total": 12,
    })
    assert "# HELP playerok_asr_accounts_total" in out
    assert "# TYPE playerok_asr_accounts_total gauge" in out
    assert "playerok_asr_accounts_total 3.0" in out
    assert "# TYPE playerok_aso_guard_sent_total counter" in out
    assert "playerok_aso_guard_sent_total 12.0" in out
