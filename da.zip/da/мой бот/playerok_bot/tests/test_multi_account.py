"""Tests for plugins/multi_account.py."""
from __future__ import annotations

import sys
import threading
from unittest.mock import MagicMock, patch

import pytest


@pytest.fixture(autouse=True)
def stub_deps(stub_playerokapi, monkeypatch):
    """Extend base stubs for multi_account tests."""
    # Ensure playerokapi package has 'account' attribute pointing to the stub module
    pkg = sys.modules["playerokapi"]
    pkg.account = sys.modules["playerokapi.account"]
    return stub_playerokapi


@pytest.fixture
def ma_module():
    for name in list(sys.modules):
        if name.startswith("plugins"):
            del sys.modules[name]
    import plugins.multi_account as ma
    return ma


def _make_ctx(ma):
    ctx = MagicMock()
    ctx.playerok_acc = None
    ctx.bot = MagicMock()
    ctx.admin_id = 123
    ctx.log = MagicMock()
    ctx.get_config = lambda: {}
    ctx.save_config = MagicMock()
    return ctx


class TestPluginMetadata:
    def test_plugin_id(self, ma_module):
        assert ma_module.PLUGIN.id == "multi_account"

    def test_plugin_name(self, ma_module):
        assert ma_module.PLUGIN.name == "Multi-Account"

    def test_plugin_icon(self, ma_module):
        assert ma_module.PLUGIN.icon == "\U0001f465"

    def test_default_enabled(self, ma_module):
        assert ma_module.PLUGIN.default_enabled is True


class TestStorageOperations:
    def test_load_accounts_creates_empty(self, ma_module):
        accounts = ma_module.load_accounts()
        assert accounts == []

    def test_save_and_load_accounts(self, ma_module):
        data = [
            {
                "alias": "shop1",
                "cookies": "cookie1",
                "user_agent": "ua1",
                "proxy": "",
                "is_active": True,
                "status": "online",
                "username": "user1",
                "error": None,
            }
        ]
        ma_module.save_accounts(data)
        loaded = ma_module.load_accounts()
        assert len(loaded) == 1
        assert loaded[0]["alias"] == "shop1"
        assert loaded[0]["is_active"] is True

    def test_find_account(self, ma_module):
        data = [
            {"alias": "shop1", "cookies": "c1"},
            {"alias": "shop2", "cookies": "c2"},
        ]
        ma_module.save_accounts(data)
        found = ma_module.find_account("shop2")
        assert found is not None
        assert found["cookies"] == "c2"

    def test_find_account_not_found(self, ma_module):
        ma_module.save_accounts([{"alias": "shop1", "cookies": "c1"}])
        assert ma_module.find_account("nope") is None


class TestAddAccount:
    def test_add_first_account_becomes_active(self, ma_module):
        ctx = _make_ctx(ma_module)
        handler = ma_module.Handler()
        handler._ctx = ctx

        # Mock PlayerokAccount
        mock_acc = MagicMock()
        mock_acc.username = "testuser"
        with patch("plugins.multi_account.Handler._start_account_listener"):
            with patch(
                "playerokapi.account.Account", return_value=mock_acc
            ) as mock_cls:
                handler._add_account_async("shop1", "cookies1", "ua", "proxy", ctx)

        accounts = ma_module.load_accounts()
        assert len(accounts) == 1
        assert accounts[0]["alias"] == "shop1"
        assert accounts[0]["is_active"] is True
        assert accounts[0]["status"] == "online"
        assert accounts[0]["username"] == "testuser"
        # ctx.playerok_acc should be updated
        assert ctx.playerok_acc is mock_acc

    def test_add_second_account_not_active(self, ma_module):
        ctx = _make_ctx(ma_module)
        handler = ma_module.Handler()
        handler._ctx = ctx

        # Pre-seed first account
        ma_module.save_accounts([{
            "alias": "shop1", "cookies": "c1", "user_agent": "",
            "proxy": "", "is_active": True, "status": "online",
            "username": "u1", "error": None,
        }])

        mock_acc = MagicMock()
        mock_acc.username = "user2"
        with patch("plugins.multi_account.Handler._start_account_listener"):
            with patch(
                "playerokapi.account.Account", return_value=mock_acc
            ):
                handler._add_account_async("shop2", "cookies2", "", "", ctx)

        accounts = ma_module.load_accounts()
        assert len(accounts) == 2
        shop2 = [a for a in accounts if a["alias"] == "shop2"][0]
        assert shop2["is_active"] is False

    def test_add_account_validation_failure(self, ma_module):
        ctx = _make_ctx(ma_module)
        handler = ma_module.Handler()
        handler._ctx = ctx

        with patch(
            "playerokapi.account.Account", side_effect=Exception("auth failed")
        ):
            handler._add_account_async("bad", "cookies", "", "", ctx)

        accounts = ma_module.load_accounts()
        assert len(accounts) == 0
        # Should notify admin about failure
        ctx.bot.send_message.assert_called()
        call_args = ctx.bot.send_message.call_args
        assert "Failed" in call_args[0][1] or "failed" in call_args[0][1].lower()


class TestRemoveAccount:
    def test_remove_account(self, ma_module):
        ctx = _make_ctx(ma_module)
        handler = ma_module.Handler()
        handler._ctx = ctx

        ma_module.save_accounts([
            {"alias": "shop1", "cookies": "c1", "is_active": True,
             "status": "online", "username": "u1", "error": None,
             "user_agent": "", "proxy": ""},
            {"alias": "shop2", "cookies": "c2", "is_active": False,
             "status": "online", "username": "u2", "error": None,
             "user_agent": "", "proxy": ""},
        ])

        handler._remove_account("shop1")
        accounts = ma_module.load_accounts()
        assert len(accounts) == 1
        assert accounts[0]["alias"] == "shop2"

    def test_remove_nonexistent(self, ma_module):
        handler = ma_module.Handler()
        ma_module.save_accounts([
            {"alias": "shop1", "cookies": "c1", "is_active": True,
             "status": "online", "username": "u1", "error": None,
             "user_agent": "", "proxy": ""},
        ])
        handler._remove_account("nope")
        # Should not crash, account list unchanged
        accounts = ma_module.load_accounts()
        assert len(accounts) == 1


class TestSwitchActive:
    def test_switch_active_updates_flag(self, ma_module):
        ctx = _make_ctx(ma_module)
        handler = ma_module.Handler()
        handler._ctx = ctx

        mock_acc1 = MagicMock()
        mock_acc2 = MagicMock()

        with handler._lock:
            handler._instances["shop1"] = {"account": mock_acc1, "thread": None, "stop": False}
            handler._instances["shop2"] = {"account": mock_acc2, "thread": None, "stop": False}

        ma_module.save_accounts([
            {"alias": "shop1", "cookies": "c1", "is_active": True,
             "status": "online", "username": "u1", "error": None,
             "user_agent": "", "proxy": ""},
            {"alias": "shop2", "cookies": "c2", "is_active": False,
             "status": "online", "username": "u2", "error": None,
             "user_agent": "", "proxy": ""},
        ])

        with patch.object(handler, "_start_account_listener"):
            result = handler._switch_active("shop2", ctx)

        assert result is True
        accounts = ma_module.load_accounts()
        shop1 = [a for a in accounts if a["alias"] == "shop1"][0]
        shop2 = [a for a in accounts if a["alias"] == "shop2"][0]
        assert shop1["is_active"] is False
        assert shop2["is_active"] is True
        # ctx.playerok_acc should point to shop2's account instance
        assert ctx.playerok_acc is mock_acc2

    def test_switch_active_not_found(self, ma_module):
        ctx = _make_ctx(ma_module)
        handler = ma_module.Handler()
        ma_module.save_accounts([
            {"alias": "shop1", "cookies": "c1", "is_active": True,
             "status": "online", "username": "u1", "error": None,
             "user_agent": "", "proxy": ""},
        ])
        result = handler._switch_active("nope", ctx)
        assert result is False


class TestNonActiveEventHandling:
    def test_handle_new_message_event(self, ma_module):
        ctx = _make_ctx(ma_module)
        handler = ma_module.Handler()

        from playerokapi.enums import EventTypes
        event = MagicMock()
        event.type = EventTypes.NEW_MESSAGE

        handler._handle_non_active_event("myshop", event, ctx)

        ctx.bot.send_message.assert_called_once()
        call_args = ctx.bot.send_message.call_args
        assert "[myshop]" in call_args[0][1]
        assert "New message" in call_args[0][1]

    def test_handle_new_deal_event(self, ma_module):
        ctx = _make_ctx(ma_module)
        handler = ma_module.Handler()

        from playerokapi.enums import EventTypes
        event = MagicMock()
        event.type = EventTypes.NEW_DEAL

        handler._handle_non_active_event("shop2", event, ctx)

        ctx.bot.send_message.assert_called_once()
        call_args = ctx.bot.send_message.call_args
        assert "[shop2]" in call_args[0][1]
        assert "New deal" in call_args[0][1]

    def test_handle_deal_confirmed_event(self, ma_module):
        ctx = _make_ctx(ma_module)
        handler = ma_module.Handler()

        from playerokapi.enums import EventTypes
        event = MagicMock()
        event.type = EventTypes.DEAL_CONFIRMED

        handler._handle_non_active_event("s1", event, ctx)

        ctx.bot.send_message.assert_called_once()
        call_args = ctx.bot.send_message.call_args
        assert "[s1]" in call_args[0][1]
        assert "Deal confirmed" in call_args[0][1]

    def test_handle_unknown_event_no_notification(self, ma_module):
        ctx = _make_ctx(ma_module)
        handler = ma_module.Handler()

        event = MagicMock()
        event.type = "SOME_UNKNOWN_TYPE"

        handler._handle_non_active_event("shop", event, ctx)

        ctx.bot.send_message.assert_not_called()


class TestSetup:
    def test_setup_creates_storage(self, ma_module):
        ctx = _make_ctx(ma_module)
        handler = ma_module.Handler()
        handler.setup(ctx)
        # Should not crash and should create file
        accounts = ma_module.load_accounts()
        assert accounts == []


class TestConfigPersistence:
    def test_accounts_persist_across_loads(self, ma_module):
        data = [
            {"alias": "a1", "cookies": "c1", "user_agent": "",
             "proxy": "", "is_active": True, "status": "online",
             "username": "u1", "error": None},
            {"alias": "a2", "cookies": "c2", "user_agent": "ua2",
             "proxy": "proxy2", "is_active": False, "status": "offline",
             "username": "u2", "error": None},
        ]
        ma_module.save_accounts(data)

        # Clear module cache and re-import
        for name in list(sys.modules):
            if name.startswith("plugins"):
                del sys.modules[name]
        import plugins.multi_account as ma2

        loaded = ma2.load_accounts()
        assert len(loaded) == 2
        assert loaded[0]["alias"] == "a1"
        assert loaded[1]["proxy"] == "proxy2"
