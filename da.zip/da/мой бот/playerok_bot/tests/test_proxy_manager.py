"""Tests for plugins/proxy_manager.py."""
from __future__ import annotations

import sys
from unittest.mock import MagicMock, patch

import pytest


@pytest.fixture
def pm_module(stub_playerokapi):
    for name in list(sys.modules):
        if name.startswith("plugins"):
            del sys.modules[name]
    import plugins.proxy_manager as pm
    return pm


def test_plugin_metadata(pm_module):
    pm = pm_module
    assert pm.PLUGIN.id == "proxy_manager"
    assert pm.PLUGIN.name == "\u041f\u0440\u043e\u043a\u0441\u0438-\u043c\u0435\u043d\u0435\u0434\u0436\u0435\u0440"
    assert pm.PLUGIN.icon == "\U0001f310"


def test_default_proxies_empty(pm_module):
    pm = pm_module
    proxies = pm.get_proxies()
    assert proxies == []


def test_add_and_remove_proxy(pm_module):
    pm = pm_module
    proxies = pm.get_proxies()
    proxies.append({
        "address": "user:pass@1.2.3.4:8080",
        "label": "1.2.3.4:8080",
        "is_active": True,
        "last_check": None,
        "is_healthy": False,
        "response_time_ms": None,
    })
    pm.save_proxies(proxies)
    loaded = pm.get_proxies()
    assert len(loaded) == 1
    assert loaded[0]["address"] == "user:pass@1.2.3.4:8080"

    # Remove
    loaded.pop(0)
    pm.save_proxies(loaded)
    assert pm.get_proxies() == []


def test_health_check_failure(pm_module):
    pm = pm_module
    # Mock requests to simulate connection failure
    with patch("plugins.proxy_manager.requests") as mock_requests:
        mock_requests.get.side_effect = Exception("Connection refused")
        is_healthy, response_time = pm.check_proxy_health("user:pass@1.2.3.4:8080")
        assert is_healthy is False
        assert response_time is None


def test_health_check_success(pm_module):
    pm = pm_module
    with patch("plugins.proxy_manager.requests") as mock_requests:
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_requests.get.return_value = mock_response
        is_healthy, response_time = pm.check_proxy_health("user:pass@1.2.3.4:8080")
        assert is_healthy is True
        assert response_time is not None
        assert response_time >= 0


def test_get_next_healthy_proxy_empty(pm_module):
    pm = pm_module
    proxies = []
    result = pm.get_next_healthy_proxy(proxies, None)
    assert result is None


def test_get_next_healthy_proxy_rotation(pm_module):
    pm = pm_module
    proxies = [
        {"address": "a@1.1.1.1:80", "is_healthy": True, "is_active": True},
        {"address": "b@2.2.2.2:80", "is_healthy": False, "is_active": False},
        {"address": "c@3.3.3.3:80", "is_healthy": True, "is_active": False},
    ]
    # Current is first, next healthy should be third
    result = pm.get_next_healthy_proxy(proxies, "a@1.1.1.1:80")
    assert result is not None
    assert result["address"] == "c@3.3.3.3:80"

    # Current is third, next healthy should wrap to first
    result = pm.get_next_healthy_proxy(proxies, "c@3.3.3.3:80")
    assert result is not None
    assert result["address"] == "a@1.1.1.1:80"


def test_rotate_proxy(pm_module):
    pm = pm_module
    # Save proxies
    pm.save_proxies([
        {"address": "a@1.1.1.1:80", "label": "1", "is_active": True, "is_healthy": True,
         "last_check": None, "response_time_ms": 100},
        {"address": "b@2.2.2.2:80", "label": "2", "is_active": False, "is_healthy": True,
         "last_check": None, "response_time_ms": 200},
    ])

    ctx = MagicMock()
    ctx.bot = MagicMock()
    ctx.admin_id = 123
    cfg = {"playerok_proxy": "a@1.1.1.1:80"}
    ctx.get_config = MagicMock(return_value=cfg)
    ctx.save_config = MagicMock()
    ctx.log = MagicMock()

    pm.HANDLER._rotate_proxy(ctx)

    # Should have rotated to second proxy
    proxies = pm.get_proxies()
    active = [p for p in proxies if p.get("is_active")]
    assert len(active) == 1
    assert active[0]["address"] == "b@2.2.2.2:80"

    # Config should have been updated
    ctx.save_config.assert_called_once()
    saved_cfg = ctx.save_config.call_args[0][0]
    assert saved_cfg["playerok_proxy"] == "b@2.2.2.2:80"
