"""Tests for plugins/reviews.py."""
from __future__ import annotations

import sys
from unittest.mock import MagicMock

import pytest


@pytest.fixture
def rv_module(stub_playerokapi):
    # Add NEW_REVIEW to EventTypes stub if not present
    enums = sys.modules["playerokapi.enums"]
    if not hasattr(enums.EventTypes, "NEW_REVIEW"):
        enums.EventTypes.NEW_REVIEW = "NEW_REVIEW"
    for name in list(sys.modules):
        if name.startswith("plugins"):
            del sys.modules[name]
    import plugins.reviews as rv
    return rv


def _make_ctx(rv):
    ctx = MagicMock()
    ctx.playerok_acc = MagicMock()
    ctx.bot = MagicMock()
    ctx.admin_id = 123
    ctx.log = MagicMock()
    ctx.get_config = rv.get_config
    ctx.save_config = rv.save_config
    return ctx


def test_plugin_metadata(rv_module):
    assert rv_module.PLUGIN.id == "reviews"
    assert rv_module.PLUGIN.icon == "\u2b50"
    assert rv_module.PLUGIN.default_enabled is True


def test_default_config(rv_module):
    cfg = rv_module.get_config()
    assert cfg["notify_new_reviews"] is True


def test_on_event_new_review_notifies(rv_module):
    rv = rv_module
    ctx = _make_ctx(rv)

    from playerokapi.enums import EventTypes
    ev = MagicMock()
    ev.type = EventTypes.NEW_REVIEW
    ev.rating = 5
    ev.text = "Great seller!"
    ev.buyer_name = "HappyBuyer"
    ev.user_name = "HappyBuyer"

    result = rv.HANDLER.on_event(ev, ctx)
    assert result is False
    ctx.bot.send_message.assert_called()


def test_on_event_new_review_respects_config(rv_module):
    rv = rv_module
    ctx = _make_ctx(rv)

    cfg = rv.get_config()
    cfg["notify_new_reviews"] = False
    rv.save_config(cfg)

    from playerokapi.enums import EventTypes
    ev = MagicMock()
    ev.type = EventTypes.NEW_REVIEW
    ev.rating = 1
    ev.text = "Bad"
    ev.buyer_name = "Buyer"
    ev.user_name = "Buyer"

    result = rv.HANDLER.on_event(ev, ctx)
    assert result is False
    ctx.bot.send_message.assert_not_called()


def test_stars_helper(rv_module):
    assert rv_module._stars(5) == "\u2b50\u2b50\u2b50\u2b50\u2b50"
    assert rv_module._stars(0) == ""
    assert rv_module._stars(3) == "\u2b50\u2b50\u2b50"
