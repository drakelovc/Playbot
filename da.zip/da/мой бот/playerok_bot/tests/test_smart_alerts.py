"""Tests for plugins/smart_alerts.py."""
from __future__ import annotations

import sys
import time
from unittest.mock import MagicMock, patch

import pytest


@pytest.fixture
def sa_module(stub_playerokapi):
    """Stub playerokapi and reimport smart_alerts fresh."""
    # Add DEAL_ROLLED_BACK to EventTypes stub if missing
    enums = sys.modules["playerokapi.enums"]
    if not hasattr(enums.EventTypes, "DEAL_ROLLED_BACK"):
        enums.EventTypes.DEAL_ROLLED_BACK = "DEAL_ROLLED_BACK"

    for name in list(sys.modules):
        if name.startswith("plugins"):
            del sys.modules[name]
    import plugins.smart_alerts as sa
    return sa


def _make_ctx(sa):
    ctx = MagicMock()
    ctx.playerok_acc = MagicMock()
    ctx.bot = MagicMock()
    ctx.admin_id = 0
    ctx.log = MagicMock()
    ctx.get_config = sa.get_config
    ctx.save_config = sa.save_config
    return ctx


def test_plugin_metadata(sa_module):
    sa = sa_module
    assert sa.PLUGIN.id == "smart_alerts"
    assert sa.PLUGIN.icon == "\U0001f514"
    assert sa.PLUGIN.default_enabled is True


def test_default_config(sa_module):
    sa = sa_module
    cfg = sa.get_config()
    assert cfg["enabled"] is True
    assert cfg["min_balance_rub"] == 500
    assert cfg["expected_sales_per_hour"] == 2.0
    assert cfg["max_refunds_per_day"] == 3
    assert cfg["rapid_buyer_threshold"] == 3
    assert cfg["check_interval_minutes"] == 5
    assert cfg["alert_cooldown_minutes"] == 30
    assert cfg["quiet_hours_start"] is None
    assert cfg["quiet_hours_end"] is None
    assert cfg["zero_sales_hours"] == 6
    assert cfg["enabled_alert_types"]["sales_anomaly"] is True
    assert cfg["enabled_alert_types"]["balance"] is True
    assert cfg["enabled_alert_types"]["suspicious_activity"] is True
    assert cfg["enabled_alert_types"]["listing_issues"] is True
    assert cfg["enabled_alert_types"]["system_health"] is True


def test_on_event_item_paid_records_sale(sa_module):
    sa = sa_module
    from playerokapi.enums import EventTypes

    ctx = _make_ctx(sa)
    ev = MagicMock()
    ev.type = EventTypes.ITEM_PAID
    ev.buyer_id = "buyer-123"

    result = sa.HANDLER.on_event(ev, ctx)
    assert result is False

    events = sa.load_events()
    assert len(events) == 1
    assert events[0]["type"] == "sale"
    assert events[0]["buyer_id"] == "buyer-123"
    assert "ts" in events[0]


def test_on_event_deal_problem_records_problem(sa_module):
    sa = sa_module
    from playerokapi.enums import EventTypes

    ctx = _make_ctx(sa)
    ev = MagicMock()
    ev.type = EventTypes.DEAL_HAS_PROBLEM
    ev.id = "deal-456"

    result = sa.HANDLER.on_event(ev, ctx)
    assert result is False

    events = sa.load_events()
    assert len(events) == 1
    assert events[0]["type"] == "problem"
    assert events[0]["deal_id"] == "deal-456"


def test_on_event_deal_rolled_back_records_refund(sa_module):
    sa = sa_module
    from playerokapi.enums import EventTypes

    ctx = _make_ctx(sa)
    ev = MagicMock()
    ev.type = EventTypes.DEAL_ROLLED_BACK
    ev.id = "deal-789"

    result = sa.HANDLER.on_event(ev, ctx)
    assert result is False

    events = sa.load_events()
    assert len(events) == 1
    assert events[0]["type"] == "refund"
    assert events[0]["deal_id"] == "deal-789"


def test_run_checks_sales_zero_alert(sa_module):
    sa = sa_module
    ctx = _make_ctx(sa)

    # Config with expected_sales > 0 and no sales events
    cfg = sa.get_config()
    cfg["expected_sales_per_hour"] = 2.0
    cfg["zero_sales_hours"] = 6
    sa.save_config(cfg)

    # No sales events at all
    sa.save_events([])

    # Ensure no balance to avoid balance check side effects
    ctx.playerok_acc = None

    sa._run_checks(ctx)

    # Should have sent an alert
    ctx.bot.send_message.assert_called()
    call_text = ctx.bot.send_message.call_args[0][1]
    assert "продаж" in call_text.lower()


def test_run_checks_balance_low_alert(sa_module):
    sa = sa_module
    ctx = _make_ctx(sa)

    cfg = sa.get_config()
    cfg["min_balance_rub"] = 500
    # Disable sales check to isolate balance test
    cfg["enabled_alert_types"]["sales_anomaly"] = False
    sa.save_config(cfg)

    # Set balance below threshold (500 rub = 50000 kopeks)
    balance = MagicMock()
    balance.withdrawable = 10000  # 100 rub < 500 rub
    ctx.playerok_acc.balance = balance

    # Add a sale event so sales check does not fire
    sa.save_events([{"type": "sale", "ts": int(time.time()), "buyer_id": "x"}])

    sa._run_checks(ctx)

    ctx.bot.send_message.assert_called()
    call_text = ctx.bot.send_message.call_args[0][1]
    assert "баланс" in call_text.lower()


def test_cooldown_prevents_duplicate(sa_module):
    sa = sa_module
    ctx = _make_ctx(sa)

    cfg = sa.get_config()
    cfg["alert_cooldown_minutes"] = 30
    sa.save_config(cfg)

    # First alert should fire
    result1 = sa._send_alert(ctx, "test_key", "test message")
    assert result1 is True

    # Second alert should be suppressed
    ctx.bot.send_message.reset_mock()
    result2 = sa._send_alert(ctx, "test_key", "test message")
    assert result2 is False
    ctx.bot.send_message.assert_not_called()


def test_quiet_hours_suppresses(sa_module):
    sa = sa_module
    ctx = _make_ctx(sa)

    current_hour = time.localtime().tm_hour
    # Set quiet hours covering current hour
    cfg = sa.get_config()
    cfg["quiet_hours_start"] = current_hour
    cfg["quiet_hours_end"] = (current_hour + 2) % 24
    cfg["alert_cooldown_minutes"] = 0  # no cooldown interference
    sa.save_config(cfg)

    result = sa._send_alert(ctx, "quiet_test", "should be suppressed")
    assert result is False
    ctx.bot.send_message.assert_not_called()


def test_trim_events_removes_old(sa_module):
    sa = sa_module

    now_ts = int(time.time())
    old_event = {"type": "sale", "ts": now_ts - 90000, "buyer_id": "old"}  # > 24h ago
    new_event = {"type": "sale", "ts": now_ts - 100, "buyer_id": "new"}  # recent

    sa.save_events([old_event, new_event])
    sa.trim_events()

    events = sa.load_events()
    assert len(events) == 1
    assert events[0]["buyer_id"] == "new"


def test_suspicious_activity_refunds(sa_module):
    sa = sa_module
    ctx = _make_ctx(sa)

    cfg = sa.get_config()
    cfg["max_refunds_per_day"] = 2
    cfg["enabled_alert_types"]["sales_anomaly"] = False
    cfg["enabled_alert_types"]["balance"] = False
    cfg["enabled_alert_types"]["system_health"] = False
    sa.save_config(cfg)

    ctx.playerok_acc = None

    # Add more refunds than threshold
    now_ts = int(time.time())
    events = [
        {"type": "refund", "ts": now_ts - 100, "deal_id": "d1"},
        {"type": "refund", "ts": now_ts - 200, "deal_id": "d2"},
        {"type": "refund", "ts": now_ts - 300, "deal_id": "d3"},
    ]
    sa.save_events(events)

    sa._run_checks(ctx)

    ctx.bot.send_message.assert_called()
    call_text = ctx.bot.send_message.call_args[0][1]
    assert "возврат" in call_text.lower()


def test_rapid_buyer_detection(sa_module):
    sa = sa_module
    ctx = _make_ctx(sa)

    cfg = sa.get_config()
    cfg["rapid_buyer_threshold"] = 3
    cfg["enabled_alert_types"]["sales_anomaly"] = False
    cfg["enabled_alert_types"]["balance"] = False
    cfg["enabled_alert_types"]["system_health"] = False
    sa.save_config(cfg)

    ctx.playerok_acc = None

    # Add multiple sales from same buyer in last hour
    now_ts = int(time.time())
    events = [
        {"type": "sale", "ts": now_ts - 60, "buyer_id": "rapid-buyer"},
        {"type": "sale", "ts": now_ts - 120, "buyer_id": "rapid-buyer"},
        {"type": "sale", "ts": now_ts - 180, "buyer_id": "rapid-buyer"},
    ]
    sa.save_events(events)

    sa._run_checks(ctx)

    ctx.bot.send_message.assert_called()
    call_text = ctx.bot.send_message.call_args[0][1]
    assert "покупатель" in call_text.lower()
