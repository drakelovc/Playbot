"""Тесты для plugins/_steam_common.py — самая «чистая» часть кодовой
базы, ничего не требует от Playerok/Telegram, удобно покрыть."""
from __future__ import annotations

import io
import json
import zipfile
from pathlib import Path

import pytest

from plugins import _steam_common as common


def test_load_save_json_roundtrip(tmp_path: Path) -> None:
    path = tmp_path / "foo.json"
    common.save_json(str(path), {"a": 1, "b": [1, 2, 3]})
    assert common.load_json(str(path), None) == {"a": 1, "b": [1, 2, 3]}


def test_load_json_default_when_missing(tmp_path: Path) -> None:
    assert common.load_json(str(tmp_path / "nope.json"), default=[]) == []


def test_short_id_deterministic() -> None:
    a = common.short_id("leshaman111")
    b = common.short_id("leshaman111")
    c = common.short_id("leshaman112")
    assert a == b
    assert a != c
    assert len(a) == 8


def test_parse_duration_minutes() -> None:
    assert common.parse_duration_minutes("Аренда Steam на 2 часа") == 120
    assert common.parse_duration_minutes("на 30 минут") == 30
    assert common.parse_duration_minutes("на 1 сутки") == 60 * 24
    assert common.parse_duration_minutes("на 2 дня") == 60 * 48
    assert common.parse_duration_minutes("без числа") is None


def test_md_escape() -> None:
    assert common.md_escape("hello_world*") == r"hello\_world\*"


def test_parse_mafile_bytes_valid() -> None:
    payload = {
        "shared_secret": "abc",
        "identity_secret": "def",
        "Session": {"SteamID": "76561198000000000"},
    }
    raw = json.dumps(payload).encode("utf-8")
    out = common.parse_mafile_bytes(raw)
    assert out["shared_secret"] == "abc"
    assert out["identity_secret"] == "def"


def test_parse_mafile_bytes_with_bom() -> None:
    payload = {"shared_secret": "x", "identity_secret": "y"}
    raw = b"\xef\xbb\xbf" + json.dumps(payload).encode("utf-8")
    out = common.parse_mafile_bytes(raw)
    assert out["shared_secret"] == "x"


def test_parse_mafile_from_zip() -> None:
    payload = {"shared_secret": "z1", "identity_secret": "z2"}
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as zf:
        zf.writestr("alpha.maFile", json.dumps(payload))
        zf.writestr("readme.txt", "ignore me")
    out = common.parse_mafile_from_zip(buf.getvalue())
    assert len(out) == 1
    name, data = out[0]
    assert name == "alpha.maFile"
    assert data["shared_secret"] == "z1"


def test_human_seconds_zero() -> None:
    assert common.human_seconds(0) in ("0 сек", "0 секунд", "только что",
                                       "0с", "0 c")  # tolerate variations


def test_human_minutes_basic() -> None:
    assert "ч" in common.human_minutes(120) or "час" in common.human_minutes(120)


def test_sqlite_backend_roundtrip(monkeypatch, tmp_path: Path) -> None:
    """Sanity: при PLAYEROK_USE_SQLITE=1 load/save идёт через SQLite."""
    monkeypatch.setenv("PLAYEROK_USE_SQLITE", "1")
    # Заставляем _sqlite_store открыть свежий коннект в этой tmp_path
    import sys
    sys.modules.pop("plugins._sqlite_store", None)
    common.save_json("storage/plugins/foo/x.json", {"v": 42})
    assert common.load_json("storage/plugins/foo/x.json", None) == {"v": 42}
    # Файл на диске НЕ должен быть создан (если не выставлен backup flag)
    assert not (tmp_path / "storage" / "plugins" / "foo" / "x.json").exists()
